
namespace DotEditPanels
{
    partial class Survey_Page1
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Survey_Page1));
                            this.lbl1a = new System.Windows.Forms.Label();
                                        this.dcim1a = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1a = new System.Windows.Forms.ComboBox();
                                        this.lbl1b = new System.Windows.Forms.Label();
                                        this.dcim1b = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1b = new System.Windows.Forms.ComboBox();
                                        this.lbl1c = new System.Windows.Forms.Label();
                                        this.dcim1c = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1c = new System.Windows.Forms.ComboBox();
                                        this.lbl1d = new System.Windows.Forms.Label();
                                        this.dcim1d = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1d = new System.Windows.Forms.ComboBox();
                                        this.lbl1e = new System.Windows.Forms.Label();
                                        this.dcim1e = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1e = new System.Windows.Forms.ComboBox();
                                        this.lbl1f = new System.Windows.Forms.Label();
                                        this.dcim1f = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1f = new System.Windows.Forms.ComboBox();
                                        this.lbl1g = new System.Windows.Forms.Label();
                                        this.dcim1g = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1g = new System.Windows.Forms.ComboBox();
                                        this.lbl1h = new System.Windows.Forms.Label();
                                        this.dcim1h = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1h = new System.Windows.Forms.ComboBox();
                                        this.lbl1i = new System.Windows.Forms.Label();
                                        this.dcim1i = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1i = new System.Windows.Forms.ComboBox();
                                        this.lbl1j = new System.Windows.Forms.Label();
                                        this.dcim1j = new AxDCIMAGELib.AxDcimage();
                                        this.cmb1j = new System.Windows.Forms.ComboBox();
                                        this.lbl2a = new System.Windows.Forms.Label();
                                        this.dcim2a = new AxDCIMAGELib.AxDcimage();
                                        this.cmb2a = new System.Windows.Forms.ComboBox();
                                        this.lbl2b = new System.Windows.Forms.Label();
                                        this.dcim2b = new AxDCIMAGELib.AxDcimage();
                                        this.cmb2b = new System.Windows.Forms.ComboBox();
                                        this.lbl2c = new System.Windows.Forms.Label();
                                        this.dcim2c = new AxDCIMAGELib.AxDcimage();
                                        this.cmb2c = new System.Windows.Forms.ComboBox();
                                        this.lbl2d = new System.Windows.Forms.Label();
                                        this.dcim2d = new AxDCIMAGELib.AxDcimage();
                                        this.cmb2d = new System.Windows.Forms.ComboBox();
                                        this.lbl2e = new System.Windows.Forms.Label();
                                        this.dcim2e = new AxDCIMAGELib.AxDcimage();
                                        this.cmb2e = new System.Windows.Forms.ComboBox();
                                        this.lbl3a = new System.Windows.Forms.Label();
                                        this.dcim3a = new AxDCIMAGELib.AxDcimage();
                                        this.cmb3a = new System.Windows.Forms.ComboBox();
                                        this.lbl3b = new System.Windows.Forms.Label();
                                        this.dcim3b = new AxDCIMAGELib.AxDcimage();
                                        this.cmb3b = new System.Windows.Forms.ComboBox();
                                        this.lbl4 = new System.Windows.Forms.Label();
                                        this.dcim4 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb4 = new System.Windows.Forms.ComboBox();
                                        this.lbl5a = new System.Windows.Forms.Label();
                                        this.dcim5a = new AxDCIMAGELib.AxDcimage();
                                        this.cmb5a = new System.Windows.Forms.ComboBox();
                                        this.lbl5b = new System.Windows.Forms.Label();
                                        this.dcim5b = new AxDCIMAGELib.AxDcimage();
                                        this.cmb5b = new System.Windows.Forms.ComboBox();
                                        this.lbl6 = new System.Windows.Forms.Label();
                                        this.dcim6 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb6 = new System.Windows.Forms.ComboBox();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1a)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1b)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1c)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1d)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1e)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1f)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1g)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1h)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1i)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim1j)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim2a)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim2b)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim2c)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim2d)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim2e)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim3a)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim3b)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim4)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim5a)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim5b)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim6)).BeginInit();
                            
            this.SuspendLayout();
                                // 
            // lbl1a
            // 
            this.lbl1a.AutoSize = true;
            this.lbl1a.Location = new System.Drawing.Point(17, 12);
            this.lbl1a.Name = "lbl1a";
            this.lbl1a.Size = new System.Drawing.Size(100, 15);
            this.lbl1a.TabIndex = 0;
            this.lbl1a.Text = "1a";
            this.lbl1a.Tag = "1a";
                                        this.lbl1a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1a
            // 
            this.dcim1a.Enabled = true;
            this.dcim1a.Location = new System.Drawing.Point(20, 33);
            this.dcim1a.Name = "dcim1a";
            this.dcim1a.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1a.Size = new System.Drawing.Size(200, 50);
            this.dcim1a.TabIndex = 1;
            this.dcim1a.TabStop = false;
            this.dcim1a.Tag = "1a";
                                        // 
            // cmb1a
            // 
            this.cmb1a.FormattingEnabled = true;
            this.cmb1a.Location = new System.Drawing.Point(20, 87);
            this.cmb1a.Name = "cmb1a";
            this.cmb1a.Size = new System.Drawing.Size(200, 26);
            this.cmb1a.TabIndex = 2;
            this.cmb1a.Tag = "1a";
                                        this.cmb1a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1b
            // 
            this.lbl1b.AutoSize = true;
            this.lbl1b.Location = new System.Drawing.Point(17, 124);
            this.lbl1b.Name = "lbl1b";
            this.lbl1b.Size = new System.Drawing.Size(100, 15);
            this.lbl1b.TabIndex = 3;
            this.lbl1b.Text = "1b";
            this.lbl1b.Tag = "1b";
                                        this.lbl1b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1b
            // 
            this.dcim1b.Enabled = true;
            this.dcim1b.Location = new System.Drawing.Point(20, 145);
            this.dcim1b.Name = "dcim1b";
            this.dcim1b.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1b.Size = new System.Drawing.Size(200, 50);
            this.dcim1b.TabIndex = 4;
            this.dcim1b.TabStop = false;
            this.dcim1b.Tag = "1b";
                                        // 
            // cmb1b
            // 
            this.cmb1b.FormattingEnabled = true;
            this.cmb1b.Location = new System.Drawing.Point(20, 199);
            this.cmb1b.Name = "cmb1b";
            this.cmb1b.Size = new System.Drawing.Size(200, 26);
            this.cmb1b.TabIndex = 5;
            this.cmb1b.Tag = "1b";
                                        this.cmb1b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1c
            // 
            this.lbl1c.AutoSize = true;
            this.lbl1c.Location = new System.Drawing.Point(17, 236);
            this.lbl1c.Name = "lbl1c";
            this.lbl1c.Size = new System.Drawing.Size(100, 15);
            this.lbl1c.TabIndex = 6;
            this.lbl1c.Text = "1c";
            this.lbl1c.Tag = "1c";
                                        this.lbl1c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1c
            // 
            this.dcim1c.Enabled = true;
            this.dcim1c.Location = new System.Drawing.Point(20, 257);
            this.dcim1c.Name = "dcim1c";
            this.dcim1c.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1c.Size = new System.Drawing.Size(200, 50);
            this.dcim1c.TabIndex = 7;
            this.dcim1c.TabStop = false;
            this.dcim1c.Tag = "1c";
                                        // 
            // cmb1c
            // 
            this.cmb1c.FormattingEnabled = true;
            this.cmb1c.Location = new System.Drawing.Point(20, 311);
            this.cmb1c.Name = "cmb1c";
            this.cmb1c.Size = new System.Drawing.Size(200, 26);
            this.cmb1c.TabIndex = 8;
            this.cmb1c.Tag = "1c";
                                        this.cmb1c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1d
            // 
            this.lbl1d.AutoSize = true;
            this.lbl1d.Location = new System.Drawing.Point(17, 348);
            this.lbl1d.Name = "lbl1d";
            this.lbl1d.Size = new System.Drawing.Size(100, 15);
            this.lbl1d.TabIndex = 9;
            this.lbl1d.Text = "1d";
            this.lbl1d.Tag = "1d";
                                        this.lbl1d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1d
            // 
            this.dcim1d.Enabled = true;
            this.dcim1d.Location = new System.Drawing.Point(20, 369);
            this.dcim1d.Name = "dcim1d";
            this.dcim1d.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1d.Size = new System.Drawing.Size(200, 50);
            this.dcim1d.TabIndex = 10;
            this.dcim1d.TabStop = false;
            this.dcim1d.Tag = "1d";
                                        // 
            // cmb1d
            // 
            this.cmb1d.FormattingEnabled = true;
            this.cmb1d.Location = new System.Drawing.Point(20, 423);
            this.cmb1d.Name = "cmb1d";
            this.cmb1d.Size = new System.Drawing.Size(200, 26);
            this.cmb1d.TabIndex = 11;
            this.cmb1d.Tag = "1d";
                                        this.cmb1d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1e
            // 
            this.lbl1e.AutoSize = true;
            this.lbl1e.Location = new System.Drawing.Point(17, 460);
            this.lbl1e.Name = "lbl1e";
            this.lbl1e.Size = new System.Drawing.Size(100, 15);
            this.lbl1e.TabIndex = 12;
            this.lbl1e.Text = "1e";
            this.lbl1e.Tag = "1e";
                                        this.lbl1e.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1e
            // 
            this.dcim1e.Enabled = true;
            this.dcim1e.Location = new System.Drawing.Point(20, 481);
            this.dcim1e.Name = "dcim1e";
            this.dcim1e.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1e.Size = new System.Drawing.Size(200, 50);
            this.dcim1e.TabIndex = 13;
            this.dcim1e.TabStop = false;
            this.dcim1e.Tag = "1e";
                                        // 
            // cmb1e
            // 
            this.cmb1e.FormattingEnabled = true;
            this.cmb1e.Location = new System.Drawing.Point(20, 535);
            this.cmb1e.Name = "cmb1e";
            this.cmb1e.Size = new System.Drawing.Size(200, 26);
            this.cmb1e.TabIndex = 14;
            this.cmb1e.Tag = "1e";
                                        this.cmb1e.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1f
            // 
            this.lbl1f.AutoSize = true;
            this.lbl1f.Location = new System.Drawing.Point(17, 572);
            this.lbl1f.Name = "lbl1f";
            this.lbl1f.Size = new System.Drawing.Size(100, 15);
            this.lbl1f.TabIndex = 15;
            this.lbl1f.Text = "1f";
            this.lbl1f.Tag = "1f";
                                        this.lbl1f.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1f
            // 
            this.dcim1f.Enabled = true;
            this.dcim1f.Location = new System.Drawing.Point(20, 593);
            this.dcim1f.Name = "dcim1f";
            this.dcim1f.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1f.Size = new System.Drawing.Size(200, 50);
            this.dcim1f.TabIndex = 16;
            this.dcim1f.TabStop = false;
            this.dcim1f.Tag = "1f";
                                        // 
            // cmb1f
            // 
            this.cmb1f.FormattingEnabled = true;
            this.cmb1f.Location = new System.Drawing.Point(20, 647);
            this.cmb1f.Name = "cmb1f";
            this.cmb1f.Size = new System.Drawing.Size(200, 26);
            this.cmb1f.TabIndex = 17;
            this.cmb1f.Tag = "1f";
                                        this.cmb1f.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1g
            // 
            this.lbl1g.AutoSize = true;
            this.lbl1g.Location = new System.Drawing.Point(17, 684);
            this.lbl1g.Name = "lbl1g";
            this.lbl1g.Size = new System.Drawing.Size(100, 15);
            this.lbl1g.TabIndex = 18;
            this.lbl1g.Text = "1g";
            this.lbl1g.Tag = "1g";
                                        this.lbl1g.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1g
            // 
            this.dcim1g.Enabled = true;
            this.dcim1g.Location = new System.Drawing.Point(20, 705);
            this.dcim1g.Name = "dcim1g";
            this.dcim1g.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1g.Size = new System.Drawing.Size(200, 50);
            this.dcim1g.TabIndex = 19;
            this.dcim1g.TabStop = false;
            this.dcim1g.Tag = "1g";
                                        // 
            // cmb1g
            // 
            this.cmb1g.FormattingEnabled = true;
            this.cmb1g.Location = new System.Drawing.Point(20, 759);
            this.cmb1g.Name = "cmb1g";
            this.cmb1g.Size = new System.Drawing.Size(200, 26);
            this.cmb1g.TabIndex = 20;
            this.cmb1g.Tag = "1g";
                                        this.cmb1g.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1h
            // 
            this.lbl1h.AutoSize = true;
            this.lbl1h.Location = new System.Drawing.Point(17, 796);
            this.lbl1h.Name = "lbl1h";
            this.lbl1h.Size = new System.Drawing.Size(100, 15);
            this.lbl1h.TabIndex = 21;
            this.lbl1h.Text = "1h";
            this.lbl1h.Tag = "1h";
                                        this.lbl1h.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1h
            // 
            this.dcim1h.Enabled = true;
            this.dcim1h.Location = new System.Drawing.Point(20, 817);
            this.dcim1h.Name = "dcim1h";
            this.dcim1h.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1h.Size = new System.Drawing.Size(200, 50);
            this.dcim1h.TabIndex = 22;
            this.dcim1h.TabStop = false;
            this.dcim1h.Tag = "1h";
                                        // 
            // cmb1h
            // 
            this.cmb1h.FormattingEnabled = true;
            this.cmb1h.Location = new System.Drawing.Point(20, 871);
            this.cmb1h.Name = "cmb1h";
            this.cmb1h.Size = new System.Drawing.Size(200, 26);
            this.cmb1h.TabIndex = 23;
            this.cmb1h.Tag = "1h";
                                        this.cmb1h.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1i
            // 
            this.lbl1i.AutoSize = true;
            this.lbl1i.Location = new System.Drawing.Point(17, 908);
            this.lbl1i.Name = "lbl1i";
            this.lbl1i.Size = new System.Drawing.Size(100, 15);
            this.lbl1i.TabIndex = 24;
            this.lbl1i.Text = "1i";
            this.lbl1i.Tag = "1i";
                                        this.lbl1i.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1i
            // 
            this.dcim1i.Enabled = true;
            this.dcim1i.Location = new System.Drawing.Point(20, 929);
            this.dcim1i.Name = "dcim1i";
            this.dcim1i.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1i.Size = new System.Drawing.Size(200, 50);
            this.dcim1i.TabIndex = 25;
            this.dcim1i.TabStop = false;
            this.dcim1i.Tag = "1i";
                                        // 
            // cmb1i
            // 
            this.cmb1i.FormattingEnabled = true;
            this.cmb1i.Location = new System.Drawing.Point(20, 983);
            this.cmb1i.Name = "cmb1i";
            this.cmb1i.Size = new System.Drawing.Size(200, 26);
            this.cmb1i.TabIndex = 26;
            this.cmb1i.Tag = "1i";
                                        this.cmb1i.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl1j
            // 
            this.lbl1j.AutoSize = true;
            this.lbl1j.Location = new System.Drawing.Point(17, 1020);
            this.lbl1j.Name = "lbl1j";
            this.lbl1j.Size = new System.Drawing.Size(100, 15);
            this.lbl1j.TabIndex = 27;
            this.lbl1j.Text = "1j";
            this.lbl1j.Tag = "1j";
                                        this.lbl1j.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim1j
            // 
            this.dcim1j.Enabled = true;
            this.dcim1j.Location = new System.Drawing.Point(20, 1041);
            this.dcim1j.Name = "dcim1j";
            this.dcim1j.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim1j.Size = new System.Drawing.Size(200, 50);
            this.dcim1j.TabIndex = 28;
            this.dcim1j.TabStop = false;
            this.dcim1j.Tag = "1j";
                                        // 
            // cmb1j
            // 
            this.cmb1j.FormattingEnabled = true;
            this.cmb1j.Location = new System.Drawing.Point(20, 1095);
            this.cmb1j.Name = "cmb1j";
            this.cmb1j.Size = new System.Drawing.Size(200, 26);
            this.cmb1j.TabIndex = 29;
            this.cmb1j.Tag = "1j";
                                        this.cmb1j.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl2a
            // 
            this.lbl2a.AutoSize = true;
            this.lbl2a.Location = new System.Drawing.Point(17, 1132);
            this.lbl2a.Name = "lbl2a";
            this.lbl2a.Size = new System.Drawing.Size(100, 15);
            this.lbl2a.TabIndex = 30;
            this.lbl2a.Text = "2a";
            this.lbl2a.Tag = "2a";
                                        this.lbl2a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim2a
            // 
            this.dcim2a.Enabled = true;
            this.dcim2a.Location = new System.Drawing.Point(20, 1153);
            this.dcim2a.Name = "dcim2a";
            this.dcim2a.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim2a.Size = new System.Drawing.Size(200, 50);
            this.dcim2a.TabIndex = 31;
            this.dcim2a.TabStop = false;
            this.dcim2a.Tag = "2a";
                                        // 
            // cmb2a
            // 
            this.cmb2a.FormattingEnabled = true;
            this.cmb2a.Location = new System.Drawing.Point(20, 1207);
            this.cmb2a.Name = "cmb2a";
            this.cmb2a.Size = new System.Drawing.Size(200, 26);
            this.cmb2a.TabIndex = 32;
            this.cmb2a.Tag = "2a";
                                        this.cmb2a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl2b
            // 
            this.lbl2b.AutoSize = true;
            this.lbl2b.Location = new System.Drawing.Point(17, 1244);
            this.lbl2b.Name = "lbl2b";
            this.lbl2b.Size = new System.Drawing.Size(100, 15);
            this.lbl2b.TabIndex = 33;
            this.lbl2b.Text = "2b";
            this.lbl2b.Tag = "2b";
                                        this.lbl2b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim2b
            // 
            this.dcim2b.Enabled = true;
            this.dcim2b.Location = new System.Drawing.Point(20, 1265);
            this.dcim2b.Name = "dcim2b";
            this.dcim2b.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim2b.Size = new System.Drawing.Size(200, 50);
            this.dcim2b.TabIndex = 34;
            this.dcim2b.TabStop = false;
            this.dcim2b.Tag = "2b";
                                        // 
            // cmb2b
            // 
            this.cmb2b.FormattingEnabled = true;
            this.cmb2b.Location = new System.Drawing.Point(20, 1319);
            this.cmb2b.Name = "cmb2b";
            this.cmb2b.Size = new System.Drawing.Size(200, 26);
            this.cmb2b.TabIndex = 35;
            this.cmb2b.Tag = "2b";
                                        this.cmb2b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl2c
            // 
            this.lbl2c.AutoSize = true;
            this.lbl2c.Location = new System.Drawing.Point(17, 1356);
            this.lbl2c.Name = "lbl2c";
            this.lbl2c.Size = new System.Drawing.Size(100, 15);
            this.lbl2c.TabIndex = 36;
            this.lbl2c.Text = "2c";
            this.lbl2c.Tag = "2c";
                                        this.lbl2c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim2c
            // 
            this.dcim2c.Enabled = true;
            this.dcim2c.Location = new System.Drawing.Point(20, 1377);
            this.dcim2c.Name = "dcim2c";
            this.dcim2c.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim2c.Size = new System.Drawing.Size(200, 50);
            this.dcim2c.TabIndex = 37;
            this.dcim2c.TabStop = false;
            this.dcim2c.Tag = "2c";
                                        // 
            // cmb2c
            // 
            this.cmb2c.FormattingEnabled = true;
            this.cmb2c.Location = new System.Drawing.Point(20, 1431);
            this.cmb2c.Name = "cmb2c";
            this.cmb2c.Size = new System.Drawing.Size(200, 26);
            this.cmb2c.TabIndex = 38;
            this.cmb2c.Tag = "2c";
                                        this.cmb2c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl2d
            // 
            this.lbl2d.AutoSize = true;
            this.lbl2d.Location = new System.Drawing.Point(17, 1468);
            this.lbl2d.Name = "lbl2d";
            this.lbl2d.Size = new System.Drawing.Size(100, 15);
            this.lbl2d.TabIndex = 39;
            this.lbl2d.Text = "2d";
            this.lbl2d.Tag = "2d";
                                        this.lbl2d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim2d
            // 
            this.dcim2d.Enabled = true;
            this.dcim2d.Location = new System.Drawing.Point(20, 1489);
            this.dcim2d.Name = "dcim2d";
            this.dcim2d.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim2d.Size = new System.Drawing.Size(200, 50);
            this.dcim2d.TabIndex = 40;
            this.dcim2d.TabStop = false;
            this.dcim2d.Tag = "2d";
                                        // 
            // cmb2d
            // 
            this.cmb2d.FormattingEnabled = true;
            this.cmb2d.Location = new System.Drawing.Point(20, 1543);
            this.cmb2d.Name = "cmb2d";
            this.cmb2d.Size = new System.Drawing.Size(200, 26);
            this.cmb2d.TabIndex = 41;
            this.cmb2d.Tag = "2d";
                                        this.cmb2d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl2e
            // 
            this.lbl2e.AutoSize = true;
            this.lbl2e.Location = new System.Drawing.Point(17, 1580);
            this.lbl2e.Name = "lbl2e";
            this.lbl2e.Size = new System.Drawing.Size(100, 15);
            this.lbl2e.TabIndex = 42;
            this.lbl2e.Text = "2e";
            this.lbl2e.Tag = "2e";
                                        this.lbl2e.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim2e
            // 
            this.dcim2e.Enabled = true;
            this.dcim2e.Location = new System.Drawing.Point(20, 1601);
            this.dcim2e.Name = "dcim2e";
            this.dcim2e.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim2e.Size = new System.Drawing.Size(200, 50);
            this.dcim2e.TabIndex = 43;
            this.dcim2e.TabStop = false;
            this.dcim2e.Tag = "2e";
                                        // 
            // cmb2e
            // 
            this.cmb2e.FormattingEnabled = true;
            this.cmb2e.Location = new System.Drawing.Point(20, 1655);
            this.cmb2e.Name = "cmb2e";
            this.cmb2e.Size = new System.Drawing.Size(200, 26);
            this.cmb2e.TabIndex = 44;
            this.cmb2e.Tag = "2e";
                                        this.cmb2e.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl3a
            // 
            this.lbl3a.AutoSize = true;
            this.lbl3a.Location = new System.Drawing.Point(17, 1692);
            this.lbl3a.Name = "lbl3a";
            this.lbl3a.Size = new System.Drawing.Size(100, 15);
            this.lbl3a.TabIndex = 45;
            this.lbl3a.Text = "3a";
            this.lbl3a.Tag = "3a";
                                        this.lbl3a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim3a
            // 
            this.dcim3a.Enabled = true;
            this.dcim3a.Location = new System.Drawing.Point(20, 1713);
            this.dcim3a.Name = "dcim3a";
            this.dcim3a.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim3a.Size = new System.Drawing.Size(200, 50);
            this.dcim3a.TabIndex = 46;
            this.dcim3a.TabStop = false;
            this.dcim3a.Tag = "3a";
                                        // 
            // cmb3a
            // 
            this.cmb3a.FormattingEnabled = true;
            this.cmb3a.Location = new System.Drawing.Point(20, 1767);
            this.cmb3a.Name = "cmb3a";
            this.cmb3a.Size = new System.Drawing.Size(200, 26);
            this.cmb3a.TabIndex = 47;
            this.cmb3a.Tag = "3a";
                                        this.cmb3a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl3b
            // 
            this.lbl3b.AutoSize = true;
            this.lbl3b.Location = new System.Drawing.Point(17, 1804);
            this.lbl3b.Name = "lbl3b";
            this.lbl3b.Size = new System.Drawing.Size(100, 15);
            this.lbl3b.TabIndex = 48;
            this.lbl3b.Text = "3b";
            this.lbl3b.Tag = "3b";
                                        this.lbl3b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim3b
            // 
            this.dcim3b.Enabled = true;
            this.dcim3b.Location = new System.Drawing.Point(20, 1825);
            this.dcim3b.Name = "dcim3b";
            this.dcim3b.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim3b.Size = new System.Drawing.Size(200, 50);
            this.dcim3b.TabIndex = 49;
            this.dcim3b.TabStop = false;
            this.dcim3b.Tag = "3b";
                                        // 
            // cmb3b
            // 
            this.cmb3b.FormattingEnabled = true;
            this.cmb3b.Location = new System.Drawing.Point(20, 1879);
            this.cmb3b.Name = "cmb3b";
            this.cmb3b.Size = new System.Drawing.Size(200, 26);
            this.cmb3b.TabIndex = 50;
            this.cmb3b.Tag = "3b";
                                        this.cmb3b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(17, 1916);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(100, 15);
            this.lbl4.TabIndex = 51;
            this.lbl4.Text = "4";
            this.lbl4.Tag = "4";
                                        this.lbl4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim4
            // 
            this.dcim4.Enabled = true;
            this.dcim4.Location = new System.Drawing.Point(20, 1937);
            this.dcim4.Name = "dcim4";
            this.dcim4.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim4.Size = new System.Drawing.Size(200, 50);
            this.dcim4.TabIndex = 52;
            this.dcim4.TabStop = false;
            this.dcim4.Tag = "4";
                                        // 
            // cmb4
            // 
            this.cmb4.FormattingEnabled = true;
            this.cmb4.Location = new System.Drawing.Point(20, 1991);
            this.cmb4.Name = "cmb4";
            this.cmb4.Size = new System.Drawing.Size(200, 26);
            this.cmb4.TabIndex = 53;
            this.cmb4.Tag = "4";
                                        this.cmb4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl5a
            // 
            this.lbl5a.AutoSize = true;
            this.lbl5a.Location = new System.Drawing.Point(17, 2028);
            this.lbl5a.Name = "lbl5a";
            this.lbl5a.Size = new System.Drawing.Size(100, 15);
            this.lbl5a.TabIndex = 54;
            this.lbl5a.Text = "5a";
            this.lbl5a.Tag = "5a";
                                        this.lbl5a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim5a
            // 
            this.dcim5a.Enabled = true;
            this.dcim5a.Location = new System.Drawing.Point(20, 2049);
            this.dcim5a.Name = "dcim5a";
            this.dcim5a.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim5a.Size = new System.Drawing.Size(200, 50);
            this.dcim5a.TabIndex = 55;
            this.dcim5a.TabStop = false;
            this.dcim5a.Tag = "5a";
                                        // 
            // cmb5a
            // 
            this.cmb5a.FormattingEnabled = true;
            this.cmb5a.Location = new System.Drawing.Point(20, 2103);
            this.cmb5a.Name = "cmb5a";
            this.cmb5a.Size = new System.Drawing.Size(200, 26);
            this.cmb5a.TabIndex = 56;
            this.cmb5a.Tag = "5a";
                                        this.cmb5a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl5b
            // 
            this.lbl5b.AutoSize = true;
            this.lbl5b.Location = new System.Drawing.Point(17, 2140);
            this.lbl5b.Name = "lbl5b";
            this.lbl5b.Size = new System.Drawing.Size(100, 15);
            this.lbl5b.TabIndex = 57;
            this.lbl5b.Text = "5b";
            this.lbl5b.Tag = "5b";
                                        this.lbl5b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim5b
            // 
            this.dcim5b.Enabled = true;
            this.dcim5b.Location = new System.Drawing.Point(20, 2161);
            this.dcim5b.Name = "dcim5b";
            this.dcim5b.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim5b.Size = new System.Drawing.Size(200, 50);
            this.dcim5b.TabIndex = 58;
            this.dcim5b.TabStop = false;
            this.dcim5b.Tag = "5b";
                                        // 
            // cmb5b
            // 
            this.cmb5b.FormattingEnabled = true;
            this.cmb5b.Location = new System.Drawing.Point(20, 2215);
            this.cmb5b.Name = "cmb5b";
            this.cmb5b.Size = new System.Drawing.Size(200, 26);
            this.cmb5b.TabIndex = 59;
            this.cmb5b.Tag = "5b";
                                        this.cmb5b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Location = new System.Drawing.Point(17, 2252);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(100, 15);
            this.lbl6.TabIndex = 60;
            this.lbl6.Text = "6";
            this.lbl6.Tag = "6";
                                        this.lbl6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim6
            // 
            this.dcim6.Enabled = true;
            this.dcim6.Location = new System.Drawing.Point(20, 2273);
            this.dcim6.Name = "dcim6";
            this.dcim6.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim.OcxState")));
            this.dcim6.Size = new System.Drawing.Size(200, 50);
            this.dcim6.TabIndex = 61;
            this.dcim6.TabStop = false;
            this.dcim6.Tag = "6";
                                        // 
            // cmb6
            // 
            this.cmb6.FormattingEnabled = true;
            this.cmb6.Location = new System.Drawing.Point(20, 2327);
            this.cmb6.Name = "cmb6";
            this.cmb6.Size = new System.Drawing.Size(200, 26);
            this.cmb6.TabIndex = 62;
            this.cmb6.Tag = "6";
                                        this.cmb6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Controls.Add(this.lbl1a);
                                        this.Controls.Add(this.dcim1a);
                                        this.Controls.Add(this.cmb1a);
                                        this.Controls.Add(this.lbl1b);
                                        this.Controls.Add(this.dcim1b);
                                        this.Controls.Add(this.cmb1b);
                                        this.Controls.Add(this.lbl1c);
                                        this.Controls.Add(this.dcim1c);
                                        this.Controls.Add(this.cmb1c);
                                        this.Controls.Add(this.lbl1d);
                                        this.Controls.Add(this.dcim1d);
                                        this.Controls.Add(this.cmb1d);
                                        this.Controls.Add(this.lbl1e);
                                        this.Controls.Add(this.dcim1e);
                                        this.Controls.Add(this.cmb1e);
                                        this.Controls.Add(this.lbl1f);
                                        this.Controls.Add(this.dcim1f);
                                        this.Controls.Add(this.cmb1f);
                                        this.Controls.Add(this.lbl1g);
                                        this.Controls.Add(this.dcim1g);
                                        this.Controls.Add(this.cmb1g);
                                        this.Controls.Add(this.lbl1h);
                                        this.Controls.Add(this.dcim1h);
                                        this.Controls.Add(this.cmb1h);
                                        this.Controls.Add(this.lbl1i);
                                        this.Controls.Add(this.dcim1i);
                                        this.Controls.Add(this.cmb1i);
                                        this.Controls.Add(this.lbl1j);
                                        this.Controls.Add(this.dcim1j);
                                        this.Controls.Add(this.cmb1j);
                                        this.Controls.Add(this.lbl2a);
                                        this.Controls.Add(this.dcim2a);
                                        this.Controls.Add(this.cmb2a);
                                        this.Controls.Add(this.lbl2b);
                                        this.Controls.Add(this.dcim2b);
                                        this.Controls.Add(this.cmb2b);
                                        this.Controls.Add(this.lbl2c);
                                        this.Controls.Add(this.dcim2c);
                                        this.Controls.Add(this.cmb2c);
                                        this.Controls.Add(this.lbl2d);
                                        this.Controls.Add(this.dcim2d);
                                        this.Controls.Add(this.cmb2d);
                                        this.Controls.Add(this.lbl2e);
                                        this.Controls.Add(this.dcim2e);
                                        this.Controls.Add(this.cmb2e);
                                        this.Controls.Add(this.lbl3a);
                                        this.Controls.Add(this.dcim3a);
                                        this.Controls.Add(this.cmb3a);
                                        this.Controls.Add(this.lbl3b);
                                        this.Controls.Add(this.dcim3b);
                                        this.Controls.Add(this.cmb3b);
                                        this.Controls.Add(this.lbl4);
                                        this.Controls.Add(this.dcim4);
                                        this.Controls.Add(this.cmb4);
                                        this.Controls.Add(this.lbl5a);
                                        this.Controls.Add(this.dcim5a);
                                        this.Controls.Add(this.cmb5a);
                                        this.Controls.Add(this.lbl5b);
                                        this.Controls.Add(this.dcim5b);
                                        this.Controls.Add(this.cmb5b);
                                        this.Controls.Add(this.lbl6);
                                        this.Controls.Add(this.dcim6);
                                        this.Controls.Add(this.cmb6);
                             
            this.Name = "Survey_Page1";
            this.Size = new System.Drawing.Size(246, 2352);
                                ((System.ComponentModel.ISupportInitialize)(this.dcim1a)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1b)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1c)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1d)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1e)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1f)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1g)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1h)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1i)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim1j)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim2a)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim2b)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim2c)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim2d)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim2e)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim3a)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim3b)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim4)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim5a)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim5b)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim6)).EndInit();
                        
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lbl1a;
                                private AxDCIMAGELib.AxDcimage dcim1a;
                                private System.Windows.Forms.ComboBox cmb1a;
                                private System.Windows.Forms.Label lbl1b;
                                private AxDCIMAGELib.AxDcimage dcim1b;
                                private System.Windows.Forms.ComboBox cmb1b;
                                private System.Windows.Forms.Label lbl1c;
                                private AxDCIMAGELib.AxDcimage dcim1c;
                                private System.Windows.Forms.ComboBox cmb1c;
                                private System.Windows.Forms.Label lbl1d;
                                private AxDCIMAGELib.AxDcimage dcim1d;
                                private System.Windows.Forms.ComboBox cmb1d;
                                private System.Windows.Forms.Label lbl1e;
                                private AxDCIMAGELib.AxDcimage dcim1e;
                                private System.Windows.Forms.ComboBox cmb1e;
                                private System.Windows.Forms.Label lbl1f;
                                private AxDCIMAGELib.AxDcimage dcim1f;
                                private System.Windows.Forms.ComboBox cmb1f;
                                private System.Windows.Forms.Label lbl1g;
                                private AxDCIMAGELib.AxDcimage dcim1g;
                                private System.Windows.Forms.ComboBox cmb1g;
                                private System.Windows.Forms.Label lbl1h;
                                private AxDCIMAGELib.AxDcimage dcim1h;
                                private System.Windows.Forms.ComboBox cmb1h;
                                private System.Windows.Forms.Label lbl1i;
                                private AxDCIMAGELib.AxDcimage dcim1i;
                                private System.Windows.Forms.ComboBox cmb1i;
                                private System.Windows.Forms.Label lbl1j;
                                private AxDCIMAGELib.AxDcimage dcim1j;
                                private System.Windows.Forms.ComboBox cmb1j;
                                private System.Windows.Forms.Label lbl2a;
                                private AxDCIMAGELib.AxDcimage dcim2a;
                                private System.Windows.Forms.ComboBox cmb2a;
                                private System.Windows.Forms.Label lbl2b;
                                private AxDCIMAGELib.AxDcimage dcim2b;
                                private System.Windows.Forms.ComboBox cmb2b;
                                private System.Windows.Forms.Label lbl2c;
                                private AxDCIMAGELib.AxDcimage dcim2c;
                                private System.Windows.Forms.ComboBox cmb2c;
                                private System.Windows.Forms.Label lbl2d;
                                private AxDCIMAGELib.AxDcimage dcim2d;
                                private System.Windows.Forms.ComboBox cmb2d;
                                private System.Windows.Forms.Label lbl2e;
                                private AxDCIMAGELib.AxDcimage dcim2e;
                                private System.Windows.Forms.ComboBox cmb2e;
                                private System.Windows.Forms.Label lbl3a;
                                private AxDCIMAGELib.AxDcimage dcim3a;
                                private System.Windows.Forms.ComboBox cmb3a;
                                private System.Windows.Forms.Label lbl3b;
                                private AxDCIMAGELib.AxDcimage dcim3b;
                                private System.Windows.Forms.ComboBox cmb3b;
                                private System.Windows.Forms.Label lbl4;
                                private AxDCIMAGELib.AxDcimage dcim4;
                                private System.Windows.Forms.ComboBox cmb4;
                                private System.Windows.Forms.Label lbl5a;
                                private AxDCIMAGELib.AxDcimage dcim5a;
                                private System.Windows.Forms.ComboBox cmb5a;
                                private System.Windows.Forms.Label lbl5b;
                                private AxDCIMAGELib.AxDcimage dcim5b;
                                private System.Windows.Forms.ComboBox cmb5b;
                                private System.Windows.Forms.Label lbl6;
                                private AxDCIMAGELib.AxDcimage dcim6;
                                private System.Windows.Forms.ComboBox cmb6;
                        
    }
}
                