//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;
using System.Data.OleDb;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace DotEditPanels
{
    public partial class E_MainPage : dotPanelBase
    {
        XmlDocument Edelweiss = new XmlDocument();
        OleDbConnection con;
        public E_MainPage()
        {
            InitializeComponent();
        }

        private void E_MainPage_Load(object sender, EventArgs e)
        {

        }
        public override bool LoadData(XmlDocument xPage)
        {   
            Hidefieldsbasedonfunction();
            Documenttitle();
            try
            {
                this.cbEntity.Text = this.dcedEntity.CtlText;
                this.cbFunction.Text = this.dcedFunction.CtlText;
                this.cbSubfunction.Text = this.dcedSubFunction.CtlText;
                this.dcedFunction.Focus(); this.dcedEntity.Focus();
                this.dcedSubFunction.Focus();
                this.dcedState.Focus();
                this.dcedState.Visible = false;
                Documenttitle();
                if (this.dcedDate_Of_Booking.CtlText != string.Empty)
                {
                    SeperateDataofBooking();
                }
                try
                {
                    if (this.dcedState.CtlText != string.Empty)
                    {
                        State();

                    }
                    Documenttitle();
                    this.dcedState.Visible = false;
                }
                catch (Exception ex)
                {
                    dcTask.WriteLog("Error in LoadXML:" + ex);
                   
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5,"Error is:" +ex);
            }
            this.dcedReferenceNumber_Name.Focus();
            this.dcedReferenceNumber_Name.Visible = true;
            this.dcedDocument_Title.Visible = true;
            Documenttitle();
            this.dcedDocument_Title.Visible = true;
            Hidefieldsbasedonfunction();
            this.cbEntity.Focus();
            this.dcedSubFunction.Focus();
            this.dcedDocument_Title.Focus();
            SetStyle(ControlStyles.Selectable, false);
            dcTask.WriteLog(5,"LoadXML is Successful");
            return base.LoadData(xPage);
        }
        public override bool SaveData(XmlDocument xPage)
        {
            bool Result = base.StartBatch();
            var dcapp = new DCAppleLib.DirectAppList();
            try
            {
                this.cbFunction.Text = this.dcedFunction.CtlText;
                this.cbSubfunction.Text = this.dcedSubFunction.CtlText;
                this.cbEntity.Text = this.dcedEntity.CtlText;
                this.dcedState.Focus();
                this.dcedState.Visible = false;
                dcedFin_Year.Focus();
                dcedDate_Of_Booking.Focus();
                dcedInvoice_Date.Focus();
                dcedDocument_Title.Focus();
                Documenttitle();
                this.dcedReferenceNumber_Name.Focus();
                this.dcedReferenceNumber_Name.Visible = true;
                this.dcedDocument_Title.Visible = true;
                Documenttitle();
                this.dcedDocument_Title.Visible = true;
                Hidefieldsbasedonfunction();
                this.cbEntity.Focus();
                this.dcedSubFunction.Focus();
                this.dcedDocument_Title.Focus();
                SetStyle(ControlStyles.Selectable, false);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Error in SaveData:" + ex);
            }
            return base.SaveData(xPage);
        }
        public void Hidefieldsbasedonfunction()
        {
            try
            {
                this.dcedMonth.Visible = false; this.lblMonth.Visible = false;
                lblState.Visible = false; dcedState.Visible = false;
                if (dcedFunction.CtlText != "")
                {
                    if (dcedFunction.CtlText == "Accounts Payable" || dcedFunction.CtlText == "Fixed Assets")
                    {
                        dcedBill_To_Fields.Visible = false; lblBill_To_Fields.Visible = false;
                        dcedSerial_Number.Visible = false; lblSerial_Number.Visible = false;
                        dcedTDS_Amount.Visible = true; lblTDS_Amount.Visible = true;
                        dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true; dtp_InvoiceDate.Visible = true;
                        dcedRCM_Flag.Visible = true; lblRCM_Flag.Visible = true;
                        dcedReferenceNumber_Name.Visible = true; lblReferenceNumber_Name.Visible = true;
                        this.dcedParty_GST_Number.Visible = true; this.lblParty_GST_Number.Visible = true;
                        dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true; dtp_InvoiceDate.Visible = true;
                        lblVendor_Name.Text = "Vendor Name*";
                        lblState.Visible = false; dcedState.Visible = false;
                        lblSerial_Number.Text = "Serial Number *";
                        lblDate_Of_Booking.Text = "Date Of Booking *";
                        lblFunction.Text = "Function *";
                        lblFin_Year.Text = "Fin Year *";
                        lblEntity_GST_Number.Text = "Entity GST Number *";
                        lblVendor_Name.Text = "Vendor Name *";
                        lblInvoice_Amount.Text = "Invoice Amount *";
                        lblInvoice_Date.Text = "Invoice Date *";
                    }
                    else if (dcedFunction.CtlText == "Accounts Receivable")
                    {
                        dcedTDS_Amount.Visible = false; lblTDS_Amount.Visible = false;
                        dcedRCM_Flag.Visible = false; lblRCM_Flag.Visible = false;
                        dcedReferenceNumber_Name.Visible = false; lblReferenceNumber_Name.Visible = false;
                        dcedBill_To_Fields.Visible = true; lblBill_To_Fields.Visible = true;
                        dcedSerial_Number.Visible = true; lblSerial_Number.Visible = true;
                        dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true; dtp_InvoiceDate.Visible = true;
                        lblVendor_Name.Text = "Customer Name";
                        this.dcedParty_GST_Number.Visible = true; lblParty_GST_Number.Visible = true;
                        lblState.Visible = false; dcedState.Visible = false;
                        lblFunction.Text = "Function *";
                        lblSerial_Number.Text = "Serial Number *";
                        lblDate_Of_Booking.Text = "Date Of Booking *"; lblFin_Year.Text = "Fin Year *";
                        lblEntity_GST_Number.Text = "Entity GST Number *";
                        lblVendor_Name.Text = "Vendor Name *";
                        lblInvoice_Amount.Text = "Invoice Amount *";
                        lblInvoice_Date.Text = "Invoice Date *";
                        if (this.dcedSubFunction.CtlText == "Non-INR Invoice")
                        {
                            this.dcedParty_GST_Number.Visible = false;
                            this.lblParty_GST_Number.Visible = false;
                            dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true; dtp_InvoiceDate.Visible = true;
                            lblFunction.Text = "Function";
                            lblSerial_Number.Text = "Serial Number";
                            lblDate_Of_Booking.Text = "Date Of Booking";
                            lblFin_Year.Text = "Fin Year";
                            lblEntity_GST_Number.Text = "Entity GST Number";
                            lblVendor_Name.Text = "Vendor Name";
                            lblInvoice_Amount.Text = "Invoice Amount";
                            lblInvoice_Date.Text = "Invoice Date";
                        }
                    }
                    else
                    {
                        this.dcedParty_GST_Number.Visible = true; lblParty_GST_Number.Visible = true;
                        dcedBill_To_Fields.Visible = false; lblBill_To_Fields.Visible = false;
                        dcedRCM_Flag.Visible = false; lblRCM_Flag.Visible = false;
                        dtp_InvoiceDate.Visible = false;
                        dcedTDS_Amount.Visible = false; lblTDS_Amount.Visible = false;
                        dcedReferenceNumber_Name.Visible = true; lblReferenceNumber_Name.Visible = true;
                        dcedSerial_Number.Visible = false; lblSerial_Number.Visible = false;
                        dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true;
                        lblVendor_Name.Text = "Vendor Name";
                        lblState.Visible = false; dcedState.Visible = false;
                        lblFin_Year.Text = "Fin Year *";
                        lblEntity_GST_Number.Text = "Entity GST Number";
                        lblInvoice_Amount.Text = "Invoice Amount";
                        lblInvoice_Date.Text = "Invoice Date";
                    }
                }
                else
                {
                    dcedBill_To_Fields.Visible = false; lblBill_To_Fields.Visible = false;
                    dcedRCM_Flag.Visible = false; lblRCM_Flag.Visible = false;
                    dcedInvoice_Date.Visible = false; lblInvoice_Date.Visible = false;
                    dtp_InvoiceDate.Visible = false;
                    dcedTDS_Amount.Visible = false; lblTDS_Amount.Visible = false;
                    lblState.Visible = false; dcedState.Visible = false;
                    dcedInvoice_Date.Visible = true; lblInvoice_Date.Visible = true; dtp_InvoiceDate.Visible = true;
                }
                dcTask.WriteLog(5, "Hidefieldsbasedonfunction is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(" Error in Hidefieldsbasedonfunction:" + ex);

            }

        }
       
        public override bool StartBatch()
        {
            bool Result = base.StartBatch();
            var dcapp = new DCAppleLib.DirectAppList();
            try
            {
                dcTask.WriteLog(5, "Entering into StartBatch");
                cbFunction.Items.Clear();
                cbEntity.Items.Clear();
                this.cbEntity.Text = this.dcedEntity.CtlText;
                this.cbFunction.Text = this.dcedFunction.CtlText;
                this.cbSubfunction.Text = dcedSubFunction.CtlText;
                if (this.dcedDate_Of_Booking.CtlText != string.Empty)
                {
                    SeperateDataofBooking();
                }
                Hidefieldsbasedonfunction();
                dcTask.WriteLog(5, "Entering into getxmlPath");
                getxmlpath();
                dcTask.WriteLog(5, "getxmlPath is Successful");
                try
                {
                    dcTask.WriteLog(5, "binding the ENTITY_SELECT");
                    DataTable dtEntity = binddata("ENTITY_SELECT");
                    dcTask.WriteLog(5, "binding the FUNCTION_SELECT");
                    DataTable dtFunction = binddata("FUNCTION_SELECT");
                    dcTask.WriteLog(5, "binding the SUBFUNCTION_SELECT");
                    DataTable dtSubFunction = binddata("SUBFUNCTION_SELECT", this.cbFunction.Text);
                    dcTask.WriteLog(5, "Filling the ENTITY");
                    fill_Entity(dtEntity);
                    dcTask.WriteLog(5, "fill_Entity is successful");
                    dcTask.WriteLog(5, "Filling the Function");
                    fill_Function(dtFunction);
                    dcTask.WriteLog(5, "fill_Function is successful");
                    dcTask.WriteLog(5, "Filling the Subfunction");
                    fill_Subfunction(dtSubFunction);
                    dcTask.WriteLog(5, "fill_SubFunction is successful");
                    if (dcedFunction.CtlText == "Accounts Receivable")
                    {

                    }

                    if (this.dcedState.CtlText != string.Empty)
                    {
                        State();
                    }
                    Documenttitle();
                    this.dcedState.Visible = false;
                }

                catch (Exception ex)
                {
                    dcTask.WriteLog(5, " Error is :" + ex);
                    this.dcedState.Visible = false;
                }
                this.dcedDocument_Title.Focus();
                this.dcedState.Visible = false;
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, " Error in StartBatch:" + ex);
                this.dcedState.Visible = false;
            }
            dcTask.WriteLog(5, "StartBatch is Successful");
            return Result;

        }
        
        void fill_Entity(DataTable dtEntity)
        {
            try
            {
                DataRow rowVendorname = dtEntity.NewRow();
                rowVendorname["ENTITY"] = "SELECT";
                dtEntity.Rows.InsertAt(rowVendorname, 0);
                cbEntity.Items.Clear();
                List<String> lstFirst = new List<string>();
                foreach (DataRow row in dtEntity.Rows)
                {
                    lstFirst.Add(row["ENTITY"].ToString());
                }
                this.cbEntity.Items.AddRange(lstFirst.ToArray());
                this.cbEntity.AutoCompleteMode = AutoCompleteMode.Suggest;
                this.cbEntity.AutoCompleteSource = AutoCompleteSource.ListItems;
                dcTask.WriteLog(5, "fill_Entity is Done");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Binding Entity:" + ex);
            }
        }
        void fill_Function(DataTable dtFunction)
        {
            try
            {
                DataRow rowVendorname = dtFunction.NewRow();
                rowVendorname["FUNCTION"] = "SELECT";
                dtFunction.Rows.InsertAt(rowVendorname, 0);

                cbFunction.Items.Clear();
                List<String> lstfunction = new List<string>();
                foreach (DataRow row in dtFunction.Rows)
                {
                    lstfunction.Add(row["FUNCTION"].ToString());

                }
                this.cbFunction.Items.AddRange(lstfunction.ToArray());
                this.cbFunction.AutoCompleteMode = AutoCompleteMode.Suggest;
                this.cbFunction.AutoCompleteSource = AutoCompleteSource.ListItems;
                dcTask.WriteLog(5, "fill_Function is Done");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Binding the Function:" + ex);
            }

        }

        void fill_Subfunction(DataTable dtSubFunction)
        {
            try
            {
                DataRow rowsubfunction = dtSubFunction.NewRow();
                rowsubfunction["SUBFUNCTION"] = "SELECT";
                dtSubFunction.Rows.InsertAt(rowsubfunction, 0);
                cbSubfunction.Items.Clear();
                List<String> lstdoctype = new List<string>();
                foreach (DataRow row in dtSubFunction.Rows)
                {
                    lstdoctype.Add(row["SUBFUNCTION"].ToString());

                }

                this.cbSubfunction.Items.AddRange(lstdoctype.ToArray());
                dcTask.WriteLog(5, "fill_SubFunction is Done");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Binding DocType: " + ex.Message + "  Details: " + ex.ToString());
            }
        }
        public void State()
        {
            try
            {
                string str = this.dcedState.CtlText;
                string[] str1 = str.Select(x => x.ToString()).ToArray();
                string st = null;
                string str2 = null;
                for (int i = 0; i < str1.Length; i++)
                {
                    st = null;
                    if ((char.IsDigit(str[0]) == true && (char.IsDigit(str[1])) == true))
                    {
                        this.dcedState.Visible = true;
                        dcTask.WriteLog(5, "Binding the STATE in StartBatch");
                        this.dcedState.CtlText = bindStatedata("STATE", this.dcedState.CtlText).ToString();
                        dcTask.WriteLog(5, "bindStatedata in StartBatch is Successful");
                        this.dcedState.Visible = false;
                        str = this.dcedState.CtlText;
                        str1 = str.Select(x => x.ToString()).ToArray();
                    }
                    else if ((char.IsDigit(str[0]) == true))
                    {
                        this.dcedState.Visible = true;
                        this.dcedState.CtlText = str[0].ToString();
                        dcTask.WriteLog(5, "Binding the STATE in StartBatch:");
                        this.dcedState.CtlText = bindStatedata("STATE", this.dcedState.CtlText).ToString();
                        dcTask.WriteLog(5, "bindStatedata in StartBatch is Successful:");
                        this.dcedState.Focus();
                        this.dcedState.Visible = false;
                        str = this.dcedState.CtlText;
                        str1 = str.Select(x => x.ToString()).ToArray();
                        this.dcedEntity_GST_Number.Focus();
                    }
                }
                this.dcedState.Visible = true;
                this.dcedState.Focus();
                this.dcedState.Visible = false;
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("State Error is:" + ex.Message);
            }
            
        }
        public void SeperateDataofBooking()
        {
            this.dcedDate_Of_Booking.Visible = true;
            this.dcedFin_Year.Visible = true;
            string DateofBooking = this.dcedDate_Of_Booking.CtlText;
            dcTask.WriteLog(5, "Splitting the Date");
            string[] datearray = DateofBooking.Split('/');
            this.dcedFin_Year.CtlText = datearray[2].ToString();
            this.dcedFin_Year.Focus();
            if (this.dcedFin_Year.CtlText.Length == 4)
            {
                int Finyear = Convert.ToInt32(this.dcedFin_Year.CtlText);
                string Finyear1 = (Finyear + 1).ToString();
                var result = Finyear1.Substring(Finyear1.Length - 2);
                this.dcedFin_Year.CtlText = this.dcedFin_Year.CtlText + "-" + result;
            }
            this.dcedFin_Year.Focus();
            this.dcedDate_Of_Booking.Focus();
            dcTask.WriteLog(5, "Changed the Fin_Year");
        }
        public DataTable binddata(string strxmlvalue, string strinputvalue)
        {
            DataTable dt = new DataTable();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                dcTask.WriteLog(5, "Connection is opened");
            }
            try
            {
                dcTask.WriteLog(5, "binddata getXMLvalues");
                string command = getXMLvalues(strxmlvalue);
                command = command.Replace(":SUBFUNCTION", strinputvalue);
                OleDbCommand cmd = new OleDbCommand(command, con);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                dcTask.WriteLog(5, "binddata is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in binddata OverLoad: " + ex.Message + "  Details: " + ex.ToString());
            }
            return dt;
        }
        public string getXMLvalues(string strXMLvalues)
        {
            string cs = string.Empty;
            try
            {
                dcTask.WriteLog(5, "Connection string strXMLvalue:" + strXMLvalues); 
                XmlNode Cs_list = Edelweiss.SelectSingleNode("/configuration/DB/setting[@name = '" + strXMLvalues + "']");
                cs = Cs_list.InnerText.ToString();
                dcTask.WriteLog(5, "Connection string CS is" + cs); 
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Getting Connection String:" + ex);
            }
            dcTask.WriteLog(5, "Connection string Done"); 
            return cs;
        }
        public void Documenttitle()
        {
            try
            {
                string DateofBooking = this.dcedDate_Of_Booking.CtlText;
                string DOB = DateofBooking.Replace("/", string.Empty);
                if (dcedFunction.CtlText == "Fixed Assets")
                {
                    this.dcedDocument_Title.CtlText = this.dcedReferenceNumber_Name.CtlText + "|" + this.dcedEntity.CtlText + "|" + this.dcedState.CtlText + "|" + dcedSubFunction.CtlText + "|" + DOB;
                    dcTask.WriteLog(5, "Document Title Generated Successfully" + dcedDocument_Title.CtlText); 
                }
                else if (dcedFunction.CtlText == "Accounts Receivable")
                {

                    dcedDocument_Title.CtlText = dcedSerial_Number.CtlText + "|" + dcedEntity.CtlText + "|" + this.dcedState.CtlText + "|" + dcedSubFunction.CtlText + "|" + DOB;
                    dcTask.WriteLog(5, "Document Title Generated Successfully" + dcedDocument_Title.CtlText); 
                }
                else
                {
                    this.dcedDocument_Title.CtlText = this.dcedReferenceNumber_Name.CtlText + "|" + this.dcedEntity.CtlText + "|" + this.dcedState.CtlText + "|" + DOB;
                    dcTask.WriteLog(5, "Document Title Generated Successfully" + dcedDocument_Title.CtlText); 
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Documenttitle:" + ex);
            }

        }
        public void getxmlpath()
        {
            try
            {
               string configurationFilePath = "C:\\Edel_E_config.xml";
                Edelweiss.Load(configurationFilePath);
                con = new OleDbConnection(getXMLvalues("CONNECTION_STRING"));
                dcTask.WriteLog(5, "Con is:" + con);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Getting XML Path:" + ex);
            }
        }
        public DataTable binddata(string strxmlvalue)
        {
            DataTable dt = new DataTable();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                dcTask.WriteLog(5, "connection is Opened.");
            }
            try
            {
                string command = getXMLvalues(strxmlvalue);
                OleDbCommand cmd = new OleDbCommand(command, con);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                dcTask.WriteLog(5, "binddata is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, " Error in Binding the Data:" + ex);
            }
            return dt;

        }
        public string bindStatedata(string strxmlvalue, string strinputvalue)
        {
            string StateCode = null;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                dcTask.WriteLog(5, "connection is Opened for BindStatedata");
            }
            try
            {
                string command = getXMLvalues(strxmlvalue);
                command = command.Replace(":STATECODE", strinputvalue);
                OleDbCommand cmd = new OleDbCommand(command, con);
                StateCode = cmd.ExecuteScalar().ToString();
                con.Close();
                dcTask.WriteLog(5, "bindstatedata is Successful");
                dcTask.WriteLog(5, "State is:" + StateCode);
                return StateCode;
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in bindStatedata OverLoad: " + ex.Message + "  Details: " + ex.ToString());
            }
            return StateCode;
        }
        private void cbEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cbEntity.Text != "SELECT")
                {
                    this.dcedEntity.Visible = true;
                    this.dcedEntity.CtlText = this.cbEntity.Text;
                    this.dcedEntity.Focus();
                    Documenttitle();
                }
                else if (cbEntity.Text == "SELECT")
                {
                    this.dcedEntity.Visible = true;
                    this.dcedEntity.CtlText = string.Empty;
                    this.dcedEntity.Focus();
                }
                this.dcedDocument_Title.Focus();
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Entity_SelectedIndexChanged:" + ex);
            }
        }
        private void cbFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cbFunction.Text != "SELECT")
                {
                    this.dcedFunction.Visible = true;
                    this.dcedFunction.CtlText = this.cbFunction.Text;
                    this.dcedFunction.Focus();
                    Hidefieldsbasedonfunction();
                    if (dcedFunction.CtlText == "Accounts Receivable")
                    {
                        this.dcedInvoice_Date.CtlText = this.dcedDate_Of_Booking.CtlText;
                        dcedSubFunction.Visible = true;
                        cbSubfunction.Text = string.Empty;
                        cbSubfunction.Items.Clear();
                        this.dcedSubFunction.Focus();
                        dcTask.WriteLog(5, "Binding the Subfunction based on function" + dcedFunction.CtlText);
                        DataTable dtSubFunction = binddata("SUBFUNCTION_SELECT", this.cbFunction.Text);
                        dcTask.WriteLog(5, "Binding the Subfunction is Successful");
                        dcTask.WriteLog(5, "Filling the Subfunction");
                        fill_Subfunction(dtSubFunction);
                        dcTask.WriteLog(5, "Fill_SubFunction is Done");
                        this.cbSubfunction.SelectedIndex = 0;
                        Documenttitle();
                    }
                    else if (dcedFunction.CtlText == "Fixed Assets")
                    {
                        dcedSubFunction.Visible = true;
                        cbSubfunction.Items.Clear();
                        dcedSubFunction.CtlText = "Fixed Asset Voucher";
                        cbSubfunction.Text = dcedSubFunction.CtlText;
                        this.dcedSubFunction.Focus();
                        dcTask.WriteLog(5, "Binding the Subfunction based on function" + dcedFunction.CtlText);
                        DataTable dtSubFunction = binddata("SUBFUNCTION_SELECT", this.cbFunction.Text);
                        dcTask.WriteLog(5, "Binding the Subfunction is Successful");
                        dcTask.WriteLog(5, "Filling the Subfunction");
                        fill_Subfunction(dtSubFunction);
                        dcTask.WriteLog(5, "Fill_SubFunction is Done");
                        this.cbSubfunction.SelectedIndex = 1;
                        Documenttitle();
                    }
                    else if (dcedFunction.CtlText == "Accounts Payable")
                    {
                        dcedSubFunction.Visible = true;
                        cbSubfunction.Items.Clear();
                        dcedSubFunction.CtlText = "AP Voucher";
                        this.dcedSubFunction.Focus();
                        dcTask.WriteLog(5, "Binding the Subfunction based on function" + dcedFunction.CtlText);
                        DataTable dtSubFunction = binddata("SUBFUNCTION_SELECT", this.cbFunction.Text);
                        dcTask.WriteLog(5, "Binding the Subfunction is Successful");
                        dcTask.WriteLog(5, "Filling the Subfunction");
                        fill_Subfunction(dtSubFunction);
                        dcTask.WriteLog(5, "Fill_SubFunction is Done");
                        this.cbSubfunction.SelectedIndex = 1;
                        Documenttitle(); 
                    }
                    else
                    {
                        dcedSubFunction.Visible = true;
                        cbSubfunction.Items.Clear();
                        cbSubfunction.Text = string.Empty;
                        dcedSubFunction.CtlText = string.Empty;
                        this.dcedSubFunction.Focus();
                        dcTask.WriteLog(5, "Binding the Subfunction based on function" + dcedFunction.CtlText);
                        DataTable dtSubFunction = binddata("SUBFUNCTION_SELECT", this.cbFunction.Text);
                        dcTask.WriteLog(5, "Binding the Subfunction is Successful");
                        dcTask.WriteLog(5, "Filling the Subfunction");
                        fill_Subfunction(dtSubFunction);
                        dcTask.WriteLog(5, "Fill_SubFunction is Done");
                        this.cbSubfunction.SelectedIndex = 0;
                        Documenttitle();
                    }
                    this.dcedDocument_Title.Focus();
                }
                else if (cbFunction.Text == "SELECT")
                {
                    dcTask.WriteLog(5, "cbFunction Value is SELECT");
                    this.dcedFunction.Visible = true;
                    dcedFunction.CtlText = string.Empty;
                    Hidefieldsbasedonfunction();
                }

            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Function_SelectedIndexChanged:" + ex);
            }
        }
        private void dtp_date_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                this.dcedDate_Of_Booking.Visible = true;
                this.dcedFin_Year.Visible = true;
                this.dcedDate_Of_Booking.CtlText = this.dtp_date.Text;
                string datev = this.dcedDate_Of_Booking.CtlText;
                dcTask.WriteLog(5,"Splitting the Date");
                string[] datearray = datev.Split('/');
                this.dcedFin_Year.CtlText = datearray[2].ToString();
                if (this.dcedFin_Year.CtlText.Length == 4)
                {
                    int Finyear = Convert.ToInt32(this.dcedFin_Year.CtlText);
                    string Finyear1 = (Finyear + 1).ToString();
                    var result = Finyear1.Substring(Finyear1.Length - 2);
                    this.dcedFin_Year.CtlText = this.dcedFin_Year.CtlText + "-" + result;
                    dcTask.WriteLog(5, "Fin_Year is Changed Successfully");
                }
                if (this.dcedFunction.CtlText == "Accounts Receivable")
                {
                    this.dcedInvoice_Date.CtlText = this.dcedDate_Of_Booking.CtlText;
                }
                Documenttitle();
                dcTask.WriteLog(5, "dtp_date_ValueChanged is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("date_ValueChanged:" + ex);
                this.dcedState.Visible = false;
            }


        }
        private void dtp_InvoiceDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                this.dcedInvoice_Date.CtlText = this.dtp_InvoiceDate.Text;
                if (this.dcedFunction.CtlText == "Accounts Receivable")
                {
                    this.dcedDate_Of_Booking.CtlText = this.dcedInvoice_Date.CtlText;
                }
                Documenttitle();
                dcTask.WriteLog(5, "dtp_InvoiceDate_ValueChanged is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("InvoiceDate_ValueChanged:" + ex);
            }
        }
        private void cbSubfunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cbSubfunction.Text != "SELECT")
                {
                    dcedSubFunction.Visible = true;
                    this.dcedSubFunction.CtlText = this.cbSubfunction.Text;
                    dcedSubFunction.Focus();
                    Documenttitle();
                    Hidefieldsbasedonfunction();
                }
                this.dcedDocument_Title.Focus();
                dcTask.WriteLog(5, "cbSubfunction_SelectedIndexChanged is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("cbSubfunction_SelectedIndexChanged:" + ex);
            }
        }

        private void dcedEntity_GST_Number_Change(object sender, EventArgs e)
        {
            try
            {

                if (this.dcedEntity_GST_Number.CtlText != string.Empty)
                {
                    this.dcedEntity_GST_Number.Visible = true;
                    string str1 = this.dcedEntity_GST_Number.CtlText;
                    string n = str1.Substring(0, 2);
                    this.dcedState.CtlText = n;
                    this.dcedState.Visible = true;
                    this.dcedState.Focus();
                    this.dcedState.Visible = false;
                    dcTask.WriteLog(5,"Checking State is Empty or not");
                    if (this.dcedState.CtlText != string.Empty)
                    {
                        State();
                       
                    }
                    Documenttitle();
                    this.dcedDocument_Title.Focus();
                }
            }
            catch (Exception ex)
            {
                Documenttitle();
                this.dcedDocument_Title.Focus();
                this.dcedState.Visible = false;
                dcTask.WriteLog("dcedEntity_GST_Number_Change:" + ex);
            }
         
        }

        private void dcedDate_Of_Booking_Change(object sender, EventArgs e)
        {
            try
            {
                if (this.dcedDate_Of_Booking.CtlText != string.Empty)
                {

                    if (this.dcedDate_Of_Booking.CtlText != string.Empty)
                    {
                        string DateofBooking = this.dcedDate_Of_Booking.CtlText;
                        dcTask.WriteLog(5, "Splitting Date in dcedDate_Of_Booking_Change Event");
                        string[] datearray = DateofBooking.Split('/');
                        this.dcedFin_Year.CtlText = datearray[2].ToString();
                        if (this.dcedFin_Year.CtlText.Length == 4)
                        {
                            int Finyear = Convert.ToInt32(this.dcedFin_Year.CtlText);
                            string Finyear1 = (Finyear + 1).ToString();
                            var result = Finyear1.Substring(Finyear1.Length - 2);
                            this.dcedFin_Year.CtlText = this.dcedFin_Year.CtlText + "-" + result;
                            dcTask.WriteLog(5, "Fin_Yearis Changed Successfully");
                        }
                        if (this.dcedFunction.CtlText == "Accounts Receivable")
                        {
                            this.dcedInvoice_Date.CtlText = this.dcedDate_Of_Booking.CtlText;
                        }
                        Documenttitle();
                        dcTask.WriteLog(5, "dcedDate_Of_Booking_Change is Done");
                    }
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Date_Of_Booking_Change " + ex);
            }
        }

        private void dcedDocument_Title_Change(object sender, EventArgs e)
        {
            Documenttitle();
            this.dcedFin_Year.Focus();
            this.dcedState.Visible = true;
            this.dcedState.Focus();
            this.dcedState.Visible = false;
            this.dcedDate_Of_Booking.Focus();
            dcedDocument_Title.Focus();
        }

        private void dcedReferenceNumber_Name_Change(object sender, EventArgs e)
        {
            try
            {
                Documenttitle();
                dcTask.WriteLog("ReferenceNumber_Name_Change is Successful");
            }
            catch (Exception ex)
            {

                dcTask.WriteLog("ReferenceNumber_Name_Change " + ex);
            }
            this.dcedDocument_Title.Focus();
        }

        private void dcedSerial_Number_Change(object sender, EventArgs e)
        {
            try
            {
                Documenttitle();
                dcTask.WriteLog("Serial_Number_Change Document Title is Successful:");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Serial_Number_Change " + ex);
            }
            this.dcedDocument_Title.Focus();
        }
    }
}
