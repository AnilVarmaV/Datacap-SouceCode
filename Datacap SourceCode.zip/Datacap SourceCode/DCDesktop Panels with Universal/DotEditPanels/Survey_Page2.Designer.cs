
namespace DotEditPanels
{
    partial class Survey_Page2
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Survey_Page2));
                            this.lbl7 = new System.Windows.Forms.Label();
                                        this.dcim7 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb7 = new System.Windows.Forms.ComboBox();
                                        this.lbl8 = new System.Windows.Forms.Label();
                                        this.dcim8 = new AxDCIMAGELib.AxDcimage();
                                        this.lst8 = new System.Windows.Forms.ListBox();
                                        this.lbl9 = new System.Windows.Forms.Label();
                                        this.dcim9 = new AxDCIMAGELib.AxDcimage();
                                        this.lst9 = new System.Windows.Forms.ListBox();
                                        this.lbl10a = new System.Windows.Forms.Label();
                                        this.dcim10a = new AxDCIMAGELib.AxDcimage();
                                        this.cmb10a = new System.Windows.Forms.ComboBox();
                                        this.lbl10b = new System.Windows.Forms.Label();
                                        this.dcim10b = new AxDCIMAGELib.AxDcimage();
                                        this.cmb10b = new System.Windows.Forms.ComboBox();
                                        this.lbl10c = new System.Windows.Forms.Label();
                                        this.dcim10c = new AxDCIMAGELib.AxDcimage();
                                        this.cmb10c = new System.Windows.Forms.ComboBox();
                                        this.lbl10d = new System.Windows.Forms.Label();
                                        this.dcim10d = new AxDCIMAGELib.AxDcimage();
                                        this.cmb10d = new System.Windows.Forms.ComboBox();
                                        this.lbl11 = new System.Windows.Forms.Label();
                                        this.dcim11 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb11 = new System.Windows.Forms.ComboBox();
                                        this.lbl12 = new System.Windows.Forms.Label();
                                        this.dcim12 = new AxDCIMAGELib.AxDcimage();
                                        this.lst12 = new System.Windows.Forms.ListBox();
                                        this.lbl13 = new System.Windows.Forms.Label();
                                        this.dcim13 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb13 = new System.Windows.Forms.ComboBox();
                                        this.lbl14 = new System.Windows.Forms.Label();
                                        this.dcim14 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb14 = new System.Windows.Forms.ComboBox();
                                        this.lbl15 = new System.Windows.Forms.Label();
                                        this.dcim15 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb15 = new System.Windows.Forms.ComboBox();
                                        this.lblMiles = new System.Windows.Forms.Label();
                                        this.dcimMiles = new AxDCIMAGELib.AxDcimage();
                                        this.dcedMiles = new AxDCEDITLib.AxDcedit();
                                        this.lbl16 = new System.Windows.Forms.Label();
                                        this.dcim16 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb16 = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAa = new System.Windows.Forms.Label();
                                        this.dcim17UAa = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAa = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAb = new System.Windows.Forms.Label();
                                        this.dcim17UAb = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAb = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAc = new System.Windows.Forms.Label();
                                        this.dcim17UAc = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAc = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAd = new System.Windows.Forms.Label();
                                        this.dcim17UAd = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAd = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAe = new System.Windows.Forms.Label();
                                        this.dcim17UAe = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAe = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAf = new System.Windows.Forms.Label();
                                        this.dcim17UAf = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAf = new System.Windows.Forms.ComboBox();
                                        this.lbl17UAg = new System.Windows.Forms.Label();
                                        this.dcim17UAg = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17UAg = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROa = new System.Windows.Forms.Label();
                                        this.dcim17ROa = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROa = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROb = new System.Windows.Forms.Label();
                                        this.dcim17ROb = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROb = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROc = new System.Windows.Forms.Label();
                                        this.dcim17ROc = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROc = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROd = new System.Windows.Forms.Label();
                                        this.dcim17ROd = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROd = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROe = new System.Windows.Forms.Label();
                                        this.dcim17ROe = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROe = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROf = new System.Windows.Forms.Label();
                                        this.dcim17ROf = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROf = new System.Windows.Forms.ComboBox();
                                        this.lbl17ROg = new System.Windows.Forms.Label();
                                        this.dcim17ROg = new AxDCIMAGELib.AxDcimage();
                                        this.cmb17ROg = new System.Windows.Forms.ComboBox();
                                        this.lbl18 = new System.Windows.Forms.Label();
                                        this.dcim18 = new AxDCIMAGELib.AxDcimage();
                                        this.cmb18 = new System.Windows.Forms.ComboBox();
                                        this.lbl18Describe = new System.Windows.Forms.Label();
                                        this.dcim18Describe = new AxDCIMAGELib.AxDcimage();
                                        this.dced18Describe = new AxDCEDITLib.AxDcedit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim7)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim8)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim9)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim10a)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim10b)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim10c)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim10d)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim11)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim12)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim13)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim14)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim15)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcimMiles)).BeginInit();
                            
            ((System.ComponentModel.ISupportInitialize)(this.dcedMiles)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim16)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAa)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAb)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAc)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAd)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAe)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAf)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17UAg)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROa)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROb)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROc)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROd)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROe)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROf)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim17ROg)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim18)).BeginInit();
                                        ((System.ComponentModel.ISupportInitialize)(this.dcim18Describe)).BeginInit();
                            
            ((System.ComponentModel.ISupportInitialize)(this.dced18Describe)).BeginInit();
                            
            this.SuspendLayout();
                                // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Location = new System.Drawing.Point(17, 12);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(100, 15);
            this.lbl7.TabIndex = 0;
            this.lbl7.Text = "7";
            this.lbl7.Tag = "7";
                                        this.lbl7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim7
            // 
            this.dcim7.Enabled = true;
            this.dcim7.Location = new System.Drawing.Point(20, 33);
            this.dcim7.Name = "dcim7";
            this.dcim7.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim7.Size = new System.Drawing.Size(105, 27);
            this.dcim7.TabIndex = 1;
            this.dcim7.TabStop = false;
            this.dcim7.Tag = "7";
                                        // 
            // cmb7
            // 
            this.cmb7.FormattingEnabled = true;
            this.cmb7.Location = new System.Drawing.Point(20, 66);
            this.cmb7.Name = "cmb7";
            this.cmb7.Size = new System.Drawing.Size(200, 26);
            this.cmb7.TabIndex = 2;
            this.cmb7.Tag = "7";
                                        this.cmb7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Location = new System.Drawing.Point(17, 103);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(100, 15);
            this.lbl8.TabIndex = 3;
            this.lbl8.Text = "8";
            this.lbl8.Tag = "8";
                                        this.lbl8.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim8
            // 
            this.dcim8.Enabled = true;
            this.dcim8.Location = new System.Drawing.Point(20, 124);
            this.dcim8.Name = "dcim8";
            this.dcim8.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim8.Size = new System.Drawing.Size(105, 27);
            this.dcim8.TabIndex = 4;
            this.dcim8.TabStop = false;
            this.dcim8.Tag = "8";
                                        // 
            // lst8
            // 
            this.lst8.FormattingEnabled = true;
            this.lst8.Location = new System.Drawing.Point(20, 157);
            this.lst8.Name = "lst8";
            this.lst8.Size = new System.Drawing.Size(200, 58);
            this.lst8.TabIndex = 5;
            this.lst8.Tag = "8";
                                        this.lst8.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst8.ItemHeight = 18;
            this.lst8.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Location = new System.Drawing.Point(17, 227);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(100, 15);
            this.lbl9.TabIndex = 6;
            this.lbl9.Text = "9";
            this.lbl9.Tag = "9";
                                        this.lbl9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim9
            // 
            this.dcim9.Enabled = true;
            this.dcim9.Location = new System.Drawing.Point(20, 248);
            this.dcim9.Name = "dcim9";
            this.dcim9.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim9.Size = new System.Drawing.Size(105, 27);
            this.dcim9.TabIndex = 7;
            this.dcim9.TabStop = false;
            this.dcim9.Tag = "9";
                                        // 
            // lst9
            // 
            this.lst9.FormattingEnabled = true;
            this.lst9.Location = new System.Drawing.Point(20, 281);
            this.lst9.Name = "lst9";
            this.lst9.Size = new System.Drawing.Size(200, 58);
            this.lst9.TabIndex = 8;
            this.lst9.Tag = "9";
                                        this.lst9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst9.ItemHeight = 18;
            this.lst9.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            // 
            // lbl10a
            // 
            this.lbl10a.AutoSize = true;
            this.lbl10a.Location = new System.Drawing.Point(17, 351);
            this.lbl10a.Name = "lbl10a";
            this.lbl10a.Size = new System.Drawing.Size(100, 15);
            this.lbl10a.TabIndex = 9;
            this.lbl10a.Text = "10a";
            this.lbl10a.Tag = "10a";
                                        this.lbl10a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim10a
            // 
            this.dcim10a.Enabled = true;
            this.dcim10a.Location = new System.Drawing.Point(20, 372);
            this.dcim10a.Name = "dcim10a";
            this.dcim10a.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim10a.Size = new System.Drawing.Size(105, 27);
            this.dcim10a.TabIndex = 10;
            this.dcim10a.TabStop = false;
            this.dcim10a.Tag = "10a";
                                        // 
            // cmb10a
            // 
            this.cmb10a.FormattingEnabled = true;
            this.cmb10a.Location = new System.Drawing.Point(20, 405);
            this.cmb10a.Name = "cmb10a";
            this.cmb10a.Size = new System.Drawing.Size(200, 26);
            this.cmb10a.TabIndex = 11;
            this.cmb10a.Tag = "10a";
                                        this.cmb10a.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl10b
            // 
            this.lbl10b.AutoSize = true;
            this.lbl10b.Location = new System.Drawing.Point(17, 442);
            this.lbl10b.Name = "lbl10b";
            this.lbl10b.Size = new System.Drawing.Size(100, 15);
            this.lbl10b.TabIndex = 12;
            this.lbl10b.Text = "10b";
            this.lbl10b.Tag = "10b";
                                        this.lbl10b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim10b
            // 
            this.dcim10b.Enabled = true;
            this.dcim10b.Location = new System.Drawing.Point(20, 463);
            this.dcim10b.Name = "dcim10b";
            this.dcim10b.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim10b.Size = new System.Drawing.Size(105, 27);
            this.dcim10b.TabIndex = 13;
            this.dcim10b.TabStop = false;
            this.dcim10b.Tag = "10b";
                                        // 
            // cmb10b
            // 
            this.cmb10b.FormattingEnabled = true;
            this.cmb10b.Location = new System.Drawing.Point(20, 496);
            this.cmb10b.Name = "cmb10b";
            this.cmb10b.Size = new System.Drawing.Size(200, 26);
            this.cmb10b.TabIndex = 14;
            this.cmb10b.Tag = "10b";
                                        this.cmb10b.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl10c
            // 
            this.lbl10c.AutoSize = true;
            this.lbl10c.Location = new System.Drawing.Point(17, 533);
            this.lbl10c.Name = "lbl10c";
            this.lbl10c.Size = new System.Drawing.Size(100, 15);
            this.lbl10c.TabIndex = 15;
            this.lbl10c.Text = "10c";
            this.lbl10c.Tag = "10c";
                                        this.lbl10c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim10c
            // 
            this.dcim10c.Enabled = true;
            this.dcim10c.Location = new System.Drawing.Point(20, 554);
            this.dcim10c.Name = "dcim10c";
            this.dcim10c.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim10c.Size = new System.Drawing.Size(105, 27);
            this.dcim10c.TabIndex = 16;
            this.dcim10c.TabStop = false;
            this.dcim10c.Tag = "10c";
                                        // 
            // cmb10c
            // 
            this.cmb10c.FormattingEnabled = true;
            this.cmb10c.Location = new System.Drawing.Point(20, 587);
            this.cmb10c.Name = "cmb10c";
            this.cmb10c.Size = new System.Drawing.Size(200, 26);
            this.cmb10c.TabIndex = 17;
            this.cmb10c.Tag = "10c";
                                        this.cmb10c.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl10d
            // 
            this.lbl10d.AutoSize = true;
            this.lbl10d.Location = new System.Drawing.Point(17, 624);
            this.lbl10d.Name = "lbl10d";
            this.lbl10d.Size = new System.Drawing.Size(100, 15);
            this.lbl10d.TabIndex = 18;
            this.lbl10d.Text = "10d";
            this.lbl10d.Tag = "10d";
                                        this.lbl10d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim10d
            // 
            this.dcim10d.Enabled = true;
            this.dcim10d.Location = new System.Drawing.Point(20, 645);
            this.dcim10d.Name = "dcim10d";
            this.dcim10d.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim10d.Size = new System.Drawing.Size(105, 27);
            this.dcim10d.TabIndex = 19;
            this.dcim10d.TabStop = false;
            this.dcim10d.Tag = "10d";
                                        // 
            // cmb10d
            // 
            this.cmb10d.FormattingEnabled = true;
            this.cmb10d.Location = new System.Drawing.Point(20, 678);
            this.cmb10d.Name = "cmb10d";
            this.cmb10d.Size = new System.Drawing.Size(200, 26);
            this.cmb10d.TabIndex = 20;
            this.cmb10d.Tag = "10d";
                                        this.cmb10d.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Location = new System.Drawing.Point(17, 715);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(100, 15);
            this.lbl11.TabIndex = 21;
            this.lbl11.Text = "11";
            this.lbl11.Tag = "11";
                                        this.lbl11.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim11
            // 
            this.dcim11.Enabled = true;
            this.dcim11.Location = new System.Drawing.Point(20, 736);
            this.dcim11.Name = "dcim11";
            this.dcim11.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim11.Size = new System.Drawing.Size(105, 27);
            this.dcim11.TabIndex = 22;
            this.dcim11.TabStop = false;
            this.dcim11.Tag = "11";
                                        // 
            // cmb11
            // 
            this.cmb11.FormattingEnabled = true;
            this.cmb11.Location = new System.Drawing.Point(20, 769);
            this.cmb11.Name = "cmb11";
            this.cmb11.Size = new System.Drawing.Size(200, 26);
            this.cmb11.TabIndex = 23;
            this.cmb11.Tag = "11";
                                        this.cmb11.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(17, 806);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(100, 15);
            this.lbl12.TabIndex = 24;
            this.lbl12.Text = "12";
            this.lbl12.Tag = "12";
                                        this.lbl12.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim12
            // 
            this.dcim12.Enabled = true;
            this.dcim12.Location = new System.Drawing.Point(20, 827);
            this.dcim12.Name = "dcim12";
            this.dcim12.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim12.Size = new System.Drawing.Size(105, 27);
            this.dcim12.TabIndex = 25;
            this.dcim12.TabStop = false;
            this.dcim12.Tag = "12";
                                        // 
            // lst12
            // 
            this.lst12.FormattingEnabled = true;
            this.lst12.Location = new System.Drawing.Point(20, 860);
            this.lst12.Name = "lst12";
            this.lst12.Size = new System.Drawing.Size(200, 58);
            this.lst12.TabIndex = 26;
            this.lst12.Tag = "12";
                                        this.lst12.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst12.ItemHeight = 18;
            this.lst12.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(17, 930);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(100, 15);
            this.lbl13.TabIndex = 27;
            this.lbl13.Text = "13";
            this.lbl13.Tag = "13";
                                        this.lbl13.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim13
            // 
            this.dcim13.Enabled = true;
            this.dcim13.Location = new System.Drawing.Point(20, 951);
            this.dcim13.Name = "dcim13";
            this.dcim13.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim13.Size = new System.Drawing.Size(105, 27);
            this.dcim13.TabIndex = 28;
            this.dcim13.TabStop = false;
            this.dcim13.Tag = "13";
                                        // 
            // cmb13
            // 
            this.cmb13.FormattingEnabled = true;
            this.cmb13.Location = new System.Drawing.Point(20, 984);
            this.cmb13.Name = "cmb13";
            this.cmb13.Size = new System.Drawing.Size(200, 26);
            this.cmb13.TabIndex = 29;
            this.cmb13.Tag = "13";
                                        this.cmb13.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Location = new System.Drawing.Point(17, 1021);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(100, 15);
            this.lbl14.TabIndex = 30;
            this.lbl14.Text = "14";
            this.lbl14.Tag = "14";
                                        this.lbl14.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim14
            // 
            this.dcim14.Enabled = true;
            this.dcim14.Location = new System.Drawing.Point(20, 1042);
            this.dcim14.Name = "dcim14";
            this.dcim14.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim14.Size = new System.Drawing.Size(105, 27);
            this.dcim14.TabIndex = 31;
            this.dcim14.TabStop = false;
            this.dcim14.Tag = "14";
                                        // 
            // cmb14
            // 
            this.cmb14.FormattingEnabled = true;
            this.cmb14.Location = new System.Drawing.Point(20, 1075);
            this.cmb14.Name = "cmb14";
            this.cmb14.Size = new System.Drawing.Size(200, 26);
            this.cmb14.TabIndex = 32;
            this.cmb14.Tag = "14";
                                        this.cmb14.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Location = new System.Drawing.Point(17, 1112);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(100, 15);
            this.lbl15.TabIndex = 33;
            this.lbl15.Text = "15";
            this.lbl15.Tag = "15";
                                        this.lbl15.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim15
            // 
            this.dcim15.Enabled = true;
            this.dcim15.Location = new System.Drawing.Point(20, 1133);
            this.dcim15.Name = "dcim15";
            this.dcim15.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim15.Size = new System.Drawing.Size(105, 27);
            this.dcim15.TabIndex = 34;
            this.dcim15.TabStop = false;
            this.dcim15.Tag = "15";
                                        // 
            // cmb15
            // 
            this.cmb15.FormattingEnabled = true;
            this.cmb15.Location = new System.Drawing.Point(20, 1166);
            this.cmb15.Name = "cmb15";
            this.cmb15.Size = new System.Drawing.Size(200, 26);
            this.cmb15.TabIndex = 35;
            this.cmb15.Tag = "15";
                                        this.cmb15.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lblMiles
            // 
            this.lblMiles.AutoSize = true;
            this.lblMiles.Location = new System.Drawing.Point(17, 1203);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(100, 15);
            this.lblMiles.TabIndex = 36;
            this.lblMiles.Text = "Miles";
            this.lblMiles.Tag = "Miles";
                                        this.lblMiles.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcimMiles
            // 
            this.dcimMiles.Enabled = true;
            this.dcimMiles.Location = new System.Drawing.Point(20, 1224);
            this.dcimMiles.Name = "dcimMiles";
            this.dcimMiles.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcimMiles.Size = new System.Drawing.Size(105, 27);
            this.dcimMiles.TabIndex = 37;
            this.dcimMiles.TabStop = false;
            this.dcimMiles.Tag = "Miles";
                                        // 
            // dcedMiles
            // 
            this.dcedMiles.Location = new System.Drawing.Point(20, 1257);
            this.dcedMiles.Name = "dcedMiles";
            this.dcedMiles.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
            this.dcedMiles.Size = new System.Drawing.Size(105, 25);
            this.dcedMiles.TabIndex = 38;
            this.dcedMiles.Tag = "Miles";
                                        // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Location = new System.Drawing.Point(17, 1294);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(100, 15);
            this.lbl16.TabIndex = 39;
            this.lbl16.Text = "16";
            this.lbl16.Tag = "16";
                                        this.lbl16.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim16
            // 
            this.dcim16.Enabled = true;
            this.dcim16.Location = new System.Drawing.Point(20, 1315);
            this.dcim16.Name = "dcim16";
            this.dcim16.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim16.Size = new System.Drawing.Size(105, 27);
            this.dcim16.TabIndex = 40;
            this.dcim16.TabStop = false;
            this.dcim16.Tag = "16";
                                        // 
            // cmb16
            // 
            this.cmb16.FormattingEnabled = true;
            this.cmb16.Location = new System.Drawing.Point(20, 1348);
            this.cmb16.Name = "cmb16";
            this.cmb16.Size = new System.Drawing.Size(200, 26);
            this.cmb16.TabIndex = 41;
            this.cmb16.Tag = "16";
                                        this.cmb16.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAa
            // 
            this.lbl17UAa.AutoSize = true;
            this.lbl17UAa.Location = new System.Drawing.Point(17, 1385);
            this.lbl17UAa.Name = "lbl17UAa";
            this.lbl17UAa.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAa.TabIndex = 42;
            this.lbl17UAa.Text = "17UAa";
            this.lbl17UAa.Tag = "17UAa";
                                        this.lbl17UAa.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAa
            // 
            this.dcim17UAa.Enabled = true;
            this.dcim17UAa.Location = new System.Drawing.Point(20, 1406);
            this.dcim17UAa.Name = "dcim17UAa";
            this.dcim17UAa.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAa.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAa.TabIndex = 43;
            this.dcim17UAa.TabStop = false;
            this.dcim17UAa.Tag = "17UAa";
                                        // 
            // cmb17UAa
            // 
            this.cmb17UAa.FormattingEnabled = true;
            this.cmb17UAa.Location = new System.Drawing.Point(20, 1439);
            this.cmb17UAa.Name = "cmb17UAa";
            this.cmb17UAa.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAa.TabIndex = 44;
            this.cmb17UAa.Tag = "17UAa";
                                        this.cmb17UAa.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAb
            // 
            this.lbl17UAb.AutoSize = true;
            this.lbl17UAb.Location = new System.Drawing.Point(17, 1476);
            this.lbl17UAb.Name = "lbl17UAb";
            this.lbl17UAb.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAb.TabIndex = 45;
            this.lbl17UAb.Text = "17UAb";
            this.lbl17UAb.Tag = "17UAb";
                                        this.lbl17UAb.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAb
            // 
            this.dcim17UAb.Enabled = true;
            this.dcim17UAb.Location = new System.Drawing.Point(20, 1497);
            this.dcim17UAb.Name = "dcim17UAb";
            this.dcim17UAb.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAb.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAb.TabIndex = 46;
            this.dcim17UAb.TabStop = false;
            this.dcim17UAb.Tag = "17UAb";
                                        // 
            // cmb17UAb
            // 
            this.cmb17UAb.FormattingEnabled = true;
            this.cmb17UAb.Location = new System.Drawing.Point(20, 1530);
            this.cmb17UAb.Name = "cmb17UAb";
            this.cmb17UAb.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAb.TabIndex = 47;
            this.cmb17UAb.Tag = "17UAb";
                                        this.cmb17UAb.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAc
            // 
            this.lbl17UAc.AutoSize = true;
            this.lbl17UAc.Location = new System.Drawing.Point(17, 1567);
            this.lbl17UAc.Name = "lbl17UAc";
            this.lbl17UAc.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAc.TabIndex = 48;
            this.lbl17UAc.Text = "17UAc";
            this.lbl17UAc.Tag = "17UAc";
                                        this.lbl17UAc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAc
            // 
            this.dcim17UAc.Enabled = true;
            this.dcim17UAc.Location = new System.Drawing.Point(20, 1588);
            this.dcim17UAc.Name = "dcim17UAc";
            this.dcim17UAc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAc.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAc.TabIndex = 49;
            this.dcim17UAc.TabStop = false;
            this.dcim17UAc.Tag = "17UAc";
                                        // 
            // cmb17UAc
            // 
            this.cmb17UAc.FormattingEnabled = true;
            this.cmb17UAc.Location = new System.Drawing.Point(20, 1621);
            this.cmb17UAc.Name = "cmb17UAc";
            this.cmb17UAc.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAc.TabIndex = 50;
            this.cmb17UAc.Tag = "17UAc";
                                        this.cmb17UAc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAd
            // 
            this.lbl17UAd.AutoSize = true;
            this.lbl17UAd.Location = new System.Drawing.Point(17, 1658);
            this.lbl17UAd.Name = "lbl17UAd";
            this.lbl17UAd.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAd.TabIndex = 51;
            this.lbl17UAd.Text = "17UAd";
            this.lbl17UAd.Tag = "17UAd";
                                        this.lbl17UAd.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAd
            // 
            this.dcim17UAd.Enabled = true;
            this.dcim17UAd.Location = new System.Drawing.Point(20, 1679);
            this.dcim17UAd.Name = "dcim17UAd";
            this.dcim17UAd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAd.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAd.TabIndex = 52;
            this.dcim17UAd.TabStop = false;
            this.dcim17UAd.Tag = "17UAd";
                                        // 
            // cmb17UAd
            // 
            this.cmb17UAd.FormattingEnabled = true;
            this.cmb17UAd.Location = new System.Drawing.Point(20, 1712);
            this.cmb17UAd.Name = "cmb17UAd";
            this.cmb17UAd.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAd.TabIndex = 53;
            this.cmb17UAd.Tag = "17UAd";
                                        this.cmb17UAd.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAe
            // 
            this.lbl17UAe.AutoSize = true;
            this.lbl17UAe.Location = new System.Drawing.Point(17, 1749);
            this.lbl17UAe.Name = "lbl17UAe";
            this.lbl17UAe.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAe.TabIndex = 54;
            this.lbl17UAe.Text = "17UAe";
            this.lbl17UAe.Tag = "17UAe";
                                        this.lbl17UAe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAe
            // 
            this.dcim17UAe.Enabled = true;
            this.dcim17UAe.Location = new System.Drawing.Point(20, 1770);
            this.dcim17UAe.Name = "dcim17UAe";
            this.dcim17UAe.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAe.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAe.TabIndex = 55;
            this.dcim17UAe.TabStop = false;
            this.dcim17UAe.Tag = "17UAe";
                                        // 
            // cmb17UAe
            // 
            this.cmb17UAe.FormattingEnabled = true;
            this.cmb17UAe.Location = new System.Drawing.Point(20, 1803);
            this.cmb17UAe.Name = "cmb17UAe";
            this.cmb17UAe.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAe.TabIndex = 56;
            this.cmb17UAe.Tag = "17UAe";
                                        this.cmb17UAe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAf
            // 
            this.lbl17UAf.AutoSize = true;
            this.lbl17UAf.Location = new System.Drawing.Point(17, 1840);
            this.lbl17UAf.Name = "lbl17UAf";
            this.lbl17UAf.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAf.TabIndex = 57;
            this.lbl17UAf.Text = "17UAf";
            this.lbl17UAf.Tag = "17UAf";
                                        this.lbl17UAf.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAf
            // 
            this.dcim17UAf.Enabled = true;
            this.dcim17UAf.Location = new System.Drawing.Point(20, 1861);
            this.dcim17UAf.Name = "dcim17UAf";
            this.dcim17UAf.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAf.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAf.TabIndex = 58;
            this.dcim17UAf.TabStop = false;
            this.dcim17UAf.Tag = "17UAf";
                                        // 
            // cmb17UAf
            // 
            this.cmb17UAf.FormattingEnabled = true;
            this.cmb17UAf.Location = new System.Drawing.Point(20, 1894);
            this.cmb17UAf.Name = "cmb17UAf";
            this.cmb17UAf.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAf.TabIndex = 59;
            this.cmb17UAf.Tag = "17UAf";
                                        this.cmb17UAf.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17UAg
            // 
            this.lbl17UAg.AutoSize = true;
            this.lbl17UAg.Location = new System.Drawing.Point(17, 1931);
            this.lbl17UAg.Name = "lbl17UAg";
            this.lbl17UAg.Size = new System.Drawing.Size(100, 15);
            this.lbl17UAg.TabIndex = 60;
            this.lbl17UAg.Text = "17UAg";
            this.lbl17UAg.Tag = "17UAg";
                                        this.lbl17UAg.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17UAg
            // 
            this.dcim17UAg.Enabled = true;
            this.dcim17UAg.Location = new System.Drawing.Point(20, 1952);
            this.dcim17UAg.Name = "dcim17UAg";
            this.dcim17UAg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17UAg.Size = new System.Drawing.Size(105, 27);
            this.dcim17UAg.TabIndex = 61;
            this.dcim17UAg.TabStop = false;
            this.dcim17UAg.Tag = "17UAg";
                                        // 
            // cmb17UAg
            // 
            this.cmb17UAg.FormattingEnabled = true;
            this.cmb17UAg.Location = new System.Drawing.Point(20, 1985);
            this.cmb17UAg.Name = "cmb17UAg";
            this.cmb17UAg.Size = new System.Drawing.Size(200, 26);
            this.cmb17UAg.TabIndex = 62;
            this.cmb17UAg.Tag = "17UAg";
                                        this.cmb17UAg.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROa
            // 
            this.lbl17ROa.AutoSize = true;
            this.lbl17ROa.Location = new System.Drawing.Point(17, 2022);
            this.lbl17ROa.Name = "lbl17ROa";
            this.lbl17ROa.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROa.TabIndex = 63;
            this.lbl17ROa.Text = "17ROa";
            this.lbl17ROa.Tag = "17ROa";
                                        this.lbl17ROa.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROa
            // 
            this.dcim17ROa.Enabled = true;
            this.dcim17ROa.Location = new System.Drawing.Point(20, 2043);
            this.dcim17ROa.Name = "dcim17ROa";
            this.dcim17ROa.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROa.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROa.TabIndex = 64;
            this.dcim17ROa.TabStop = false;
            this.dcim17ROa.Tag = "17ROa";
                                        // 
            // cmb17ROa
            // 
            this.cmb17ROa.FormattingEnabled = true;
            this.cmb17ROa.Location = new System.Drawing.Point(20, 2076);
            this.cmb17ROa.Name = "cmb17ROa";
            this.cmb17ROa.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROa.TabIndex = 65;
            this.cmb17ROa.Tag = "17ROa";
                                        this.cmb17ROa.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROb
            // 
            this.lbl17ROb.AutoSize = true;
            this.lbl17ROb.Location = new System.Drawing.Point(17, 2113);
            this.lbl17ROb.Name = "lbl17ROb";
            this.lbl17ROb.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROb.TabIndex = 66;
            this.lbl17ROb.Text = "17ROb";
            this.lbl17ROb.Tag = "17ROb";
                                        this.lbl17ROb.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROb
            // 
            this.dcim17ROb.Enabled = true;
            this.dcim17ROb.Location = new System.Drawing.Point(20, 2134);
            this.dcim17ROb.Name = "dcim17ROb";
            this.dcim17ROb.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROb.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROb.TabIndex = 67;
            this.dcim17ROb.TabStop = false;
            this.dcim17ROb.Tag = "17ROb";
                                        // 
            // cmb17ROb
            // 
            this.cmb17ROb.FormattingEnabled = true;
            this.cmb17ROb.Location = new System.Drawing.Point(20, 2167);
            this.cmb17ROb.Name = "cmb17ROb";
            this.cmb17ROb.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROb.TabIndex = 68;
            this.cmb17ROb.Tag = "17ROb";
                                        this.cmb17ROb.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROc
            // 
            this.lbl17ROc.AutoSize = true;
            this.lbl17ROc.Location = new System.Drawing.Point(17, 2204);
            this.lbl17ROc.Name = "lbl17ROc";
            this.lbl17ROc.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROc.TabIndex = 69;
            this.lbl17ROc.Text = "17ROc";
            this.lbl17ROc.Tag = "17ROc";
                                        this.lbl17ROc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROc
            // 
            this.dcim17ROc.Enabled = true;
            this.dcim17ROc.Location = new System.Drawing.Point(20, 2225);
            this.dcim17ROc.Name = "dcim17ROc";
            this.dcim17ROc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROc.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROc.TabIndex = 70;
            this.dcim17ROc.TabStop = false;
            this.dcim17ROc.Tag = "17ROc";
                                        // 
            // cmb17ROc
            // 
            this.cmb17ROc.FormattingEnabled = true;
            this.cmb17ROc.Location = new System.Drawing.Point(20, 2258);
            this.cmb17ROc.Name = "cmb17ROc";
            this.cmb17ROc.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROc.TabIndex = 71;
            this.cmb17ROc.Tag = "17ROc";
                                        this.cmb17ROc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROd
            // 
            this.lbl17ROd.AutoSize = true;
            this.lbl17ROd.Location = new System.Drawing.Point(17, 2295);
            this.lbl17ROd.Name = "lbl17ROd";
            this.lbl17ROd.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROd.TabIndex = 72;
            this.lbl17ROd.Text = "17ROd";
            this.lbl17ROd.Tag = "17ROd";
                                        this.lbl17ROd.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROd
            // 
            this.dcim17ROd.Enabled = true;
            this.dcim17ROd.Location = new System.Drawing.Point(20, 2316);
            this.dcim17ROd.Name = "dcim17ROd";
            this.dcim17ROd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROd.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROd.TabIndex = 73;
            this.dcim17ROd.TabStop = false;
            this.dcim17ROd.Tag = "17ROd";
                                        // 
            // cmb17ROd
            // 
            this.cmb17ROd.FormattingEnabled = true;
            this.cmb17ROd.Location = new System.Drawing.Point(20, 2349);
            this.cmb17ROd.Name = "cmb17ROd";
            this.cmb17ROd.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROd.TabIndex = 74;
            this.cmb17ROd.Tag = "17ROd";
                                        this.cmb17ROd.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROe
            // 
            this.lbl17ROe.AutoSize = true;
            this.lbl17ROe.Location = new System.Drawing.Point(17, 2386);
            this.lbl17ROe.Name = "lbl17ROe";
            this.lbl17ROe.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROe.TabIndex = 75;
            this.lbl17ROe.Text = "17ROe";
            this.lbl17ROe.Tag = "17ROe";
                                        this.lbl17ROe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROe
            // 
            this.dcim17ROe.Enabled = true;
            this.dcim17ROe.Location = new System.Drawing.Point(20, 2407);
            this.dcim17ROe.Name = "dcim17ROe";
            this.dcim17ROe.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROe.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROe.TabIndex = 76;
            this.dcim17ROe.TabStop = false;
            this.dcim17ROe.Tag = "17ROe";
                                        // 
            // cmb17ROe
            // 
            this.cmb17ROe.FormattingEnabled = true;
            this.cmb17ROe.Location = new System.Drawing.Point(20, 2440);
            this.cmb17ROe.Name = "cmb17ROe";
            this.cmb17ROe.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROe.TabIndex = 77;
            this.cmb17ROe.Tag = "17ROe";
                                        this.cmb17ROe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROf
            // 
            this.lbl17ROf.AutoSize = true;
            this.lbl17ROf.Location = new System.Drawing.Point(17, 2477);
            this.lbl17ROf.Name = "lbl17ROf";
            this.lbl17ROf.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROf.TabIndex = 78;
            this.lbl17ROf.Text = "17ROf";
            this.lbl17ROf.Tag = "17ROf";
                                        this.lbl17ROf.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROf
            // 
            this.dcim17ROf.Enabled = true;
            this.dcim17ROf.Location = new System.Drawing.Point(20, 2498);
            this.dcim17ROf.Name = "dcim17ROf";
            this.dcim17ROf.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROf.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROf.TabIndex = 79;
            this.dcim17ROf.TabStop = false;
            this.dcim17ROf.Tag = "17ROf";
                                        // 
            // cmb17ROf
            // 
            this.cmb17ROf.FormattingEnabled = true;
            this.cmb17ROf.Location = new System.Drawing.Point(20, 2531);
            this.cmb17ROf.Name = "cmb17ROf";
            this.cmb17ROf.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROf.TabIndex = 80;
            this.cmb17ROf.Tag = "17ROf";
                                        this.cmb17ROf.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl17ROg
            // 
            this.lbl17ROg.AutoSize = true;
            this.lbl17ROg.Location = new System.Drawing.Point(17, 2568);
            this.lbl17ROg.Name = "lbl17ROg";
            this.lbl17ROg.Size = new System.Drawing.Size(100, 15);
            this.lbl17ROg.TabIndex = 81;
            this.lbl17ROg.Text = "17ROg";
            this.lbl17ROg.Tag = "17ROg";
                                        this.lbl17ROg.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim17ROg
            // 
            this.dcim17ROg.Enabled = true;
            this.dcim17ROg.Location = new System.Drawing.Point(20, 2589);
            this.dcim17ROg.Name = "dcim17ROg";
            this.dcim17ROg.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim17ROg.Size = new System.Drawing.Size(105, 27);
            this.dcim17ROg.TabIndex = 82;
            this.dcim17ROg.TabStop = false;
            this.dcim17ROg.Tag = "17ROg";
                                        // 
            // cmb17ROg
            // 
            this.cmb17ROg.FormattingEnabled = true;
            this.cmb17ROg.Location = new System.Drawing.Point(20, 2622);
            this.cmb17ROg.Name = "cmb17ROg";
            this.cmb17ROg.Size = new System.Drawing.Size(200, 26);
            this.cmb17ROg.TabIndex = 83;
            this.cmb17ROg.Tag = "17ROg";
                                        this.cmb17ROg.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Location = new System.Drawing.Point(17, 2659);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(100, 15);
            this.lbl18.TabIndex = 84;
            this.lbl18.Text = "18";
            this.lbl18.Tag = "18";
                                        this.lbl18.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim18
            // 
            this.dcim18.Enabled = true;
            this.dcim18.Location = new System.Drawing.Point(20, 2680);
            this.dcim18.Name = "dcim18";
            this.dcim18.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim18.Size = new System.Drawing.Size(105, 27);
            this.dcim18.TabIndex = 85;
            this.dcim18.TabStop = false;
            this.dcim18.Tag = "18";
                                        // 
            // cmb18
            // 
            this.cmb18.FormattingEnabled = true;
            this.cmb18.Location = new System.Drawing.Point(20, 2713);
            this.cmb18.Name = "cmb18";
            this.cmb18.Size = new System.Drawing.Size(200, 26);
            this.cmb18.TabIndex = 86;
            this.cmb18.Tag = "18";
                                        this.cmb18.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbl18Describe
            // 
            this.lbl18Describe.AutoSize = true;
            this.lbl18Describe.Location = new System.Drawing.Point(17, 2750);
            this.lbl18Describe.Name = "lbl18Describe";
            this.lbl18Describe.Size = new System.Drawing.Size(100, 15);
            this.lbl18Describe.TabIndex = 87;
            this.lbl18Describe.Text = "18Describe";
            this.lbl18Describe.Tag = "18Describe";
                                        this.lbl18Describe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dcim18Describe
            // 
            this.dcim18Describe.Enabled = true;
            this.dcim18Describe.Location = new System.Drawing.Point(20, 2771);
            this.dcim18Describe.Name = "dcim18Describe";
            this.dcim18Describe.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            this.dcim18Describe.Size = new System.Drawing.Size(105, 27);
            this.dcim18Describe.TabIndex = 88;
            this.dcim18Describe.TabStop = false;
            this.dcim18Describe.Tag = "18Describe";
                                        // 
            // dced18Describe
            // 
            this.dced18Describe.Location = new System.Drawing.Point(20, 2804);
            this.dced18Describe.Name = "dced18Describe";
            this.dced18Describe.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
            this.dced18Describe.Size = new System.Drawing.Size(105, 25);
            this.dced18Describe.TabIndex = 89;
            this.dced18Describe.Tag = "18Describe";
                                        this.Controls.Add(this.lbl7);
                                        this.Controls.Add(this.dcim7);
                                        this.Controls.Add(this.cmb7);
                                        this.Controls.Add(this.lbl8);
                                        this.Controls.Add(this.dcim8);
                                        this.Controls.Add(this.lst8);
                                        this.Controls.Add(this.lbl9);
                                        this.Controls.Add(this.dcim9);
                                        this.Controls.Add(this.lst9);
                                        this.Controls.Add(this.lbl10a);
                                        this.Controls.Add(this.dcim10a);
                                        this.Controls.Add(this.cmb10a);
                                        this.Controls.Add(this.lbl10b);
                                        this.Controls.Add(this.dcim10b);
                                        this.Controls.Add(this.cmb10b);
                                        this.Controls.Add(this.lbl10c);
                                        this.Controls.Add(this.dcim10c);
                                        this.Controls.Add(this.cmb10c);
                                        this.Controls.Add(this.lbl10d);
                                        this.Controls.Add(this.dcim10d);
                                        this.Controls.Add(this.cmb10d);
                                        this.Controls.Add(this.lbl11);
                                        this.Controls.Add(this.dcim11);
                                        this.Controls.Add(this.cmb11);
                                        this.Controls.Add(this.lbl12);
                                        this.Controls.Add(this.dcim12);
                                        this.Controls.Add(this.lst12);
                                        this.Controls.Add(this.lbl13);
                                        this.Controls.Add(this.dcim13);
                                        this.Controls.Add(this.cmb13);
                                        this.Controls.Add(this.lbl14);
                                        this.Controls.Add(this.dcim14);
                                        this.Controls.Add(this.cmb14);
                                        this.Controls.Add(this.lbl15);
                                        this.Controls.Add(this.dcim15);
                                        this.Controls.Add(this.cmb15);
                                        this.Controls.Add(this.lblMiles);
                                        this.Controls.Add(this.dcimMiles);
                                        this.Controls.Add(this.dcedMiles);
                                        this.Controls.Add(this.lbl16);
                                        this.Controls.Add(this.dcim16);
                                        this.Controls.Add(this.cmb16);
                                        this.Controls.Add(this.lbl17UAa);
                                        this.Controls.Add(this.dcim17UAa);
                                        this.Controls.Add(this.cmb17UAa);
                                        this.Controls.Add(this.lbl17UAb);
                                        this.Controls.Add(this.dcim17UAb);
                                        this.Controls.Add(this.cmb17UAb);
                                        this.Controls.Add(this.lbl17UAc);
                                        this.Controls.Add(this.dcim17UAc);
                                        this.Controls.Add(this.cmb17UAc);
                                        this.Controls.Add(this.lbl17UAd);
                                        this.Controls.Add(this.dcim17UAd);
                                        this.Controls.Add(this.cmb17UAd);
                                        this.Controls.Add(this.lbl17UAe);
                                        this.Controls.Add(this.dcim17UAe);
                                        this.Controls.Add(this.cmb17UAe);
                                        this.Controls.Add(this.lbl17UAf);
                                        this.Controls.Add(this.dcim17UAf);
                                        this.Controls.Add(this.cmb17UAf);
                                        this.Controls.Add(this.lbl17UAg);
                                        this.Controls.Add(this.dcim17UAg);
                                        this.Controls.Add(this.cmb17UAg);
                                        this.Controls.Add(this.lbl17ROa);
                                        this.Controls.Add(this.dcim17ROa);
                                        this.Controls.Add(this.cmb17ROa);
                                        this.Controls.Add(this.lbl17ROb);
                                        this.Controls.Add(this.dcim17ROb);
                                        this.Controls.Add(this.cmb17ROb);
                                        this.Controls.Add(this.lbl17ROc);
                                        this.Controls.Add(this.dcim17ROc);
                                        this.Controls.Add(this.cmb17ROc);
                                        this.Controls.Add(this.lbl17ROd);
                                        this.Controls.Add(this.dcim17ROd);
                                        this.Controls.Add(this.cmb17ROd);
                                        this.Controls.Add(this.lbl17ROe);
                                        this.Controls.Add(this.dcim17ROe);
                                        this.Controls.Add(this.cmb17ROe);
                                        this.Controls.Add(this.lbl17ROf);
                                        this.Controls.Add(this.dcim17ROf);
                                        this.Controls.Add(this.cmb17ROf);
                                        this.Controls.Add(this.lbl17ROg);
                                        this.Controls.Add(this.dcim17ROg);
                                        this.Controls.Add(this.cmb17ROg);
                                        this.Controls.Add(this.lbl18);
                                        this.Controls.Add(this.dcim18);
                                        this.Controls.Add(this.cmb18);
                                        this.Controls.Add(this.lbl18Describe);
                                        this.Controls.Add(this.dcim18Describe);
                                        this.Controls.Add(this.dced18Describe);
                             
            this.Name = "Survey_Page2";
            this.Size = new System.Drawing.Size(246, 2829);
                                ((System.ComponentModel.ISupportInitialize)(this.dcim7)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim8)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim9)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim10a)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim10b)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim10c)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim10d)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim11)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim12)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim13)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim14)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim15)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcimMiles)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcedMiles)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim16)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAa)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAb)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAc)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAd)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAe)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAf)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17UAg)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROa)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROb)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROc)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROd)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROe)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROf)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim17ROg)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim18)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dcim18Describe)).EndInit();
                                    ((System.ComponentModel.ISupportInitialize)(this.dced18Describe)).EndInit();
                        
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lbl7;
                                private AxDCIMAGELib.AxDcimage dcim7;
                                private System.Windows.Forms.ComboBox cmb7;
                                private System.Windows.Forms.Label lbl8;
                                private AxDCIMAGELib.AxDcimage dcim8;
                                private System.Windows.Forms.ListBox lst8;
                                private System.Windows.Forms.Label lbl9;
                                private AxDCIMAGELib.AxDcimage dcim9;
                                private System.Windows.Forms.ListBox lst9;
                                private System.Windows.Forms.Label lbl10a;
                                private AxDCIMAGELib.AxDcimage dcim10a;
                                private System.Windows.Forms.ComboBox cmb10a;
                                private System.Windows.Forms.Label lbl10b;
                                private AxDCIMAGELib.AxDcimage dcim10b;
                                private System.Windows.Forms.ComboBox cmb10b;
                                private System.Windows.Forms.Label lbl10c;
                                private AxDCIMAGELib.AxDcimage dcim10c;
                                private System.Windows.Forms.ComboBox cmb10c;
                                private System.Windows.Forms.Label lbl10d;
                                private AxDCIMAGELib.AxDcimage dcim10d;
                                private System.Windows.Forms.ComboBox cmb10d;
                                private System.Windows.Forms.Label lbl11;
                                private AxDCIMAGELib.AxDcimage dcim11;
                                private System.Windows.Forms.ComboBox cmb11;
                                private System.Windows.Forms.Label lbl12;
                                private AxDCIMAGELib.AxDcimage dcim12;
                                private System.Windows.Forms.ListBox lst12;
                                private System.Windows.Forms.Label lbl13;
                                private AxDCIMAGELib.AxDcimage dcim13;
                                private System.Windows.Forms.ComboBox cmb13;
                                private System.Windows.Forms.Label lbl14;
                                private AxDCIMAGELib.AxDcimage dcim14;
                                private System.Windows.Forms.ComboBox cmb14;
                                private System.Windows.Forms.Label lbl15;
                                private AxDCIMAGELib.AxDcimage dcim15;
                                private System.Windows.Forms.ComboBox cmb15;
                                private System.Windows.Forms.Label lblMiles;
                                private AxDCIMAGELib.AxDcimage dcimMiles;
                                private AxDCEDITLib.AxDcedit dcedMiles;
                                private System.Windows.Forms.Label lbl16;
                                private AxDCIMAGELib.AxDcimage dcim16;
                                private System.Windows.Forms.ComboBox cmb16;
                                private System.Windows.Forms.Label lbl17UAa;
                                private AxDCIMAGELib.AxDcimage dcim17UAa;
                                private System.Windows.Forms.ComboBox cmb17UAa;
                                private System.Windows.Forms.Label lbl17UAb;
                                private AxDCIMAGELib.AxDcimage dcim17UAb;
                                private System.Windows.Forms.ComboBox cmb17UAb;
                                private System.Windows.Forms.Label lbl17UAc;
                                private AxDCIMAGELib.AxDcimage dcim17UAc;
                                private System.Windows.Forms.ComboBox cmb17UAc;
                                private System.Windows.Forms.Label lbl17UAd;
                                private AxDCIMAGELib.AxDcimage dcim17UAd;
                                private System.Windows.Forms.ComboBox cmb17UAd;
                                private System.Windows.Forms.Label lbl17UAe;
                                private AxDCIMAGELib.AxDcimage dcim17UAe;
                                private System.Windows.Forms.ComboBox cmb17UAe;
                                private System.Windows.Forms.Label lbl17UAf;
                                private AxDCIMAGELib.AxDcimage dcim17UAf;
                                private System.Windows.Forms.ComboBox cmb17UAf;
                                private System.Windows.Forms.Label lbl17UAg;
                                private AxDCIMAGELib.AxDcimage dcim17UAg;
                                private System.Windows.Forms.ComboBox cmb17UAg;
                                private System.Windows.Forms.Label lbl17ROa;
                                private AxDCIMAGELib.AxDcimage dcim17ROa;
                                private System.Windows.Forms.ComboBox cmb17ROa;
                                private System.Windows.Forms.Label lbl17ROb;
                                private AxDCIMAGELib.AxDcimage dcim17ROb;
                                private System.Windows.Forms.ComboBox cmb17ROb;
                                private System.Windows.Forms.Label lbl17ROc;
                                private AxDCIMAGELib.AxDcimage dcim17ROc;
                                private System.Windows.Forms.ComboBox cmb17ROc;
                                private System.Windows.Forms.Label lbl17ROd;
                                private AxDCIMAGELib.AxDcimage dcim17ROd;
                                private System.Windows.Forms.ComboBox cmb17ROd;
                                private System.Windows.Forms.Label lbl17ROe;
                                private AxDCIMAGELib.AxDcimage dcim17ROe;
                                private System.Windows.Forms.ComboBox cmb17ROe;
                                private System.Windows.Forms.Label lbl17ROf;
                                private AxDCIMAGELib.AxDcimage dcim17ROf;
                                private System.Windows.Forms.ComboBox cmb17ROf;
                                private System.Windows.Forms.Label lbl17ROg;
                                private AxDCIMAGELib.AxDcimage dcim17ROg;
                                private System.Windows.Forms.ComboBox cmb17ROg;
                                private System.Windows.Forms.Label lbl18;
                                private AxDCIMAGELib.AxDcimage dcim18;
                                private System.Windows.Forms.ComboBox cmb18;
                                private System.Windows.Forms.Label lbl18Describe;
                                private AxDCIMAGELib.AxDcimage dcim18Describe;
                                private AxDCEDITLib.AxDcedit dced18Describe;
                        
    }
}
                