
namespace DotEditPanels
{
    partial class Invoice
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Invoice));
            this.lblInvoice_Number = new System.Windows.Forms.Label();
            this.dcimInvoice_Number = new AxDCIMAGELib.AxDcimage();
            this.dcedInvoice_Number = new AxDCEDITLib.AxDcedit();
            this.lblInvoice_Date = new System.Windows.Forms.Label();
            this.dcimInvoice_Date = new AxDCIMAGELib.AxDcimage();
            this.dcedInvoice_Date = new AxDCEDITLib.AxDcedit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInvoice_Number
            // 
            this.lblInvoice_Number.AutoSize = true;
            this.lblInvoice_Number.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Number.Location = new System.Drawing.Point(17, 12);
            this.lblInvoice_Number.Name = "lblInvoice_Number";
            this.lblInvoice_Number.Size = new System.Drawing.Size(136, 18);
            this.lblInvoice_Number.TabIndex = 0;
            this.lblInvoice_Number.Tag = "Invoice Number";
            this.lblInvoice_Number.Text = "Invoice Number";
            // 
            // dcimInvoice_Number
            // 
            this.dcimInvoice_Number.Location = new System.Drawing.Point(20, 33);
            this.dcimInvoice_Number.Name = "dcimInvoice_Number";
            this.dcimInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Number.OcxState")));
            this.dcimInvoice_Number.Size = new System.Drawing.Size(200, 50);
            this.dcimInvoice_Number.TabIndex = 1;
            this.dcimInvoice_Number.TabStop = false;
            this.dcimInvoice_Number.Tag = "Invoice Number";
            // 
            // dcedInvoice_Number
            // 
            this.dcedInvoice_Number.Location = new System.Drawing.Point(20, 87);
            this.dcedInvoice_Number.Name = "dcedInvoice_Number";
            this.dcedInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Number.OcxState")));
            this.dcedInvoice_Number.Size = new System.Drawing.Size(200, 25);
            this.dcedInvoice_Number.TabIndex = 2;
            this.dcedInvoice_Number.Tag = "Invoice Number";
            // 
            // lblInvoice_Date
            // 
            this.lblInvoice_Date.AutoSize = true;
            this.lblInvoice_Date.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Date.Location = new System.Drawing.Point(17, 124);
            this.lblInvoice_Date.Name = "lblInvoice_Date";
            this.lblInvoice_Date.Size = new System.Drawing.Size(112, 18);
            this.lblInvoice_Date.TabIndex = 3;
            this.lblInvoice_Date.Tag = "Invoice Date";
            this.lblInvoice_Date.Text = "Invoice Date";
            // 
            // dcimInvoice_Date
            // 
            this.dcimInvoice_Date.Location = new System.Drawing.Point(20, 145);
            this.dcimInvoice_Date.Name = "dcimInvoice_Date";
            this.dcimInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Date.OcxState")));
            this.dcimInvoice_Date.Size = new System.Drawing.Size(200, 50);
            this.dcimInvoice_Date.TabIndex = 4;
            this.dcimInvoice_Date.TabStop = false;
            this.dcimInvoice_Date.Tag = "Invoice Date";
            // 
            // dcedInvoice_Date
            // 
            this.dcedInvoice_Date.Location = new System.Drawing.Point(20, 199);
            this.dcedInvoice_Date.Name = "dcedInvoice_Date";
            this.dcedInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Date.OcxState")));
            this.dcedInvoice_Date.Size = new System.Drawing.Size(200, 25);
            this.dcedInvoice_Date.TabIndex = 5;
            this.dcedInvoice_Date.Tag = "Invoice Date";
            // 
            // Invoice
            // 
            this.Controls.Add(this.lblInvoice_Number);
            this.Controls.Add(this.dcimInvoice_Number);
            this.Controls.Add(this.dcedInvoice_Number);
            this.Controls.Add(this.lblInvoice_Date);
            this.Controls.Add(this.dcimInvoice_Date);
            this.Controls.Add(this.dcedInvoice_Date);
            this.Name = "Invoice";
            this.Size = new System.Drawing.Size(531, 520);
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lblInvoice_Number;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Number;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Number;
                                private System.Windows.Forms.Label lblInvoice_Date;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Date;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Date;
                        
    }
}
                