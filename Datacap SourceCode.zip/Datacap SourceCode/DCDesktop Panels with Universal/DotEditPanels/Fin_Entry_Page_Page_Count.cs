//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;
using System.Configuration;
using System.Data.OleDb;



namespace DotEditPanels
{
    public partial class Fin_Entry_Page_Page_Count : dotPanelBase
    {
       

        public Fin_Entry_Page_Page_Count()
        {
            InitializeComponent();


        }

        public override bool StartBatch()
        {

            bool bRes = base.StartBatch();
            var dcapp = new DCAppleLib.DirectAppList();
            //DCAppleLib.IDCAppInfo appInf = null;
            //string sINIFilePath = "";

            dcedDocumentType.Visible = false;
            cmb_Function.Visible = true;
            dcedFunction.Visible = false;
            dcedVendorName.Visible = false;

            if (dcedUniqueCode.CtlText != "")
            {
                cmb_UniqueCode.SelectedValue = dcedUniqueCode.CtlText;
            }
            if (dcedEntity.CtlText != "")
            {
            }
            if (dcedDocumentType.CtlText == "")
            {
                dcedIssueDate.Visible = false;
                dcedLicensors.Visible = false;
                dcedPropertyAddress.Visible = false;
                dcedTenure.Visible = false;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = false;
                lblLicensors.Visible = false;
                lblPropertyAddress.Visible = false;
                lblTenure.Visible = false;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = false;

            }
            else if (dcedDocumentType.CtlText.Contains("Registered Agreement"))
            {
                dcedIssueDate.Visible = true;
                dcedLicensors.Visible = true;
                dcedPropertyAddress.Visible = true;
                dcedTenure.Visible = true;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = true;
                lblLicensors.Visible = true;
                lblPropertyAddress.Visible = true;
                lblTenure.Visible = true;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = true;
            }
            else if (dcedDocumentType.CtlText.Contains("Letter of Intent"))
            {
                dcedIssueDate.Visible = true;
                dcedLicensors.Visible = true;
                dcedPropertyAddress.Visible = true;
                dcedTenure.Visible = false;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = true;
                lblLicensors.Visible = true;
                lblPropertyAddress.Visible = true;
                lblTenure.Visible = false;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = true;
            }


            try
            {
                OleDbConnection con = new OleDbConnection(getconnectionstring());
                con.Open();
                string command = "select * from ADMINISTRATOR.UNIQUE_CODE";
                DataTable dtuniquecode = new DataTable();
                OleDbCommand cmd = new OleDbCommand(command, con);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dtuniquecode);


                DataRow rows = dtuniquecode.NewRow();
                rows["UNIQUE_CODE"] = "SELECT";
                dtuniquecode.Rows.InsertAt(rows, 0);
                this.cmb_UniqueCode.SelectedIndexChanged -= new EventHandler(cmb_UniqueCode_SelectedIndexChanged);
                cmb_UniqueCode.DisplayMember = "UNIQUE_CODE";
                cmb_UniqueCode.ValueMember = "UNIQUE_CODE";
                cmb_UniqueCode.DataSource = dtuniquecode;
                this.cmb_UniqueCode.SelectedIndexChanged += new EventHandler(cmb_UniqueCode_SelectedIndexChanged);
                this.cmb_UniqueCode.AutoCompleteMode = AutoCompleteMode.Suggest;
                this.cmb_UniqueCode.AutoCompleteSource = AutoCompleteSource.ListItems;

                fillfunction();
                filldoctype();
                string command4 = "select DISTINCT VENDOR_NAME from ADMINISTRATOR.VENDOR_DETAILS";
                DataTable dtVendorname = new DataTable();

                OleDbCommand cmd4 = new OleDbCommand(command4, con);
                OleDbDataAdapter da4 = new OleDbDataAdapter(cmd4);
                da4.Fill(dtVendorname);

                DataRow rowVendorname = dtVendorname.NewRow();
                rowVendorname["VENDOR_NAME"] = "SELECT";
                dtVendorname.Rows.InsertAt(rowVendorname, 0);
                this.cmb_VendorName.SelectedIndexChanged -= new EventHandler(cmb_VendorName_SelectedIndexChanged);
                cmb_VendorName.DisplayMember = "VENDOR_NAME";
                cmb_VendorName.ValueMember = "VENDOR_NAME";
                cmb_VendorName.DataSource = dtVendorname;
                this.cmb_VendorName.SelectedIndexChanged += new EventHandler(cmb_VendorName_SelectedIndexChanged);


                con.Close();



                if (dcedDocumentType.CtlText != "")
                {
                    try
                    {

                        string connectionstring = getconnectionstring();

                        OleDbConnection con2 = new OleDbConnection(connectionstring);
                        con2.Open();

                        string command2 = "select  FUNCTION from ADMINISTRATOR.FUNCTION_DOCTYPE where DOCUMENT_TYPE='" + dcedDocumentType.CtlText + "'";

                        //if (cmb_DocumentType.Text == "" || cmb_DocumentType.Text == "SELECT" || cmb_DocumentType.Text == "System.Data.DataRowView")
                        //{
                        //    // filldoctype();
                        //}
                        //else
                        //{
                        string s2 = dcedDocumentType.CtlText;

                        OleDbCommand cmd2 = new OleDbCommand(command2, con2);
                        DataTable dtdoc = new DataTable();

                        OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                        filldoctype();

                        da2.Fill(dtdoc);

                        string s = "";
                        if (dtdoc.Rows.Count == 1)
                        {
                            foreach (DataRow row in dtdoc.Rows)
                            {

                                s = row["FUNCTION"].ToString();
                            }
                            cmb_Function.SelectedValue = s;
                            cmb_DocumentType.SelectedValue = s2;

                        }



                    }

                        //}

                    catch (Exception ex) { }



                }


            }
            catch (Exception ex)
            {

            }

            return bRes;


        }

        public void fillfunction()
        {
            try
            {
                string connectionstring = getconnectionstring();

                OleDbConnection con = new OleDbConnection(connectionstring);
                con.Open();

                string command = "select distinct FUNCTION from ADMINISTRATOR.FUNCTION_DOCTYPE order by FUNCTION asc";

                OleDbCommand cmd = new OleDbCommand(command, con);
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                DataRow row = dt.NewRow();
                row["FUNCTION"] = "SELECT";
                dt.Rows.InsertAt(row, 0);
                this.cmb_Function.SelectedIndexChanged -= new EventHandler(cmb_Function_SelectedIndexChanged);
                cmb_Function.DisplayMember = "FUNCTION";
                cmb_Function.ValueMember = "FUNCTION";
                cmb_Function.DataSource = dt;
                this.cmb_Function.SelectedIndexChanged += new EventHandler(cmb_Function_SelectedIndexChanged);

                con.Close();
            }
            catch (Exception ex) { }
        }
        public void filldoctype()
        {
            try
            {
                string connectionstring = getconnectionstring();

                OleDbConnection con = new OleDbConnection(connectionstring);
                con.Open();

                string command = "select DOCUMENT_TYPE from ADMINISTRATOR.FUNCTION_DOCTYPE order by DOCUMENT_TYPE asc ";
                OleDbCommand cmd = new OleDbCommand(command, con);
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                DataRow row = dt.NewRow();
                row["DOCUMENT_TYPE"] = "SELECT";
                dt.Rows.InsertAt(row, 0);
                this.cmb_DocumentType.SelectedIndexChanged -= new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                cmb_DocumentType.DisplayMember = "DOCUMENT_TYPE";
                cmb_DocumentType.ValueMember = "DOCUMENT_TYPE";
                cmb_DocumentType.DataSource = dt;
                this.cmb_DocumentType.SelectedIndexChanged += new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                con.Close();
            }
            catch (Exception ex)
            {

            }
        }
        public void filldoctype(string selectedfunction)
        {
            try
            {
                string connectionstring = getconnectionstring();

                OleDbConnection con = new OleDbConnection(connectionstring);
                con.Open();

                string command = "select DOCUMENT_TYPE from ADMINISTRATOR.FUNCTION_DOCTYPE where FUNCTION='" + selectedfunction + "' order by DOCUMENT_TYPE asc";

                OleDbCommand cmd = new OleDbCommand(command, con);
                DataTable dt = new DataTable();

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                da.Fill(dt);
                DataRow row = dt.NewRow();
                row["DOCUMENT_TYPE"] = "SELECT";
                dt.Rows.InsertAt(row, 0);
                this.cmb_DocumentType.SelectedIndexChanged -= new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                cmb_DocumentType.DisplayMember = "DOCUMENT_TYPE";
                cmb_DocumentType.ValueMember = "DOCUMENT_TYPE";
                cmb_DocumentType.DataSource = dt;
                this.cmb_DocumentType.SelectedIndexChanged += new EventHandler(cmb_DocumentType_SelectedIndexChanged);

                con.Close();
            }
            catch (Exception e)
            {

            }
        }

        private void cmb_DocumentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                //dcedDocumentType.CtlText = cmb_DocumentType.Text;
                //dcedDocumentType.Focus();

                dcedDocumentType.CtlText = cmb_DocumentType.Text;
                dcedDocumentType.Visible = true;
                dcedDocumentType.Focus();
                dcedDocumentType.Visible = false;
                if (cmb_DocumentType.SelectedValue != null)
                {
                    if (cmb_DocumentType.SelectedValue != "SELECT")
                    {

                        string connectionstring = getconnectionstring();

                        OleDbConnection con = new OleDbConnection(connectionstring);
                        con.Open();

                        string command = "select  FUNCTION from ADMINISTRATOR.FUNCTION_DOCTYPE where DOCUMENT_TYPE='" + cmb_DocumentType.Text + "'";

                        if (cmb_DocumentType.Text == "" || cmb_DocumentType.Text == "SELECT" || cmb_DocumentType.Text == "System.Data.DataRowView")
                        {
                            // filldoctype();
                        }
                        else
                        {
                            string s2 = cmb_DocumentType.SelectedValue.ToString();

                            OleDbCommand cmd = new OleDbCommand(command, con);
                            DataTable dt = new DataTable();

                            OleDbDataAdapter da = new OleDbDataAdapter(cmd);


                            da.Fill(dt);

                            string s = "";
                            if (dt.Rows.Count == 1)
                            {
                                foreach (DataRow row in dt.Rows)
                                {

                                    s = row["FUNCTION"].ToString();
                                }
                                this.cmb_Function.SelectedIndexChanged -= new EventHandler(cmb_Function_SelectedIndexChanged);
                                this.cmb_DocumentType.SelectedIndexChanged -= new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                                cmb_Function.SelectedValue = s;
                                cmb_DocumentType.SelectedValue = s2;

                                this.cmb_Function.SelectedIndexChanged += new EventHandler(cmb_Function_SelectedIndexChanged);
                                this.cmb_DocumentType.SelectedIndexChanged += new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                                dcedFunction.Visible = true;
                                this.dcedFunction.CtlText = this.cmb_Function.SelectedValue.ToString();
                                dcedFunction.Focus();
                                dcedFunction.Visible = false;
                               

                            }

                        }
                        string s1 = dcedDocumentType.CtlText;


                        cmb_DocumentType.Refresh();
                        if (cmb_DocumentType.SelectedValue.ToString() == "" || cmb_DocumentType.SelectedValue.ToString() == "SELECT")
                        {
                            dcedIssueDate.Visible = false;
                            dcedLicensors.Visible = false;
                            dcedPropertyAddress.Visible = false;
                            dcedTenure.Visible = false;
                            dcedVendorName.Visible = false;
                            lblIssueDate.Visible = false;
                            cmb_VendorName.Visible = false;
                            lblLicensors.Visible = false;
                            lblPropertyAddress.Visible = false;
                            lblTenure.Visible = false;
                            lblVendorName.Visible = false;
                            dtp_IssueDate.Visible = false;

                        }
                        else if (cmb_DocumentType.SelectedValue.ToString().Contains("Registered Agreement"))
                        {
                            dcedIssueDate.Visible = true;
                            dcedLicensors.Visible = true;
                            dcedPropertyAddress.Visible = true;
                            dcedTenure.Visible = true;
                            dcedVendorName.Visible = false;
                            cmb_VendorName.Visible = false;
                            lblIssueDate.Visible = true;
                            lblLicensors.Visible = true;
                            lblPropertyAddress.Visible = true;
                            lblTenure.Visible = true;
                            lblVendorName.Visible = false;
                            dtp_IssueDate.Visible = true;
                        }
                        else if (cmb_DocumentType.SelectedValue.ToString().Contains("Letter of Intent"))
                        {
                            dcedIssueDate.Visible = true;
                            dcedLicensors.Visible = true;
                            dcedPropertyAddress.Visible = true;
                            dcedTenure.Visible = false;
                            dcedVendorName.Visible = false;
                            cmb_VendorName.Visible = false;
                            lblIssueDate.Visible = true;
                            lblLicensors.Visible = true;
                            lblPropertyAddress.Visible = true;
                            lblTenure.Visible = false;
                            lblVendorName.Visible = false;
                            dtp_IssueDate.Visible = true;
                            // cmb_Function.SelectedItem = "";
                        }
                        else
                        {
                            try
                            {
                                OleDbConnection con1 = new OleDbConnection(getconnectionstring());
                                con1.Open();
                                string command1 = "select FIELD_STATUS from ADMINISTRATOR.FUNCTION_DOCTYPE where DOCUMENT_TYPE='" + dcedDocumentType.CtlText + "'";
                                DataTable dt = new DataTable();
                                OleDbCommand cmd = new OleDbCommand(command1, con1);
                                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                da.Fill(dt);
                                con.Close();
                                string vendornamefieldstatus = string.Empty;
                                if (dt.Rows.Count > 0)
                                {
                                    vendornamefieldstatus = dt.Rows[0][0].ToString();// row["FIELD_STATUS"].ToString();
                                    if (vendornamefieldstatus == "NO")
                                    {

                                        dcedVendorName.Visible = false;
                                        cmb_VendorName.Visible = false;
                                        lblVendorName.Visible = false;


                                    }
                                    else
                                    {

                                        dcedVendorName.Visible = false;
                                        cmb_VendorName.Visible = true;
                                        lblVendorName.Visible = true;


                                    }
                                    dcedIssueDate.Visible = false;
                                    dcedLicensors.Visible = false;
                                    dcedPropertyAddress.Visible = false;
                                    dcedTenure.Visible = false;
                                    lblIssueDate.Visible = false;
                                    lblLicensors.Visible = false;
                                    lblPropertyAddress.Visible = false;
                                    lblTenure.Visible = false;
                                    dtp_IssueDate.Visible = false;
                                }



                            }
                            catch (Exception ex)
                            {

                            }
                        }

                    }
                }
            }
            catch (Exception ex) { }



        }

        private void cmb_UniqueCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_UniqueCode.SelectedValue != "SELECT")
            {
                try
                {
                    dcedUniqueCode.Visible = true;
                    this.dcedUniqueCode.CtlText = this.cmb_UniqueCode.Text;
                    dcedUniqueCode.Focus();
                    dcedUniqueCode.Visible = false;
                    OleDbConnection con = new OleDbConnection(@"Provider=IBMDADB2;Database=SAMPLE;Hostname=localhost;Port=50000;Uid=db2admin;Pwd=mits123$;Protocol=TCPIP");
                    con.Open();
                    string command = "select * from ADMINISTRATOR.UNIQUE_CODE where UNIQUE_CODE='" + cmb_UniqueCode.SelectedValue + "'";
                    DataTable dtuniquecode = new DataTable();
                    OleDbCommand cmd = new OleDbCommand(command, con);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    da.Fill(dtuniquecode);
                    con.Close();
                    foreach (DataRow row in dtuniquecode.Rows)
                    {
                        this.dcedEntity.CtlText = row["ENTITY"].ToString();
                        dcedEntity.Focus();
                        this.dcedPrimaryUser.CtlText = row["PRIMARY_USER"].ToString();
                        dcedPrimaryUser.Focus();
                        this.dcedRegion.CtlText = row["REGION"].ToString();
                        dcedRegion.Focus();
                        this.dcedState.CtlText = row["STATE"].ToString();
                        dcedState.Focus();
                        this.dcedCity.CtlText = row["CITY"].ToString();
                        dcedCity.Focus();

                    }


                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                dcedEntity.CtlText = String.Empty;
                dcedPrimaryUser.CtlText = String.Empty;
                dcedRegion.CtlText = String.Empty;
                dcedState.CtlText = String.Empty;
                dcedCity.CtlText = String.Empty;
            }
        }

        private void cmb_Function_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmb_Function.Text != "SELECT")
            {
                dcedFunction.Visible = true;
                this.dcedFunction.CtlText = cmb_Function.SelectedValue.ToString();
                dcedFunction.Focus();
                dcedFunction.Visible = false;
                //filldoctype with selected function
                filldoctype(cmb_Function.SelectedValue.ToString());
            }
            else
            {
                // cmb_DocumentType.DataSource=null;
                filldoctype();
                dcedIssueDate.Visible = false;
                dcedLicensors.Visible = false;
                dcedPropertyAddress.Visible = false;
                dcedTenure.Visible = false;
                dcedVendorName.Visible = false;
                lblIssueDate.Visible = false;
                cmb_VendorName.Visible = false;
                lblLicensors.Visible = false;
                lblPropertyAddress.Visible = false;
                lblTenure.Visible = false;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = false;

            }



        }

        private void dtp_IssueDate_ValueChanged(object sender, EventArgs e)
        {
            dcedIssueDate.CtlText = dtp_IssueDate.Value.ToString("dd/MM/yyyy");
        }
        public string getqueryuniquecode()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(getxmlpath());
            XmlNode queyr1 = doc.DocumentElement.SelectSingleNode("Query1");
            string q1 = queyr1.InnerText.ToString();
            return q1;

        }
        public string getquerydoctype()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(getxmlpath());
            XmlNode query = doc.DocumentElement.SelectSingleNode("Query2");
            string q = query.InnerText.ToString();
            return q;

        }
        public string getconnectionstring()
        {

            XmlDocument doc = new XmlDocument();
            doc.Load(getxmlpath());

            XmlNode Cs_list = doc.DocumentElement.SelectSingleNode("ConnectionString");
            string cs = @Cs_list.InnerText.ToString();
            return cs;
        }
        public string getxmlpath()
        {
            // string configurationFilePath= ConfigurationSettings.AppSettings["configurationFilePath"].ToString();
            string configurationFilePath = @"C:\Datacap\Desktop_Panel\cs.xml";
            return configurationFilePath;
        }
        public OleDbConnection getConnection()
        {

            OleDbConnection myConn = new OleDbConnection(getconnectionstring());
            return myConn;
        }
        private void dcedEntity_Change(object sender, EventArgs e)
        {
            if (dcedEntity.CtlText == "Edelweiss Commodities Services Limited")
            {
                dcedTenure.Visible = false;
                lblTenure.Visible = false;
            }
            else if (dcedEntity.CtlText == "")
            {

            }
        }
        //private void InitializeConfiguration()
        //{
        //    // Debug.Write("InitializeConfiguration");
        //    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
        //    string str = this.getUserSetting("configurationFile");
        //    // Debug.Write("Fetch configuration file name from App.Config = " + str);
        //    fileMap.ExeConfigFilename = str;
        //  //  this.applicationConfiguration = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
        //}
        private string getUserSetting(string key)
        {
            string lstrUserSetting = string.Empty;
            try
            {
                //System.Configuration.Configuration config = GetConfig(typeof(Fin_Entry_Page_Page_Count));
                //ConfigurationSectionGroup group = config.SectionGroups["userSettings"];
                //ClientSettingsSection section = (ClientSettingsSection)group.Sections["ApplicationConfig"];
                //lstrUserSetting = section.Settings.Get(key).Value.ValueXml.InnerText;
            }
            catch (Exception ex)
            {
                MessageBox.Show("User Config File - " + ex);
            }

            return lstrUserSetting;

            //Debug.Write("getting user setting for key = " + key);
            //ConfigurationSectionGroup group = ConfigurationManager.OpenExeConfiguration(0).SectionGroups["userSettings"];
            //ClientSettingsSection section = (ClientSettingsSection) group.Sections["ApplicationConfig"];
            //return section.Settings.Get(key).Value.ValueXml.InnerText;
        }
        //private string getDBSqlString(string key)
        //{
        //    //ConfigurationSectionGroup group = this.applicationConfiguration.SectionGroups["AppSettings"];
        //    //ClientSettingsSection section = (ClientSettingsSection)group.Sections["DB"];
        //    //return section.Settings.Get(key).Value.ValueXml.InnerText;
        //}
     //   public static System.Configuration.Configuration GetConfig(Type type)
        //{
        //    //workout app.config lokcation
        //    string dllLocation = type.Assembly.Location + ".config";
        //    if (dllLocation == null)
        //        throw new Exception("Could not find config file, add .config in DLL location");


        //    //create config
        //    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
        //    fileMap.ExeConfigFilename = dllLocation;
        //    System.Configuration.Configuration config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

        //    return config;
        //}
        private void cmb_VendorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                dcedVendorName.Visible = true;
                dcedVendorName.CtlText = cmb_VendorName.SelectedValue.ToString();
                dcedVendorName.Focus();
                dcedVendorName.Visible = false;
            }
            catch (Exception ex)
            {
            }


        }


        public void filldatatotextfields()
        {
            if (cmb_VendorName.SelectedValue != "SELECT" && cmb_UniqueCode.SelectedValue != "SELECT" && cmb_Function.SelectedValue != "SELECT" && cmb_DocumentType.SelectedValue != "SELECT")
            {
                dcedDocumentType.CtlText = cmb_DocumentType.SelectedValue.ToString();

                dcedFunction.CtlText = cmb_Function.SelectedValue.ToString();
                dcedIssueDate.CtlText = dtp_IssueDate.Value.ToString("dd/MM/yyyy");

                dcedUniqueCode.CtlText = cmb_UniqueCode.SelectedValue.ToString();
                dcedVendorName.CtlText = cmb_VendorName.SelectedValue.ToString();
            }
            else
            {
                MessageBox.Show("please Select ");

            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            //XmlDocument doc = new XmlDocument();
            //doc = dcTask.BatchXML;
            //XmlNode node = dcTask.BatchXML.SelectSingleNode("(/*)");           
            //MessageBox.Show("doctype " + dcedDocumentType.CtlText);
            //MessageBox.Show("entity " + dcedEntity.CtlText);
            //MessageBox.Show("function " + dcedFunction.CtlText);
            //MessageBox.Show("issuedate " + dcedIssueDate.CtlText);
            //MessageBox.Show("licensors " + dcedLicensors.CtlText);
            //MessageBox.Show("primaryuser " + dcedPrimaryUser.CtlText);
            //MessageBox.Show("propertyaddress " + dcedPropertyAddress.CtlText);
            //MessageBox.Show("Region " + dcedRegion.CtlText);
            //MessageBox.Show("state " + dcedState.CtlText);
            //MessageBox.Show("tenure " + dcedTenure.CtlText);
            MessageBox.Show("unique " + dcedUniqueCode.CtlText);
            //MessageBox.Show("vendorname " + dcedVendorName.CtlText);
            //MessageBox.Show("city " + dcedCity.CtlText);
        }

        private void Fin_Entry_Page_Page_Count_Load(object sender, EventArgs e)
        {



        }

        public override bool LoadData(XmlDocument xPage)
        {
            bool bRetn = false;

            //try
            //{
                bRetn = base.LoadData(xPage);

                string sPageID = xDataPage.DocumentElement.Attributes["id"].Value;
                //MessageBox.Show(sPageID);
                //XmlNode pVar = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + sPageID + "']/V[@n='POLRresult']");
                //if (pVar != null)
                //{
                //    // lblPOLR.Text = "POLR: " + pVar.InnerText;
                //    POLRBtn.Text = sPOLRBtnText + " " + pVar.InnerText;
                //}

                ////lblStickyFinger.Visible = false;
                //StickyBtn.Visible = false;

                //if (dcedVendor.CtlText == "<New>" || dcedVendor.CtlText == "")
                //{
                //    pVar = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + sPageID + "']/V[@n='TemplateID']");
                //    if (pVar != null)
                //    {
                //        XmlNodeList pInvs = dcTask.BatchXML.SelectNodes(".//P[V[@n='TYPE']='Main_Page']");
                //        foreach (XmlNode pInv in pInvs)
                //        {
                //            if (pInv.Attributes["id"].Value == sPageID)
                //                break;
                //            XmlNode pTemp = pInv.SelectSingleNode("V[@n='TemplateID']");
                //            if (pTemp != null && pTemp.InnerText == pVar.InnerText)
                //            {
                //                StickyBtn.Visible = true;
                //                break;
                //            }
                //        }
                //    }
                //}

            //    if (enableLocalDate)
            //    {
            //        // The page was just loaded, so reset the date to match the default date format for the locale for the user.
            //        // This is called when a page is loaded and after a task profile is run.
            //        dcedInvoice_Date.CtlText = adjustDateToLocaleOrYMD(dcedInvoice_Date.CtlText, false);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    dcTask.WriteLog(5, "APT Panel LoadData Exception: " + ex.Message + "  Details: " + ex.ToString());
            //}

            return bRetn;
        }
    }
}
