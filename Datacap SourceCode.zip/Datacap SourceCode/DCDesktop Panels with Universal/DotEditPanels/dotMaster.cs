//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Xml;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using System.Resources;

namespace DotEditPanels
{
    public partial class dotMaster : UserControl
    {

        const string sMainFormCase = @" 
                    case ""{0}"": 
                    {2}
                        Crownwood.DotNetMagic.Controls.TabPage tPage = new Crownwood.DotNetMagic.Controls.TabPage(""{0}"");
                        tPage.SuspendLayout();
                        tPage.Dock = DockStyle.Fill;
                        tPage.AutoScroll = true;
                        tPage.AutoSize = false;
                        tPage.AutoSizeMode = AutoSizeMode.GrowOnly;
                        tabControl1.TabPages.Add(tPage);
                        tabControl1.TabPages[tabControl1.TabPages.Count-1].Controls.Add(new DotEditPanels.{1}());
                        tabControl1.TabPages[tabControl1.TabPages.Count - 1].Tag = ""{0}"";
                        tPage.ResumeLayout(true);
                        break;
                    {3}
        ";

        const string sCSProj = @"
<project xmlns=""http://schemas.microsoft.com/developer/msbuild/2003"">
    <Compile Include=""{0}.cs"">
      <SubType>UserControl</SubType>
    </Compile>
    <Compile Include=""{0}.Designer.cs"">
      <DependentUpon>{0}.cs</DependentUpon>
    </Compile>
    <EmbeddedResource Include=""{0}.resx"">
      <SubType>Designer</SubType>
      <DependentUpon>{0}.cs</DependentUpon>
    </EmbeddedResource>
</project>
        ";
        

        const string sSourceXML=@"
            <xml>
                <class>
                <header>
namespace DotEditPanels
{
    partial class dummy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing &amp;&amp; (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dummy));
                </header>

                <content>
                    <beginInit>
                    </beginInit>
                    <initializeX>
                    </initializeX>
                    <controls>
            this.SuspendLayout();
                    </controls>
                    <endInit>
                    </endInit>
                    <userControl> 
            this.Name = ""dummy"";
            this.Size = new System.Drawing.Size({0}, {1});
                    </userControl>
                </content>
                <finalizeX>
                </finalizeX>
                <panelFooter>
                </panelFooter>
                <footer>
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                </footer>
                <decl>
                </decl>
                <remaining>
    }
}
                </remaining>
            </class>
                <controlTemplates>
                    <Control>
                        <content>
                            <beginInit>
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>
                            </controls>
                            <endInit>
                            </endInit>
                        </content>
                        <finalizeX>
                        </finalizeX>
                        <decl>
                        </decl>
                    </Control>
                    <PanelButtons>
                        <content>
                            <beginInit>            this.btnInsBefore{0} = new System.Windows.Forms.Button();
            this.btnInsAfter{0} = new System.Windows.Forms.Button();
            this.btnDel{0} = new System.Windows.Forms.Button();
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>            // 
            // btnInsBefore
            // 
            this.btnInsBefore{0}.Location = new System.Drawing.Point({1}, Combine({2}+25));
            this.btnInsBefore{0}.Name = ""btnInsBefore{0}"";
            this.btnInsBefore{0}.Size = new System.Drawing.Size({6},{7});
            this.btnInsBefore{0}.TabIndex = {4};
            this.btnInsBefore{0}.Text = ""Insert"";
            this.btnInsBefore{0}.Tag = ""{3}"";
            this.btnInsBefore{0}.UseVisualStyleBackColor = true;
            // 
            // btnInsAfter
            // 
            this.btnInsAfter{0}.Location = new System.Drawing.Point(Combine({1}+60), Combine({2}+25));
            this.btnInsAfter{0}.Name = ""btnInsAfter{0}"";
            this.btnInsAfter{0}.Size = new System.Drawing.Size({6},{7});
            this.btnInsAfter{0}.TabIndex = Combine({4}+1);
            this.btnInsAfter{0}.Text = ""Append"";
            this.btnInsAfter{0}.Tag = ""{3}"";
            this.btnInsAfter{0}.UseVisualStyleBackColor = true;
            // 
            // btnDel
            // 
            this.btnDel{0}.Location = new System.Drawing.Point(Combine({1}+120), Combine({2}+25));
            this.btnDel{0}.Name = ""btnDel{0}"";
            this.btnDel{0}.Size = new System.Drawing.Size({6},{7});
            this.btnDel{0}.TabIndex = Combine({4}+2);
            this.btnDel{0}.Text = ""Delete"";
            this.btnDel{0}.Tag = ""{3}"";
            this.btnDel{0}.UseVisualStyleBackColor = true;
                            </controls>
                            <endInit>            this.Controls.Add(this.btnDel{0});
            this.Controls.Add(this.btnInsAfter{0});
            this.Controls.Add(this.btnInsBefore{0});
                            </endInit>
                        </content>
                        <finalizeX>
                        </finalizeX>
                        <decl>        private System.Windows.Forms.Button btnInsBefore{0};
        private System.Windows.Forms.Button btnInsAfter{0};
        private System.Windows.Forms.Button btnDel{0};
                        </decl>
                    </PanelButtons>
                    <Panel>
                        <content>
                            <beginInit>             this.{0} = new System.Windows.Forms.Panel();
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>              this.{0}.SuspendLayout();

            // 
            // panel1
            // 
            this.{0}.AutoScroll = true;
            this.{0}.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>               this.Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <panelFooter>               this.{0}.ResumeLayout();
                        </panelFooter>
                        <decl>      private System.Windows.Forms.Panel {0};
                        </decl>
                    </Panel>
                    <Label>
                        <content>
                            <beginInit>            this.{0} = new System.Windows.Forms.Label();
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>            // 
            // {0}
            // 
            this.{0}.AutoSize = true;
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Text = ""{8}"";  //caption
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <finalizeX>
                        </finalizeX>
                        <decl>        private System.Windows.Forms.Label {0};
                        </decl>
                    </Label>
                    <DcEdit>
                        <content>
                            <beginInit>            this.{0} = new AxDCEDITLib.AxDcedit();
                            </beginInit>
                            <initializeX>
            ((System.ComponentModel.ISupportInitialize)(this.{0})).BeginInit();
                            </initializeX>
                            <controls>            // 
            // {0}
            // 
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject(""dcedit.OcxState"")));
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <finalizeX>            ((System.ComponentModel.ISupportInitialize)(this.{0})).EndInit();
                        </finalizeX>
                        <decl>        private AxDCEDITLib.AxDcedit {0};
                        </decl>
                    </DcEdit>
                    <ListBox>
                        <content>
                            <beginInit>            this.{0} = new System.Windows.Forms.ListBox();
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>            // 
            // {0}
            // 
            this.{0}.FormattingEnabled = true;
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <finalizeX>
                        </finalizeX>
                        <decl>        private System.Windows.Forms.ListBox {0};
                        </decl>
                    </ListBox>
                    <ComboBox>
                        <content>
                            <beginInit>            this.{0} = new System.Windows.Forms.ComboBox();
                            </beginInit>
                            <initializeX>
                            </initializeX>
                            <controls>            // 
            // {0}
            // 
            this.{0}.FormattingEnabled = true;
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <finalizeX>
                        </finalizeX>
                        <decl>        private System.Windows.Forms.ComboBox {0};
                        </decl>
                    </ComboBox>
                    <TextBox>
                        <content>
                            <beginInit>            this.{0} = new System.Windows.Forms.TextBox();
                            </beginInit>
                            <controls>            // 
            // {0}
            // 
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <decl>        private System.Windows.Forms.TextBox {0};
                        </decl>
                    </TextBox>
                    <Image>
                        <content>
                            <beginInit>            this.{0} = new AxDCIMAGELib.AxDcimage();
                            </beginInit>
                            <initializeX>            ((System.ComponentModel.ISupportInitialize)(this.{0})).BeginInit();
                            </initializeX>
                            <controls>            // 
            // {0}
            // 
            this.{0}.Enabled = true;
            this.{0}.Location = new System.Drawing.Point({1}, {2});
            this.{0}.Name = ""{0}"";
            this.{0}.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject(""dcimage.OcxState"")));
            this.{0}.Size = new System.Drawing.Size({6},{7});
            this.{0}.TabIndex = {4};
            this.{0}.TabStop = false;
            this.{0}.Tag = ""{3}"";
                            </controls>
                            <endInit>            this.{5}Controls.Add(this.{0});
                            </endInit>
                        </content>
                        <finalizeX>            ((System.ComponentModel.ISupportInitialize)(this.{0})).EndInit();
                        </finalizeX>
                        <decl>        private AxDCIMAGELib.AxDcimage {0};
                        </decl>
                    </Image>
                </controlTemplates>
            </xml>            
            ";
        

        public dotMaster()
        {
            InitializeComponent();
            Process p = Process.GetCurrentProcess();
            ProcessModuleCollection pColl = p.Modules;
            foreach (ProcessModule pMod in pColl)
            {
                if (pMod.ModuleName.ToLower() == "doteditpanels.dll".ToLower())
                {
                    sProjectRoot = pMod.FileName.Substring(0, pMod.FileName.LastIndexOf("\\obj\\"));
                    break;
                }
            }

        }

        XmlDocument xSetup = new XmlDocument();
        XmlDocument xOut = new XmlDocument();
        XmlDocument xLayout = new XmlDocument(); //xml layout file generated by bpilot scriptlib.xml code
 
        int nXPlus = 150;
              
        public string CreateNewLayout(string sType, string sNewName)
        {
//            xOut.PreserveWhitespace = true;
            xOut.LoadXml(sSourceXML.Replace("dummy", sNewName));
            XmlNode xParent = xSetup.SelectSingleNode("/S/*[@type='" + sType + "']");
            if (xParent == null)
                return "";

            AdjustDifferences();

            //add layout structure details from scriptlib generated file to setup xml nodes
            Mergelayout(xSetup, xLayout);

            GenerateLevel(xSetup, xOut, xParent.SelectNodes("F"));
               
            string[] arSize = formSize.Split(',');
            xOut.SelectSingleNode(".//userControl").InnerText = string.Format(xOut.SelectSingleNode(".//userControl").InnerText, arSize[0]/*(nX + nXPlus).ToString()*/, (nYMy + nYOffset).ToString());
            return xOut.SelectSingleNode(".//class").InnerText;
                     
        }

        int nY = 30;
        int nYMy = 0;
        int nYMax = 0;
        int nX = 30;
        int nTab = 0;
        int nYOffset = 0;
        int nXOffset = 0;
        
        int nCurField = 1;

        public void AppendResult(string sName, string sTag, XmlNode pNode, XmlDocument xOut, string sPanel, int nHorzIdx, XmlNode xSetupNode)
        {   /*
             * sName :
             * sTag  :
             * pNode :
             * xOut  :
             * sPanel :
             * nHorzIdx :
             * xSetupNode : Setup DCO field node 
     */       
            //Std sizes for controls
            string slbl_w = "0";
            string slbl_h = "0";
            string slbl_l = "0";
            string slbl_t = "0";
            string slbl_c = "";

            //Flag to create by type
            bool bHasLayoutData = false;

            //Get setupnode layout nodes
            XmlNode xlabel = xSetupNode.SelectSingleNode("label");
            if (xlabel != null)
            {
                bHasLayoutData = true;

                slbl_w = xlabel.Attributes["w"].Value;
                slbl_h = xlabel.Attributes["h"].Value;
                slbl_l = xlabel.Attributes["l"].Value;
                slbl_t = xlabel.Attributes["t"].Value;
                slbl_c = xlabel.Attributes["caption"].Value;

                //remove decimal from original value
                if (slbl_w.Contains("."))
                    slbl_w = slbl_w.Substring(0, slbl_w.IndexOf("."));

                if (slbl_h.Contains("."))
                    slbl_h = slbl_h.Substring(0, slbl_h.IndexOf("."));
            }

            string sdci_w = "0";
            string sdci_h = "0";
            string sdci_l = "0";
            string sdci_t = "0";

            XmlNode xdcimage = xSetupNode.SelectSingleNode("dcimage");
            if (xdcimage != null)
            {
                bHasLayoutData = true;

                sdci_w = xdcimage.Attributes["w"].Value;
                sdci_h = xdcimage.Attributes["h"].Value;
                sdci_l = xdcimage.Attributes["l"].Value;
                sdci_t = xdcimage.Attributes["t"].Value;

                //remove decimal from original value
                if (sdci_w.Contains("."))
                    sdci_w = sdci_w.Substring(0, sdci_w.IndexOf("."));

                if (sdci_h.Contains("."))
                    sdci_h = sdci_h.Substring(0, sdci_h.IndexOf("."));
            }

            string sdce_w = "0";
            string sdce_h = "0";
            string sdce_l = "0";
            string sdce_t = "0";
            
            XmlNode xdcedit = xSetupNode.SelectSingleNode("dcedit");
            if (xdcedit != null)
            {
                bHasLayoutData = true;

                sdce_w = xdcedit.Attributes["w"].Value;
                sdce_h = xdcedit.Attributes["h"].Value;
                sdce_l = xdcedit.Attributes["l"].Value;
                sdce_t = xdcedit.Attributes["t"].Value;

                //remove decimal from original value
                if (sdce_w.Contains("."))
                    sdce_w = sdce_w.Substring(0, sdce_w.IndexOf("."));

                if (sdce_h.Contains("."))
                    sdce_h = sdce_h.Substring(0, sdce_h.IndexOf("."));
            }

            string sfram_w = "0";
            string sfram_h = "0";
            string sfram_l = "0";
            string sfram_t = "0";
            
            XmlNode xframe = xSetupNode.SelectSingleNode("frame");
            if (xframe != null)
            {
                bHasLayoutData = true;

                sfram_w = xframe.Attributes["w"].Value;
                sfram_h = xframe.Attributes["h"].Value;
                sfram_l = xframe.Attributes["l"].Value;
                sfram_t = xframe.Attributes["t"].Value;

                //remove decimal from original value
                if (sfram_w.Contains("."))
                    sfram_w = sfram_w.Substring(0, sfram_w.IndexOf("."));

                if (sfram_h.Contains("."))
                    sfram_h = sfram_h.Substring(0, sfram_h.IndexOf("."));

                if (sfram_l.Contains("."))
                    sfram_l = sfram_l.Substring(0, sfram_l.IndexOf("."));

                if (sfram_t.Contains("."))
                    sfram_t = sfram_t.Substring(0, sfram_t.IndexOf("."));
            }

            string scmb_w = "0";
            string scmb_h = "0";
            string scmb_l = "0";
            string scmb_t = "0";
            
            //works where name is list or combo
            XmlNode xcmb = xSetupNode.SelectSingleNode("combobox");
            if (xcmb != null)
            {
                bHasLayoutData = true;

                scmb_w = xcmb.Attributes["w"].Value;
                scmb_h = xcmb.Attributes["h"].Value;
                scmb_l = xcmb.Attributes["l"].Value;
                scmb_t = xcmb.Attributes["t"].Value;

                //remove decimal from original value
                if (scmb_w.Contains("."))
                    scmb_w = scmb_w.Substring(0, scmb_w.IndexOf("."));

                if (scmb_h.Contains("."))
                    scmb_h = scmb_h.Substring(0, scmb_h.IndexOf("."));

                if (scmb_l.Contains("."))
                    scmb_l = scmb_l.Substring(0, scmb_l.IndexOf("."));

                if (scmb_t.Contains("."))
                    scmb_t = scmb_t.Substring(0, scmb_t.IndexOf("."));
            }

            if (bHasLayoutData == true) 
            {  // Exit if the 'control' does not have a matching component in the layout file
               // ie. if the field has no snippet or no label, or if just an image (superfield)
                if (sName.StartsWith("lbl") && xlabel == null)
                    return;

                if (sName.StartsWith("dced") && xdcedit == null)
                    return;

                if (sName.StartsWith("dcim") && xdcimage == null)
                    return;

                if ((sName.StartsWith("cmb") || sName.StartsWith("lst")) && xcmb == null)
                    return;
            }
          
            if (pNode.Name == "decl")
            {
                if (sPanel == "")
                {
                    nY += 30;
                    if (sName.StartsWith("lst"))
                        nY += 30;
                }
                else
                {
                    if (sName.StartsWith("dcim"))
                        nY += 24;
                    else
                    {
                        nX += 100;
                        nY = 0;
                    }
                }
                nTab++;
            }
            string sAppend="";
            XmlNode xNodeOut = xOut.SelectSingleNode(".//" + pNode.Name);
            if (xNodeOut != null)
            {
                int Y = nY;
                                
                if (sName.StartsWith("pan"))
                { 
                    Y += 10;
                    if (xframe != null)
                        sAppend = string.Format(pNode.InnerText, sName, sfram_l, sfram_t, sTag, nTab.ToString(), sPanel, sfram_w, sfram_h, sTag);
                    else
                        sAppend = string.Format(pNode.InnerText, sName, nX.ToString(), Y.ToString(), sTag, nTab.ToString(), sPanel, "500", "400", sTag);
                }
                else if (sName.StartsWith("lbl"))
                {
                    Y += 10;
                    if (xlabel != null)
                         sAppend = string.Format(pNode.InnerText, sName, slbl_l, slbl_t, sTag, nTab.ToString(), sPanel, slbl_w, slbl_h, slbl_c);
                    else
                         sAppend = string.Format(pNode.InnerText, sName, nX.ToString(), Y.ToString(), sTag, nTab.ToString(), sPanel, "100", "15", sTag);
                }                              
                else
                    sAppend = string.Format(pNode.InnerText, sName, nX.ToString(), Y.ToString(), sTag, nTab.ToString(), sPanel, "", "", sTag);

                if (pNode.Name == "controls")
               {
             
                    if (nYOffset == 0)
                    {
                        string[] arLoc = dcedLoc.Split(',');
                        string[] arSize = dcedSize.Split(',');
                        int nDced = (Convert.ToInt32(arLoc[1]) + Convert.ToInt32(arSize[1]));
                        arLoc = dcimLoc.Split(',');
                        arSize = dcimSize.Split(',');
                        int nDcim = (Convert.ToInt32(arLoc[1]) + Convert.ToInt32(arSize[1]));

                        nDcim = (nDced > nDcim ? nDced : nDcim);
                        nDced = (nDcim > nDced ? nDcim : nDced);

                        arLoc = dclbLoc.Split(',');
                        arSize = dclbSize.Split(',');
                        int nDclb = (Convert.ToInt32(arLoc[1]) + Convert.ToInt32(arSize[1]));

                        nDcim = (nDclb > nDcim ? nDclb : nDcim);
                        nDced = (nDclb > nDced ? nDclb : nDced);
                        nDclb = (nDcim > nDclb ? nDcim : nDclb);
                        nYOffset = nDced;

                        nXOffset = Convert.ToInt32(dcedSize.Split(',')[0]);
                        if (Convert.ToInt32(dcimSize.Split(',')[0]) > nXOffset)
                            nXOffset = Convert.ToInt32(dcimSize.Split(',')[0]);
                    }
                                        
                    if (nCurField != nFieldIdx)
                    {
                        if (bHasLayoutData==false)
                            nYMy += nYOffset;
                        nCurField = nFieldIdx;
                        nYMax = (nYMax > nYMy ? nYMax : nYMy); //maximum height for determining panel
                    }

                    //dcedit, listbox and combobox controls
                    if (sName.StartsWith("dced") || sName.StartsWith("lst") || sName.StartsWith("cmb"))
                    {
                        int nTop = nYMy + Convert.ToInt32(dcedLoc.Split(',')[1]);
                        int nLeft = Convert.ToInt32(dcedLoc.Split(',')[0]);
                        if (sPanel != "")
                        {
                            nTop = Convert.ToInt32(dcimSize.Split(',')[1])-1;
                            nLeft = 0;
                        }
                        nLeft += nXOffset * nHorzIdx;

                        if (xdcedit != null && sName.StartsWith("dced"))
                        {   //dcedit 
                            sAppend = string.Format(pNode.InnerText, sName, sdce_l, sdce_t, sTag, nTab.ToString(), sPanel, sdce_w, sdce_h, sTag);
                            sAppend = sAppend.Replace("dcedit.OcxState", "dcedresize.OcxState");
                        }
                        else if (xcmb!=null && (sName.StartsWith("cmb")||sName.StartsWith("lst")))
                        {   //combo or list box
                            sAppend = string.Format(pNode.InnerText, sName, scmb_l, scmb_t, sTag, nTab.ToString(), sPanel, scmb_w, scmb_h, sTag);
                        }
                        else
                            sAppend = string.Format(pNode.InnerText, sName, nLeft.ToString(), nTop.ToString(), sTag, nTab.ToString(), sPanel, "100", "24", sTag);

                        if (sName.StartsWith("lst"))
                            nYMy += (Convert.ToInt32(dclboxSize.Split(',')[1]) - Convert.ToInt32(dcedSize.Split(',')[1]));
                    }
                    else if (sName.StartsWith("dcim") || sName.StartsWith("pan"))
                    {
                        int nTop = nYMy + Convert.ToInt32(dcimLoc.Split(',')[1]);
                        int nLeft = Convert.ToInt32(dcimLoc.Split(',')[0]);
                        if (sPanel != "")
                        {
                            nTop = 0;
                            nLeft = 0;
                        }
                        nLeft += nXOffset * nHorzIdx;
                        if (xdcimage != null && sName.StartsWith("dcim"))
                        {
                            sAppend = string.Format(pNode.InnerText, sName, sdci_l, sdci_t, sTag, nTab.ToString(), sPanel, sdci_w, sdci_h, sTag);
                            sAppend = sAppend.Replace("dcimage.OcxState", "dcimresize.OcxState");
                        }
                        else if (xframe != null && sName.StartsWith("pan"))
                            sAppend = string.Format(pNode.InnerText, sName, sfram_l, sfram_t, sTag, nTab.ToString(), sPanel, sfram_w, sfram_h, sTag);
                        else
                            sAppend = string.Format(pNode.InnerText, sName, nLeft.ToString(), nTop.ToString(), sTag, nTab.ToString(), sPanel, "100", "25", sTag);
                    }
                    else if (sName.StartsWith("lb"))
                    {
                        int nTop = nYMy + Convert.ToInt32(dclbLoc.Split(',')[1]);
                        int nLeft = Convert.ToInt32(dclbLoc.Split(',')[0]);
                        nLeft += nXOffset * nHorzIdx;

                        if (xlabel != null)
                            sAppend = string.Format(pNode.InnerText, sName, slbl_l, slbl_t, sTag, nTab.ToString(), sPanel, slbl_w, slbl_h, slbl_c);
                        else
                            sAppend = string.Format(pNode.InnerText, sName, nLeft.ToString(), nTop.ToString(), sTag, nTab.ToString(), sPanel, "100","15", sTag);
                                  
                    }
                    else if (sName.StartsWith("pb"))
                    {
                        int nTop = nYMy + Convert.ToInt32(dclbLoc.Split(',')[1]);
                        int nLeft = Convert.ToInt32(dclbLoc.Split(',')[0]);
                        nLeft += nXOffset * nHorzIdx;
                        sAppend = string.Format(pNode.InnerText, sName, nLeft.ToString(), nTop.ToString(), sTag, nTab.ToString(), sPanel, "50","50", sTag);
                        int nCom = sAppend.IndexOf("Combine(");
                        while (nCom > -1)
                        {
                            int nCom1 = sAppend.IndexOf(")", nCom);
                            if (nCom > -1)
                            {
                                string []arPlus = sAppend.Substring(nCom + 8, nCom1 - (nCom + 8)).Split('+');
                                string sPlus = (Convert.ToInt32(arPlus[0]) + Convert.ToInt32(arPlus[1])).ToString();
                                string sNew=sAppend.Substring(0, nCom) + sPlus + sAppend.Substring(nCom1+1);
                                sAppend = sNew;
                            }
                            nCom = sAppend.IndexOf("Combine(");
                        }
                    }
                }
                xNodeOut.InnerText += sAppend;
            }
        }

        int nFieldIdx = 0;
        int nSubFieldIdx = 0;

        public void GenerateSubLevel(XmlDocument xSetup, XmlDocument xOut, XmlNodeList xNodes, string sPanel)
        {
            int nY1 = nY;
            int nX1 = nX;
            int nTab1 = nTab;

            nSubFieldIdx = 0;
            foreach (XmlNode xNode in xNodes)
            {
                string sName=xNode.Attributes["type"].Value;
                string sSafe = sName.Replace(" ", "_");
                XmlNode pNode = xSetup.SelectSingleNode("/S/F[@type='" + sName + "']");
                if (pNode != null)
                {
                    XmlNode pOutStart = null;
                    string sType = "DcEdit";
                    string sSafe1 = "dced" + sSafe;
                    if (pNode.SelectNodes("F").Count > 0)
                    {
                        sSafe1 = "";
                        if (pNode.SelectNodes("F").Count > 1)
                        {
                            int nXS = nX;
                            nY += 30;
                            nSubFieldIdx=0;
                            nFieldIdx++;
                            foreach (XmlNode pSub in pNode.SelectNodes("F"))
                            {
                                sName = pSub.Attributes["type"].Value;
                                sSafe = sName.Replace(" ", "_");
                                pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Label");
                                if (pOutStart == null)
                                    continue;
                                foreach (XmlNode pChild in pOutStart.ChildNodes)
                                {
                                    if (pChild.SelectNodes("*").Count > 0)
                                    {
                                        foreach (XmlNode xChild in pChild.ChildNodes)
                                        {
                                            AppendResult("lb" + sSafe, sName, xChild, xOut, "", nSubFieldIdx, pSub);
                                        }
                                    }
                                    else
                                    {
                                        AppendResult("lb" + sSafe, sName, pChild, xOut, "", nSubFieldIdx, pSub);
                                    }
                                }
                                nSubFieldIdx++;
                                nY -= 30;
                                nX += 100;
                            }
                            nSubFieldIdx = 0;
                            nX = nXS;
                            nY += 10;
                            
                            sType = "Panel";
                            sName = pNode.Attributes["type"].Value;
                            sSafe = sName.Replace(" ", "_");
                            sSafe1 = "pan" + sSafe;
                            pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Panel");
                            XmlNode pCont = pOutStart.SelectSingleNode("content/controls");
                            int nSizeY = 0;
                            int nSizeX = 0;
                            if (pCont != null)
                            {
                                nSizeY = (Convert.ToInt32(dcimSize.Split(',')[1]) + Convert.ToInt32(dcedSize.Split(',')[1])) * 4;
                                nSizeX = pNode.SelectNodes("F").Count * Convert.ToInt32(dcedSize.Split(',')[0]) + 20;
                                string sCont = SetFactValue(pCont.InnerText, "{0}.Size", ".Size(", nSizeX.ToString() + "," + nSizeY.ToString());
                                XmlNode xframe = pNode.SelectSingleNode("frame"); //check if layout was loaded and field has a location - skip autosize if found
                                if (xframe == null)
                                    pCont.InnerText = sCont;
                            }
                            foreach (XmlNode pChild in pOutStart.ChildNodes)
                            {
                                if (pChild.SelectNodes("*").Count > 0)
                                {
                                    foreach (XmlNode xChild in pChild.ChildNodes)
                                    {
                                        AppendResult(sSafe1, sName, xChild, xOut, "", 0, pNode);
                                    }
                                }
                                else
                                {
                                    AppendResult(sSafe1, sName, pChild, xOut, "", 0, pNode);
                                }
                            }
                            sSafe1 += ".";
                            nYMy += nSizeY;
                            formSize = (nSizeX + nYOffset).ToString() + "," + formSize.Split(',')[1];

                            pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/PanelButtons");
                            foreach (XmlNode pChild in pOutStart.ChildNodes)
                            {
                                if (pChild.SelectNodes("*").Count > 0)
                                {
                                    foreach (XmlNode xChild in pChild.ChildNodes)
                                    {
                                        AppendResult("pb" + sSafe, sName, xChild, xOut, "", nSubFieldIdx, pNode);
                                    }
                                }
                                else
                                {
                                    AppendResult("pb" + sSafe, sName, pChild, xOut, "", nSubFieldIdx, pNode);
                                }
                            }
                            nTab1 += 2;
                        }
                        nY = 0;
                        nX = 0;
                        nTab = 0;

                        GenerateSubLevel(xSetup, xOut, pNode.SelectNodes("F"), sSafe1);
                        if (pNode.SelectNodes("F").Count > 1)
                        {
                            nY1 += 500;
                            nXPlus += 400;
                        }
                        continue;
                    }

                    Boolean bLayout = false;
                    XmlNode xLayoutNode = null;

                    //check for layout tags
                    xLayoutNode = pNode.SelectSingleNode("combobox");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("dcimage");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("dcedit");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("label");
                    if (xLayoutNode != null)
                        bLayout = true;

                    //Check SETUP dco status. If status is '-1' and no Layout xml tags exist then ignore this field.
                    if (pNode.SelectSingleNode("V[@n='STATUS']") != null && pNode.SelectSingleNode("V[@n='STATUS']").InnerText == "-1" && bLayout == false)
                        continue;

                    XmlNode pType = pNode.SelectSingleNode("V[@n='RecogType']");
                    if (pType != null)
                    {
                        if (pType.InnerText == "4" || pType.InnerText == "18" || pNode.SelectSingleNode("V[@n='DICT']") != null || pNode.SelectSingleNode("V[@n='SELECT']")!=null )
                        {
                            if (pNode.SelectSingleNode("V[@n='MultiPunch']") != null)
                            {
                                sType = "ListBox";
                                sSafe1 = "lst" + sSafe;
                            }
                            else
                            {
                                sType = "ComboBox";
                                sSafe1 = "cmb" + sSafe;
                            }
                        }
                    }

                    // Image
                    pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Image");
                    if (pOutStart == null)
                        continue;
                    foreach (XmlNode pChild in pOutStart.ChildNodes)
                    {
                        if (pChild.SelectNodes("*").Count > 0)
                        {
                            foreach (XmlNode xChild in pChild.ChildNodes)
                            {
                                AppendResult("dcim" + sSafe, sName, xChild, xOut, sPanel, nSubFieldIdx, pNode);
                            }
                        }
                        else
                        {
                            AppendResult("dcim" + sSafe, sName, pChild, xOut, sPanel, nSubFieldIdx, pNode);
                        }
                    }

                    // Data
                    pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/" + sType);
                    if (pOutStart == null)
                        continue;
                    foreach (XmlNode pChild in pOutStart.ChildNodes)
                    {
                        if (pChild.SelectNodes("*").Count > 0)
                        {
                            foreach (XmlNode xChild in pChild.ChildNodes)
                            {
                                AppendResult(sSafe1, sName, xChild, xOut, sPanel, nSubFieldIdx, pNode);
                            }
                        }
                        else
                        {
                            AppendResult(sSafe1, sName, pChild, xOut, sPanel, nSubFieldIdx, pNode);
                        }
                    }
                    nSubFieldIdx++;
                }
            }
            nY = nY1;
            nX = nX1;
            nTab = nTab1;
        }

        public void Mergelayout(XmlDocument xSetup, XmlDocument xLayout)
        {
            XmlNodeList xFieldNodes = xSetup.SelectNodes("//F");
            
            //loop through each field in the setup xml and find a matching entry in the layout xml
            foreach (XmlNode xField in xFieldNodes)
            {
                string sName = xField.Attributes["type"].Value;
                string sSafeNm = sName.Replace(" ", "_");
                               
                //Get dcimage node 
                XmlNode dciNode = xLayout.SelectSingleNode("//dcimage[@name='Dcim" + sSafeNm + "']");
                if (dciNode != null)
                {   //add dcimage node to setup node as child
                    XmlNode newdciNode = xSetup.ImportNode(dciNode, true);
                    xField.AppendChild(newdciNode);
                }

                //Get dcedit node 
                XmlNode dcedNode = xLayout.SelectSingleNode("//dcedit[@name='Dced" + sSafeNm + "']");
                if (dcedNode != null)
                {   //add dcedit node to setup node as child
                    XmlNode newdcedNode = xSetup.ImportNode(dcedNode, true);
                    xField.AppendChild(newdcedNode);
                }

                //Get combobox node 
                XmlNode cmbNode = xLayout.SelectSingleNode("//combobox[@name='Combo" + sSafeNm + "']");
                if (cmbNode != null)
                {   //add cmb node to setup node as child
                    XmlNode newcmbNode = xSetup.ImportNode(cmbNode, true);
                    xField.AppendChild(newcmbNode);
                }

                //Get frame node (superfram node for hierarchical fields)
                XmlNode frameNode = xLayout.SelectSingleNode("//frame[@name='SuperFram" + sSafeNm + "']");
                if (frameNode != null)
                {  //add dcedit node to setup node as child
                    XmlNode newframeNode = xSetup.ImportNode(frameNode, true);
                    xField.AppendChild(newframeNode);
                }

                //Get Label node 
                XmlNode lblNode = xLayout.SelectSingleNode("//label[@name='Label" + sSafeNm + "']");
                if (lblNode != null)
                {   //add label node to setup node as child
                    XmlNode newlblNode = xSetup.ImportNode(lblNode, true);
                    xField.AppendChild(newlblNode);
                }
                else
                {
                    XmlNode ParentNode=null;
                    if (dcedNode != null)
                        ParentNode = dcedNode.ParentNode;

                    if (dciNode != null && ParentNode==null)
                        ParentNode = dciNode.ParentNode;

                    if (cmbNode != null && ParentNode == null)
                        ParentNode = cmbNode.ParentNode;

                    if (ParentNode != null)
                    {
                        if (ParentNode.Name == "frame")
                        {//change tag name to "label", change attribute name to "Label" + sSafeNm, add as new label node
                         //this adds a 'label' node to fields where the frame caption was used as a label.
                            XmlElement newFrmLblNode = xSetup.CreateElement("label");
    
                            newFrmLblNode.SetAttribute("name", "Label" + sSafeNm);

                            string newWidth = ParentNode.Attributes["w"].Value;
                            if (newWidth.Contains("."))  //remove decimals
                                newWidth = newWidth.Substring(0, newWidth.IndexOf("."));

                            string newHeight = ParentNode.Attributes["h"].Value;
                            if (newHeight.Contains("."))  //remove decimals
                                newHeight = newHeight.Substring(0, newHeight.IndexOf("."));

                            string newLength = ParentNode.Attributes["l"].Value;
                            if (newLength.Contains("."))  //remove decimals
                                newLength = newLength.Substring(0, newLength.IndexOf("."));
                                                 
                            string newTop = ParentNode.Attributes["t"].Value;
                            if (newTop.Contains("."))  //remove decimals
                                newTop = newTop.Substring(0, newTop.IndexOf(".")); 

                            int nTop = Convert.ToInt16(newTop); //adjust upwards to clear new control structure
                            nTop = nTop - 10;
                            if (nTop < 0)
                                nTop = 0;
                            
                            newFrmLblNode.SetAttribute("t", nTop.ToString());
                            newFrmLblNode.SetAttribute("w", newWidth);
                            newFrmLblNode.SetAttribute("h", newHeight);
                            newFrmLblNode.SetAttribute("l", newLength);
                            newFrmLblNode.SetAttribute("caption", ParentNode.Attributes["caption"].Value);

                            xField.AppendChild(newFrmLblNode);
                        }
                    }
              
                }
                
            }
            
        }


        public void GenerateLevel(XmlDocument xSetup, XmlDocument xOut, XmlNodeList xNodes)
        {
            nFieldIdx = 0;

            foreach (XmlNode xNode in xNodes)
            {
                string sName=xNode.Attributes["type"].Value;
                string sSafe = sName.Replace(" ", "_");
                XmlNode pNode = xSetup.SelectSingleNode("/S/F[@type='" + sName + "']");
                if (pNode != null)
                {
                    XmlNode pOutStart = null;
                    string sType = "DcEdit";
                    string sSafe1 = "dced" + sSafe;
                    XmlNode pType = pNode.SelectSingleNode("V[@n='RecogType']");
                    if (pNode.SelectNodes("F").Count > 0 && pType==null)
                    {
                        sSafe1 = "";
                        if (pNode.SelectNodes("F").Count > 1)
                        {
                            int nXS = nX;
                            nY += 30;
                            nFieldIdx++;
                            foreach (XmlNode pSub in pNode.SelectNodes("F"))
                            {
                                sName = pSub.Attributes["type"].Value;
                                sSafe = sName.Replace(" ", "_");
                                pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Label");
                                if (pOutStart == null)
                                    continue;
                                foreach (XmlNode pChild in pOutStart.ChildNodes)
                                {
                                    if (pChild.SelectNodes("*").Count > 0)
                                    {
                                        foreach (XmlNode xChild in pChild.ChildNodes)
                                        {
                                            AppendResult("lb" + sSafe, sName, xChild, xOut, "", 0, pSub);
                                        }
                                    }
                                    else
                                    {
                                        AppendResult("lb" + sSafe, sName, pChild, xOut, "", 0, pSub);
                                    }
                                }
                                nY -= 30;
                                nX += 100;
                            }
                            nX = nXS;
                            nY += 30;

                            sType = "Panel";
                            sSafe1 = "pan" + sSafe;
                            pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Panel");
                            foreach (XmlNode pChild in pOutStart.ChildNodes)
                            {
                                if (pChild.SelectNodes("*").Count > 0)
                                {
                                    foreach (XmlNode xChild in pChild.ChildNodes)
                                    {
                                        AppendResult(sSafe1, sName, xChild, xOut, "", 0, pNode);
                                    }
                                }
                                else
                                {
                                    AppendResult(sSafe1, sName, pChild, xOut, "", 0, pNode);
                                }
                            }
                            sSafe1 += ".";
                        }
                        GenerateSubLevel(xSetup, xOut, pNode.SelectNodes("F"), sSafe1);
                        continue;
                    }

                    Boolean bLayout = false;
                    XmlNode xLayoutNode = null;

                    //check for layout tags
                     xLayoutNode = pNode.SelectSingleNode("combobox");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("dcimage");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("dcedit");
                    if (xLayoutNode != null)
                        bLayout = true;

                    xLayoutNode = pNode.SelectSingleNode("label");
                    if (xLayoutNode != null)
                        bLayout = true;
                    
                    //Check SETUP dco status. If status is '-1' and no Layout xml tags exist then ignore this field.
                    if (pNode.SelectSingleNode("V[@n='STATUS']") != null && pNode.SelectSingleNode("V[@n='STATUS']").InnerText == "-1" && bLayout==false)
                        continue;
                    nFieldIdx++;
                    if (pType!=null)
                    {
                        //Check if OMR field. pType is RecogType Variable node
                        if (pType.InnerText=="4" || pType.InnerText=="18" || pNode.SelectSingleNode("V[@n='DICT']")!=null)
                        {
                            if (pNode.SelectSingleNode("V[@n='MultiPunch']") != null)
                            {
                                sType = "ListBox";
                                sSafe1 = "lst" + sSafe;
                            }
                            else
                            {
                                sType = "ComboBox";
                                sSafe1 = "cmb" + sSafe;
                            }
                        }
                    }

                    // Label
                    pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Label");
                    if (pOutStart == null)
                        continue;
                    foreach (XmlNode pChild in pOutStart.ChildNodes)
                    {
                        if (pChild.SelectNodes("*").Count > 0)
                        {
                            foreach (XmlNode xChild in pChild.ChildNodes)
                            {
                                AppendResult("lbl" + sSafe, sName, xChild, xOut, "", 0, pNode);
                            }
                        }
                        else
                        {
                            AppendResult("lbl" + sSafe, sName, pChild, xOut, "", 0, pNode);
                        }
                    }
                    // Image
                    pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/Image");
                    if (pOutStart == null)
                        continue;
                    foreach (XmlNode pChild in pOutStart.ChildNodes)
                    {
                        if (pChild.SelectNodes("*").Count > 0)
                        {
                            foreach (XmlNode xChild in pChild.ChildNodes)
                            {
                                AppendResult("dcim" + sSafe, sName, xChild, xOut, "", 0, pNode);
                            }
                        }
                        else
                        {
                            AppendResult("dcim" + sSafe, sName, pChild, xOut, "", 0, pNode);
                        }
                    }

                    // Data
                    pOutStart = xOut.SelectSingleNode("/xml/controlTemplates/" + sType);
                    if (pOutStart == null)
                        continue;
                    foreach (XmlNode pChild in pOutStart.ChildNodes)
                    {
                        if (pChild.SelectNodes("*").Count > 0)
                        {
                            foreach (XmlNode xChild in pChild.ChildNodes)
                            {
                                AppendResult(sSafe1, sName, xChild, xOut, "", 0, pNode);
                            }
                        }
                        else
                        { 
                            AppendResult(sSafe1, sName, pChild, xOut, "", 0, pNode);
                        }
                    }

                }
            }

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (dlgFO.ShowDialog() == DialogResult.OK)
            {
                cmbTypes.Items.Clear();
                txtSetup.Text = dlgFO.FileName;
                xSetup.Load(txtSetup.Text);
                XmlNodeList pList = xSetup.SelectNodes("/S/P[F]");
                foreach (XmlNode pNode in pList)
                {
                    cmbTypes.Items.Add(pNode.Attributes["type"].Value);
                }
                if (cmbTypes.Items.Count > 0)
                    cmbTypes.SelectedIndex = 0;
            }
        }

        string dcedLoc = "";
        string dcedSize = "";
        string dcimLoc = "";
        string dcimSize = "";
        string dclbLoc = "";
        string dclbSize = "";
        string dclboxLoc = "";
        string dclboxSize = "";
        string dccboxLoc = "";
        string dccboxSize = "";

        string formSize = "";



        private string GetFactValue(string sText, string sOne, string sTwo)
        {
            int nPos = sText.IndexOf(sOne);
            if (nPos > -1)
            {
                int nPos1 = sText.IndexOf(sTwo, nPos);
                if (nPos1 > -1)
                {
                    nPos1 += sTwo.Length;
                    int nPos2 = sText.IndexOf(")", nPos1);
                    string sLoc = sText.Substring(nPos1, (nPos2 - nPos1));
                    return sLoc;
                }
            }
            return "";
        }

        private string SetFactValue(string sText, string sOne, string sTwo, string sVal)
        { 
            int nPos = sText.IndexOf(sOne);
            if (nPos>-1)
            {
                int nPos1=sText.IndexOf(sTwo, nPos);
                if (nPos1>-1)
                {
                    nPos1 += sTwo.Length;
                    int nPos2 = sText.IndexOf(")", nPos1);
                    string sLoc = sText.Substring(0, nPos1) + sVal + sText.Substring(nPos2);
                    return sLoc;
                }
            }
            return sText;
        }


        private string AppendProps(string sText, string sIn, string sCtrl)
        { 
            int nPos=sText.IndexOf("// " + sCtrl);
            string sRes=sIn;
            if (nPos > 0)
            {
                int nPos1 = sText.IndexOf("//", sText.IndexOf(" = ", nPos));
                if (nPos1 > 0)
                {
                    string sOut = sText.Substring(nPos, (nPos1-nPos));
                    string[] arProps = sOut.Split('\n');
                    foreach (string s in arProps)
                    {
                        string []arLine=s.Split('=');
                        if (arLine.Length>1)
                        {
                            string []arProp=arLine[0].Split('.');
                            if (arProp.Length>1)
                            {
                                string sProp = "." + arProp[arProp.Length-1].Trim() + " =";
                                int nExists=sIn.IndexOf(sProp);
                                if (nExists<0)
                                {
                                    string sNew=s.Replace(sCtrl, "{0}")+'\n';
                                    sRes+=sNew;
                                }
                            }
                        }
                    }
                }
            }
            return sRes;
        }

        private void AdjustDifferences()
        {
            StreamReader pIn = File.OpenText(sProjectRoot + "\\dotLayout.Designer.cs");
            string sText = pIn.ReadToEnd();
            pIn.Close();

            dcedLoc = GetFactValue(sText, "dcedit.Location", ".Point(");
            dcedSize = GetFactValue(sText, "dcedit.Size", ".Size(");

            dcimLoc = GetFactValue(sText, "dcimage.Location", ".Point(");
            dcimSize = GetFactValue(sText, "dcimage.Size", ".Size(");

            dclbLoc = GetFactValue(sText, "dclabel.Location", ".Point(");
            dclbSize = GetFactValue(sText, "dclabel.Size", ".Size(");

            dclboxLoc = GetFactValue(sText, "dclistbox.Location", ".Point(");
            dclboxSize = GetFactValue(sText, "dclistbox.Size", ".Size(");

            dccboxLoc = GetFactValue(sText, "dccombobox.Location", ".Point(");
            dccboxSize = GetFactValue(sText, "dccombobox.Size", ".Size(");

            formSize = GetFactValue(sText, "this.Size", ".Size(");
                        
            if (txtLayout.TextLength > 0)  //bypass resizing if layout file was selected
                return;

            // Set new control sizes to dotlayout size - prevents dynamic sizing!
            XmlNode pCont = xOut.SelectSingleNode("/xml/controlTemplates/Image/content/controls");
            if (pCont != null)
            {
                string sCont = SetFactValue(pCont.InnerText, "{0}.Size", ".Size(", dcimSize);
                pCont.InnerText = sCont;
            }

            pCont = xOut.SelectSingleNode("/xml/controlTemplates/DcEdit/content/controls");
            if (pCont != null)
            {
                string sCont = SetFactValue(pCont.InnerText, "{0}.Size", ".Size(", dcedSize);
                pCont.InnerText = sCont;
            }

            pCont = xOut.SelectSingleNode("/xml/controlTemplates/ComboBox/content/controls");
            if (pCont != null)
            {
                string sCont = SetFactValue(pCont.InnerText, "{0}.Size", ".Size(", dccboxSize);
                pCont.InnerText = sCont;
                pCont.InnerText = AppendProps(sText, pCont.InnerText, "dccombobox");
            }

            pCont = xOut.SelectSingleNode("/xml/controlTemplates/ListBox/content/controls");
            if (pCont != null)
            {
                string sCont = SetFactValue(pCont.InnerText, "{0}.Size", ".Size(", dclboxSize);
                pCont.InnerText = sCont;
                pCont.InnerText = AppendProps(sText, pCont.InnerText, "dclistbox");
            }

            pCont = xOut.SelectSingleNode("/xml/controlTemplates/Label/content/controls");
            if (pCont != null)
            {
                pCont.InnerText = AppendProps(sText, pCont.InnerText, "dclabel");
            }
             
        }

        //string sProjectRoot = @"E:\Naveen_Datacap_E\Tools&Dlls\DCDesktop Panels with Universal\DotEditPanels";
        string sProjectRoot = @"C:\Datacap\Desktop_Panel\DCDesktop Panels with Universal\DotEditPanels";
        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (txtNewName.Text == "")
                MessageBox.Show("Choose new name", "DotEditPanels");
            else
            {
                //Steps to create new control:
                //1. rewrite dummy files with the new name;
                //2. replace all references to dummy in those with new name;
                string[] aFiles ={ "dotLayout.cs", "dotLayout.resx" };
                foreach (string f in aFiles)
                {
                    StreamReader pIn = File.OpenText(sProjectRoot + "\\" +f);
                    string sText = pIn.ReadToEnd();
                    pIn.Close();
                    StreamWriter pOut = File.CreateText(sProjectRoot + "\\" + f.Replace("dotLayout", txtNewName.Text));
                    pOut.Write(sText.Replace("dotLayout", txtNewName.Text));
                    pOut.Close();
                }

                //3. generate new layout in designer.cs file; 
                StreamWriter pD = File.CreateText(sProjectRoot + "\\" + txtNewName.Text + ".designer.cs");
                pD.Write(CreateNewLayout(cmbTypes.SelectedItem.ToString(), txtNewName.Text));
                pD.Close();

                //4. append ocxstate into resx file;

                //5. modify project xml to include new control.
                XmlDocument xProj=new XmlDocument();
                XmlNamespaceManager ns = new XmlNamespaceManager(xProj.NameTable);
                ns.AddNamespace("s", "http://schemas.microsoft.com/developer/msbuild/2003");
                xProj.Load(sProjectRoot + "\\DotEditPanels.csproj");
                XmlDocument xAppend=new XmlDocument();
                xAppend.LoadXml(string.Format(sCSProj, txtNewName.Text));
                foreach (XmlNode pNode in xAppend.DocumentElement.ChildNodes)
                {
                    XmlNode pNew = xProj.ImportNode(pNode, true);
                    XmlNodeList pList = xProj.SelectNodes(".//s:" + pNew.Name, ns);
                    pList[0].ParentNode.InsertBefore(pNew, pList[0]);
                }

/*              if (MessageBox.Show("Embed new panel into main program?", "Add more code", MessageBoxButtons.OKCancel)==DialogResult.OK)
                {
                    string sMainRoot = sProjectRoot.Replace("DotEditPanels", "DotEdit");
                    StreamReader pIn = File.OpenText(sMainRoot + "\\MainForm.cs");
                    string sText = pIn.ReadToEnd();
                    pIn.Close();
                    string sSearch = "{   //USED IN AUTOFORM /*********\r\n";
                    int nPos = sText.IndexOf(sSearch);
                    if (nPos > -1)
                    {
                        string sInsert = string.Format(sMainFormCase, cmbTypes.Text, txtNewName.Text, "{", "}");
                        sText = sText.Substring(0, nPos + sSearch.Length) + sInsert + sText.Substring(nPos + sSearch.Length);
                        StreamWriter pOut = File.CreateText(sMainRoot + "\\MainForm.cs");
                        if (pOut != null)
                        {
                            pOut.Write(sText);
                            pOut.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Couldn't find entry point!", "DotEditPanels");
                    }
                }  */
                xProj.Save(sProjectRoot + "\\DotEditPanels.csproj");
             
                MessageBox.Show("Done! Please Reload Files and Rebuild DotEdit Projects!", "DotEditPanels");
            }
        }

        private void cmbTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
//          string sSet = xSetup.SelectSingleNode("/S/B").Attributes["type"].Value;
            string sSet = cmbTypes.Text;
            if (sSet[0]>='0' && sSet[0]<='9')
                sSet="N" + sSet;
            txtNewName.Text=sSet;
        }

        private void btnBrwsLayout_Click(object sender, EventArgs e)
        {
            if (dlgFO.ShowDialog() == DialogResult.OK)
            {   //read the layout xml generated by a scriptlib panel

                txtLayout.Text = dlgFO.FileName;
                xLayout.Load(txtLayout.Text);

                //adjust positions for parent containers (frames)
                NormalizeLayout(xLayout);
    
            }
        }

        private void NormalizeLayout(XmlDocument xLayout)
        {
            //remove non superfram container tags
            XmlNode xRoot = xLayout.SelectSingleNode("layout");

            if (xRoot != null)
            {
                XmlNodeList xNodelist = xRoot.ChildNodes;
                NormalizeFrame(xNodelist, "0", "0");
            }
            
        }

        private void NormalizeFrame(XmlNodeList xNodelist, string nParentL, string nParentT)
        {
            string nL="0";
            string nT="0";
                       
            foreach (XmlNode xNode in xNodelist)
            {
                XmlNodeList xChildNodelist = xNode.ChildNodes;
                if (xNode.Attributes["l"] != null)
                    nL = xNode.Attributes["l"].Value;
                if (xNode.Attributes["t"] != null)
                    nT = xNode.Attributes["t"].Value;
                
                if (nL.Contains("."))
                    nL = nL.Substring(0, nL.IndexOf("."));
                if (nT.Contains("."))
                    nT = nT.Substring(0, nT.IndexOf("."));
                             
                string cL = (Convert.ToInt32(nL) + Convert.ToInt32(nParentL)).ToString();
                string cT = (Convert.ToInt32(nT) + Convert.ToInt32(nParentT)).ToString();

                if (Convert.ToInt32(cT) > nYMy)
                    nYMy = Convert.ToInt32(cT); 

               // if (xNode.Name == "frame" && xNode.Attributes["name"].Value.StartsWith("Frame")) //ignore superframe types
                if (xNode.Name == "frame") 
                {
                    if (xNode.Attributes["l"] != null)
                        xNode.Attributes["l"].Value = cL;
                    if (xNode.Attributes["t"] != null)
                        xNode.Attributes["t"].Value = cT;

                    if (xChildNodelist != null)
                        NormalizeFrame(xChildNodelist, cL, cT);
                }
                else
                {
                    if (xNode.Attributes["l"] != null)
                        xNode.Attributes["l"].Value = cL;
                    if (xNode.Attributes["t"] != null)
                        xNode.Attributes["t"].Value = cT;
                }
            }
        }

 


    }
}