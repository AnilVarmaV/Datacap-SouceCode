//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;
using System.Data.OleDb;
using System.Configuration;


namespace DotEditPanels
{
    public partial class N_MainPage : dotPanelBase
    {
        XmlDocument Edelweiss = new XmlDocument();
        OleDbConnection con;

        public N_MainPage()
        {
            InitializeComponent();
        }

        private void N_MainPage_Load(object sender, EventArgs e)
        {

        }
        public override bool SaveData(XmlDocument xPage)
        {
            bool Result = base.StartBatch();
            var dcapp = new DCAppleLib.DirectAppList();
            try
            {
                this.dcedIssueDate.Focus();
                this.dcedEntity.Focus();
                this.dcedIssueDate.Visible = true;
                this.dcedIssueDate.Focus();
                hidefields(dcedDocumentType.CtlText); 
                vendorshowhide(dcedDocumentType.CtlText);
                SetStyle(ControlStyles.Selectable, false);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog("Error in SaveData:" + ex);
            }
            return base.SaveData(xPage);
        }
        public override bool StartBatch()
        {

            bool bRes = base.StartBatch();
            var dcapp = new DCAppleLib.DirectAppList();

            dcTask.WriteLog("Entering into StartBatch");
            dcedDocumentType.Visible = false;
            cmb_Function.Visible = true;
            dcedFunction.Visible = false;
            dcedVendorName.Visible = false;
            LstUniqueCode.Visible = false;
            LstDocumentType.Visible = false;
            dcTask.WriteLog("Entering into Hidefields");
            hidefields(dcedDocumentType.CtlText);
            dcTask.WriteLog(5, "Fields Hiding Succesfull");
            getxmlpath();

            dcTask.WriteLog(5, "Getting Values from XML");

            try
            {
                dcTask.WriteLog(5, "Clear the combox Items");
                this.cmb_UniqueCode.Items.Clear();
                this.cmb_Function.Items.Clear();
                this.cmb_DocumentType.Items.Clear();
                this.cmb_VendorName.Items.Clear();
               dcTask.WriteLog(5, "Binding UNIQUE_CODE");
                DataTable dtuniquecode = binddata("UNIQUE_CODE");
                dcTask.WriteLog(5, "Binding N_FUNCTION");
                DataTable dtfunction = binddata("N_FUNCTION");
                dcTask.WriteLog(5, "Binding N_DOCTYPE");
                DataTable dtdoctype = binddata("N_DOCTYPE");
                dcTask.WriteLog(5, "all combo boxes bind successfully");
                dcTask.WriteLog(5, "Filling to UniqueCode");
                fill_UniqueCode(dtuniquecode);
                dcTask.WriteLog(5, "Filling to Function");
                fill_Function(dtfunction);
                dcTask.WriteLog(5, "Filling to DocType");
                fill_DocType(dtdoctype);
                dcTask.WriteLog(5, "Filling Successful");
                cmb_DocumentType.SelectedIndex = -1;
                cmb_Function.SelectedIndex = -1;
                cmb_UniqueCode.SelectedIndex = -1;
                cmb_VendorName.SelectedIndex = -1;

                cmb_DocumentType.SelectedText = "";
                cmb_Function.SelectedText = "";

                cmb_UniqueCode.SelectedText = "";
                cmb_VendorName.SelectedText = "";

                cmb_DocumentType.Text = "";
                cmb_Function.Text = "";

                cmb_UniqueCode.Text = "";
                cmb_VendorName.Text = "";
                //Vendor

                if (!string.IsNullOrEmpty(dcedDocumentType.CtlText))
                {
                    dcTask.WriteLog(5, "Entering to Check the Vendor is Require or not");
                    vendorshowhide(dcedDocumentType.CtlText);
                    this.cmb_DocumentType.SelectedIndexChanged -= new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                    cmb_DocumentType.SelectedItem = dcedDocumentType.CtlText;
                    this.cmb_DocumentType.SelectedIndexChanged += new EventHandler(cmb_DocumentType_SelectedIndexChanged);
                }
                else
                {
                    cmb_DocumentType.SelectedIndex = -1;
                }

                if (!string.IsNullOrEmpty(dcedUniqueCode.CtlText))
                {
                    dcTask.WriteLog(5, "Passing Datacap Uniquecode value to Combobox");
                    this.cmb_UniqueCode.SelectedIndexChanged -= new EventHandler(cmb_UniqueCode_SelectedIndexChanged);
                    cmb_UniqueCode.SelectedItem = dcedUniqueCode.CtlText;
                    this.cmb_UniqueCode.SelectedIndexChanged += new EventHandler(cmb_UniqueCode_SelectedIndexChanged);
                }
                else
                {
                    cmb_UniqueCode.SelectedIndex = -1;
                }

                LstDocumentType.Visible = false;
                LstUniqueCode.Visible = false;
                dcTask.WriteLog(5, "startBatch is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in StartBatch: " + ex.Message + "  Details: " + ex.ToString());
            }

            return bRes;


        }

        void hidefields(string strDocumentTypeValue)
        {
            dcTask.WriteLog(5, "Entering to Hide Fields");
            dcTask.WriteLog(5, "Document Type is:"+strDocumentTypeValue);
            if (strDocumentTypeValue.Contains("Registered Agreement"))
            {
                dcedIssueDate.Visible = true;
                dcedLicensors.Visible = true;
                dcedPropertyAddress.Visible = true;
                dcedTenure.Visible = true;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = true;
                lblLicensors.Visible = true;
                lblPropertyAddress.Visible = true;
                lblTenure.Visible = true;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = true;
            }
            else if (strDocumentTypeValue.Contains("Letter of Intent"))
            {
                dcedIssueDate.Visible = true;
                dcedLicensors.Visible = true;
                dcedPropertyAddress.Visible = true;
                dcedTenure.Visible = false;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = true;
                lblLicensors.Visible = true;
                lblPropertyAddress.Visible = true;
                lblTenure.Visible = false;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = true;
            }
            else
            {
                dcedIssueDate.Visible = false;
                dcedLicensors.Visible = false;
                dcedPropertyAddress.Visible = false;
                dcedTenure.Visible = false;
                dcedVendorName.Visible = false;
                cmb_VendorName.Visible = false;
                lblIssueDate.Visible = false;
                lblLicensors.Visible = false;
                lblPropertyAddress.Visible = false;
                lblTenure.Visible = false;
                lblVendorName.Visible = false;
                dtp_IssueDate.Visible = false;

            }
            dcTask.WriteLog(5,"HideFields Successful");
        }

        public string getXMLvalues(string strXMLvalues)
        {
            string cs = string.Empty;
            try
            {
                XmlNode Cs_list = Edelweiss.SelectSingleNode("/configuration/DB/setting[@name = '" + strXMLvalues + "']");
                 cs = Cs_list.InnerText.ToString();
                 dcTask.WriteLog(5, "Connection String CS is:" + cs);
            }
            catch(Exception ex)
            {

                dcTask.WriteLog(5, "Error in getXMLvalues: " + ex.Message + "  Details: " + ex.ToString());
               
            }
            return cs;
        }

        public void getxmlpath()
        {
            try
            {
                dcTask.WriteLog(5, "Entering into getxml:");
                // string configurationFilePaths=  ConfigurationSettings.AppSettings["configurationFilePath"].ToString();
                string configurationFilePath = "C:\\edel_config.xml";//.AppSettings["configurationFile"]);
                Edelweiss.Load(configurationFilePath);
                dcTask.WriteLog(5, "getxml path is" + configurationFilePath);
                con = new OleDbConnection(getXMLvalues("CONNECTION_STRING"));
                dcTask.WriteLog(5, "getXml con is:" + con);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in getxmlpath: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        public DataTable binddata(string strxmlvalue)
        {
            DataTable dt = new DataTable();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                dcTask.WriteLog(5, "Error in connection open");
            }
            try
            {
                
                string command = getXMLvalues(strxmlvalue);
                OleDbCommand cmd = new OleDbCommand(command, con);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                dcTask.WriteLog(5, "Binding the " + strxmlvalue + "is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in binddata: " + ex.Message + "  Details: " + ex.ToString());
            }
            return dt;

        }
        public DataTable binddata(string strxmlvalue, string strinputvalue)
        {
            DataTable dt = new DataTable();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            try
            {
                string command = getXMLvalues(strxmlvalue);
                command = command.Replace(":Uniquecode", strinputvalue);
                OleDbCommand cmd = new OleDbCommand(command, con);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                dcTask.WriteLog(5, "Binding the " + strxmlvalue + "is Successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in binddata OverLoad: " + ex.Message + "  Details: " + ex.ToString());
            }
            return dt;
        }

        private void cmb_UniqueCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            LstUniqueCode.Visible = false;
            try
            {
                if (cmb_UniqueCode.Text != "SELECT")
                {
                    this.dcedUniqueCode.Visible = true;
                    this.dcedUniqueCode.CtlText = this.cmb_UniqueCode.Text;
                    dcedUniqueCode.Focus();
                    dcedUniqueCode.Visible = false;
                    dcTask.WriteLog(5, "Binding the Selected Uniquecode values ");
                    DataTable dtUniqueCodeValues = binddata("UNIQUE_CODE_VALUES", this.cmb_UniqueCode.Text);
                    dcTask.WriteLog(5, "Unique code values count:"+dtUniqueCodeValues.Rows.Count);
                    if (dtUniqueCodeValues.Rows.Count > 0)
                    {
                        foreach (DataRow row in dtUniqueCodeValues.Rows)
                        {
                            this.dcedEntity.CtlText = row["ENTITY"].ToString();
                            dcedEntity.Focus();
                            this.dcedPrimaryUser.CtlText = row["PRIMARY_USER"].ToString();
                            dcedPrimaryUser.Focus();
                            this.dcedRegion.CtlText = row["REGION"].ToString();
                            dcedRegion.Focus();
                            this.dcedState.CtlText = row["STATE"].ToString();
                            dcedState.Focus();
                            this.dcedCity.CtlText = row["CITY"].ToString();
                            dcedCity.Focus();
                            this.dcedPropertyAddress.CtlText = row["PROPERTY_ADDRESS"].ToString();
                            dcedPropertyAddress.Focus();

                        }
                    }
                    dcTask.WriteLog(5, "Bind the Selected Uniquecode is Successful ");
                }
                else
                {
                    this.dcedEntity.CtlText = "";
                    dcedEntity.Focus();
                    this.dcedPrimaryUser.CtlText = "";
                    dcedPrimaryUser.Focus();
                    this.dcedRegion.CtlText = "";
                    dcedRegion.Focus();
                    this.dcedState.CtlText = "";
                    dcedState.Focus();
                    this.dcedCity.CtlText = "";
                    dcedCity.Focus();
                    cmb_UniqueCode.Focus();

                    this.dcedPropertyAddress.CtlText = "";
                    dcedPropertyAddress.Focus();

                    this.dcedUniqueCode.Visible = true;
                    this.dcedUniqueCode.CtlText = "";
                    dcedUniqueCode.Focus();
                    dcedUniqueCode.Visible = false;
                }
             //   this.cmb_UniqueCode.AutoCompleteMode = AutoCompleteMode.Suggest;
                //this.cmb_UniqueCode.AutoCompleteSource = AutoCompleteSource.ListItems;
            }
            catch(Exception ex)
            {
                dcTask.WriteLog(5, "Error in cmb_UniqueCode_SelectedIndexChanged: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        private void cmb_Function_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmb_UniqueCode.Text != "SELECT")
                {
                    this.dcedFunction.Visible = true;
                    this.dcedFunction.CtlText = this.cmb_Function.Text;
                    dcedFunction.Focus();
                    dcedFunction.Visible = false;
                    cmb_DocumentType.Focus();
                    dcTask.WriteLog(5, "Binding the Selected cmb_Function FUNCTION_VALUES");
                    DataTable dtFunction = binddata("FUNCTION_VALUES", this.cmb_Function.Text);
                    cmb_DocumentType.SelectedIndex = -1;
                    dcTask.WriteLog(5, "Filling the cmb_Function DocType");
                    fill_DocType(dtFunction);
                    dcTask.WriteLog(5, "Fill to cmb_Function DocType is successful");
                    //foreach (DataRow row in dtUniqueCodeValues.Rows)
                    //{
                    //    lstdoctype.Add(row["DOCUMENT_TYPE"].ToString());

                    //}

                    //this.cmb_DocumentType.Items.AddRange(lstdoctype.ToArray());
                    //this.cmb_DocumentType.AutoCompleteMode = AutoCompleteMode.Suggest;
                    //this.cmb_DocumentType.AutoCompleteSource = AutoCompleteSource.ListItems;
                }
                else
                {
                    this.dcedFunction.Visible = true;
                    this.dcedFunction.CtlText = "";
                    dcedFunction.Focus();
                    dcedFunction.Visible = false;
                    cmb_Function.Focus();
                    cmb_DocumentType.Items.Clear();
                    cmb_DocumentType.SelectedIndex = -1;

                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in cmb_Function_SelectedIndexChanged: " + ex.Message + "  Details: " + ex.ToString());
            }

        }

        private void cmb_DocumentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LstDocumentType.Visible = false;
                this.dcedDocumentType.Visible = true;
                this.dcedDocumentType.CtlText = this.cmb_DocumentType.Text;
                dcedDocumentType.Focus();
                this.dcedDocumentType.Visible = false;
                dcTask.WriteLog(5, "hiding the" +cmb_DocumentType.Text+"Fileds");
                hidefields(cmb_DocumentType.Text);
                dcTask.WriteLog(5, "hiding is successful");
                vendorshowhide(cmb_DocumentType.Text);
                dcTask.WriteLog(5, "vendorshowhide in cmb_DocumentType_SelectedIndexChanged is successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in cmb_DocumentType_SelectedIndexChanged: " + ex.Message + "  Details: " + ex.ToString());
            }

        }

        private void cmb_VendorName_SelectedIndexChanged(object sender, EventArgs e)
        {

            this.dcedVendorName.Visible = true;
            this.dcedVendorName.CtlText = this.cmb_VendorName.Text;
            dcedVendorName.Focus();
            this.dcedVendorName.Visible = false;
        }

        void fill_UniqueCode(DataTable dtuniquecode)
        {
            try
            {
                DataRow rowVendorname = dtuniquecode.NewRow();
                rowVendorname["UNIQUE_CODE"] = "SELECT";
                dtuniquecode.Rows.InsertAt(rowVendorname, 0);
                cmb_UniqueCode.Items.Clear();
                List<String> lstFirst = new List<string>();
                ///Unique Code
                foreach (DataRow row in dtuniquecode.Rows)
                {
                    lstFirst.Add(row["UNIQUE_CODE"].ToString());

                }
                this.cmb_UniqueCode.Items.AddRange(lstFirst.ToArray());
              //  this.cmb_UniqueCode.AutoCompleteMode = AutoCompleteMode.None;
              //  this.cmb_UniqueCode.AutoCompleteSource = AutoCompleteSource.ListItems;
                dcTask.WriteLog("fill_UniqueCode is successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Binding Unique Code: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        void fill_Function(DataTable dtfunction)
        {
            try {
               
            DataRow rowVendorname = dtfunction.NewRow();
            rowVendorname["FUNCTION"] = "SELECT";
            dtfunction.Rows.InsertAt(rowVendorname, 0);

            cmb_Function.Items.Clear();
            List<String> lstfunction = new List<string>();
            ///Function
            foreach (DataRow row in dtfunction.Rows)
            {
                lstfunction.Add(row["FUNCTION"].ToString());

            }

            this.cmb_Function.Items.AddRange(lstfunction.ToArray());
            this.cmb_Function.AutoCompleteMode = AutoCompleteMode.Suggest;
            this.cmb_Function.AutoCompleteSource = AutoCompleteSource.ListItems;
            dcTask.WriteLog("fill_Function is successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Binding Function: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        void fill_DocType(DataTable dtdoctype)
        {
            try { 
            DataRow rowVendorname = dtdoctype.NewRow();
            rowVendorname["DOCUMENT_TYPE"] = "SELECT";
            dtdoctype.Rows.InsertAt(rowVendorname, 0);
            cmb_DocumentType.Items.Clear();
            List<String> lstdoctype = new List<string>();
            ///DocType
            foreach (DataRow row in dtdoctype.Rows)
            {
                lstdoctype.Add(row["DOCUMENT_TYPE"].ToString());

            }

            this.cmb_DocumentType.Items.AddRange(lstdoctype.ToArray());
            dcTask.WriteLog("fill_DocType is successful");
          // this.cmb_DocumentType.AutoCompleteMode = AutoCompleteMode.Suggest;
           // this.cmb_DocumentType.AutoCompleteSource = AutoCompleteSource.ListItems;
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Binding DocType: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        void fill_vendor(DataTable dtVendor)
        {
            try { 
            cmb_VendorName.Items.Clear();
            List<String> lstvendor = new List<string>();
            foreach (DataRow row in dtVendor.Rows)
            {
                lstvendor.Add(row["VENDOR_NAME"].ToString());

            }

            this.cmb_VendorName.Items.AddRange(lstvendor.ToArray());
            this.cmb_VendorName.AutoCompleteMode = AutoCompleteMode.Suggest;
            this.cmb_VendorName.AutoCompleteSource = AutoCompleteSource.ListItems;
            dcTask.WriteLog("fill_vendor is successful");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Binding Vendor: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        void vendorshowhide(string strdocvalue)
        {
            try { 
            DataTable dtuniquecode = binddata("VENDOR_STATUS", strdocvalue);

            if (dtuniquecode.Rows.Count > 0)
            {
                foreach (DataRow row in dtuniquecode.Rows)
                {
                    this.cmb_Function.SelectedIndexChanged -= new EventHandler(cmb_Function_SelectedIndexChanged);
                    cmb_Function.SelectedItem = row["FUNCTION"].ToString();
                    this.cmb_Function.SelectedIndexChanged += new EventHandler(cmb_Function_SelectedIndexChanged);

                    this.dcedFunction.Visible = true;
                    this.dcedFunction.CtlText = this.cmb_Function.Text;
                    dcedFunction.Focus();
                    dcedFunction.Visible = false;
                    cmb_DocumentType.Focus();

                    XmlDocument doc = new XmlDocument();
                    doc = dcTask.BatchXML;

                    XmlNode node = dcTask.BatchXML.SelectSingleNode("(/*)");

                    XmlNode itemNode = dcTask.BatchXML.SelectSingleNode("/B/V[@n = 'FieldStatus']");


                    string strStatus = string.Empty;
                    if (row["FIELD_STATUS"].ToString() == "YES")
                    {
                        strStatus = "YES";
                        lblVendorName.Visible = true;
                        cmb_VendorName.Visible = true;
                        dcTask.WriteLog("Binding the Vendor");
                        DataTable dtVendor = binddata("N_VENDOR");
                        fill_vendor(dtVendor);
                        dcTask.WriteLog("fill_vendor is successful ");
                        cmb_VendorName.SelectedIndex = -1;
                        cmb_VendorName.SelectedText = "";

                        if (!string.IsNullOrEmpty(dcedVendorName.CtlText))
                        {
                            this.cmb_VendorName.SelectedIndexChanged -= new EventHandler(cmb_VendorName_SelectedIndexChanged);
                            cmb_VendorName.SelectedItem = dcedVendorName.CtlText;
                            this.cmb_VendorName.SelectedIndexChanged += new EventHandler(cmb_VendorName_SelectedIndexChanged);
                        }
                    }
                    else
                    {
                        strStatus = "NO";
                        lblVendorName.Visible = false;
                        cmb_VendorName.Visible = false;
                    }

                    if (itemNode == null)
                    {
                        XmlElement filedstatus = doc.CreateElement("V");
                        filedstatus.SetAttribute("n", "FieldStatus");
                        filedstatus.InnerText = strStatus;
                        node.AppendChild(filedstatus);
                        dcTask.WriteLog("fill_vendor is successful ");
                    }
                    else
                    {
                        itemNode.InnerText = strStatus;
                    }

                }
            }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in Showing or Hiding Vendor Field: " + ex.Message + "  Details: " + ex.ToString());
            }


        }

        private void dtp_IssueDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                dcedIssueDate.CtlText = dtp_IssueDate.Text;
               // dcedIssueDate.Focus();
                dcTask.WriteLog("dtp_IssueDate_ValueChanged is successful ");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in dtp_IssueDate_ValueChanged: " + ex.Message + "  Details: " + ex.ToString());
            }
        }
        private void LstUniqueCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmb_UniqueCode.Text = LstUniqueCode.SelectedItem.ToString();
                LstUniqueCode.Visible = false;
                dcTask.WriteLog("LstUniqueCode_SelectedIndexChanged is successful ");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in LstUniqueCode_SelectedIndexChanged: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        private void cmb_UniqueCode_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                dcTask.WriteLog("Binding cmb_UniqueCode_TextUpdate UNIQUE_CODE");
                DataTable dtuniquecode = binddata("UNIQUE_CODE");
                LstUniqueCode.Visible = false;
                string actual = this.cmb_UniqueCode.Text;
                if (actual == "" || actual == null)
                {
                    LstUniqueCode.Visible = false;
                    dcTask.WriteLog(5,"UNIQUE_CODE text is Null or Empty");
                }
                else
                {
                    DataRow[] rows = dtuniquecode.Select(string.Format("UNIQUE_CODE LIKE '%" + actual + "%'"));
                    //DataTable filteredTable = dtuniquecode.Clone();
                    //foreach (DataRow r in rows)
                    //    filteredTable.ImportRow(r);
                    LstUniqueCode.Items.Clear();
                    foreach (DataRow row1 in rows)
                        LstUniqueCode.Items.Add(row1[1]);
                    if (LstUniqueCode.Items.Contains("-SelectName-"))
                    {
                        LstUniqueCode.Items.Remove("-SelectName-");
                    }
                    if (LstUniqueCode.Items.Count > 0)
                    {
                        LstUniqueCode.Visible = true;
                        cmb_UniqueCode.DroppedDown = false;
                    }
                    dcTask.WriteLog(5,"cmb_UniqueCode_TextUpdate is Successful");
                }
                dcTask.WriteLog(5,"cmb_UniqueCode_TextUpdate is Completed");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in cmb_UniqueCode_TextUpdate: " + ex.Message + "  Details: " + ex.ToString());
            }
            
        }

        private void LstDocumentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmb_DocumentType.Text = LstDocumentType.SelectedItem.ToString();
                LstDocumentType.Visible = false;
                dcTask.WriteLog(5,"LstDocumentType_SelectedIndexChanged is Completed");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in LstDocumentType_SelectedIndexChanged: " + ex.Message + "  Details: " + ex.ToString());
            }
        }

        private void cmb_DocumentType_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                dcTask.WriteLog("Binding cmb_DocumentType_TextUpdate FUNCTION_VALUES");
                DataTable dtdoctype = binddata("FUNCTION_VALUES", cmb_Function.Text);
                LstDocumentType.Visible = false;
                //LstDocumentType

                string actual = this.cmb_DocumentType.Text;
                if (actual == "" || actual == null)
                {
                    LstDocumentType.Visible = false;
                    dcTask.WriteLog("DocumentType text is Null or Empty");
                }
                else
                {
                    DataRow[] rows = dtdoctype.Select(string.Format("DOCUMENT_TYPE LIKE '%" + actual + "%'"));
                    //DataTable filteredTable = dtuniquecode.Clone();
                    //foreach (DataRow r in rows)
                    //    filteredTable.ImportRow(r);
                    LstDocumentType.Items.Clear();
                    foreach (DataRow row1 in rows)
                        LstDocumentType.Items.Add(row1[0]);
                    if (LstDocumentType.Items.Contains("-SelectName-"))
                    {
                        LstDocumentType.Items.Remove("-SelectName-");
                    }
                    if (LstDocumentType.Items.Count > 0)
                    {
                        LstDocumentType.Visible = true;
                        cmb_DocumentType.DroppedDown = false;
                    }
                    dcTask.WriteLog("cmb_DocumentType_TextUpdate is Done");
                }
                dcTask.WriteLog("cmb_DocumentType_TextUpdate is Completed");
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Error in cmb_DocumentType_TextUpdate: " + ex.Message + "  Details: " + ex.ToString());
            }
        }
    }
}
