//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using DotEditLib;

namespace DotEditPanels
{
    public partial class Main_Page : dotPanelBase
    {
        public Main_Page()
        {
            InitializeComponent();
        }

        public override bool LoadData(XmlDocument xPage)
        {
            Control pNext = null;
            pNext=panLineitem.GetNextControl(pNext, true);
            while (pNext != null)
            {
                if (pNext is AxDCEDITLib.AxDcedit)
                {
                    AxDCEDITLib.AxDcedit pEdit = (AxDCEDITLib.AxDcedit)pNext;
                    pEdit.KeyDownEvent -= new AxDCEDITLib._DDceditEvents_KeyDownEventHandler(this.dcedGrid_KeyDownEvent);
                    pEdit.KeyDownEvent += new AxDCEDITLib._DDceditEvents_KeyDownEventHandler(this.dcedGrid_KeyDownEvent);
                }
                pNext = panLineitem.GetNextControl(pNext, true);
            }
            return base.LoadData(xPage);
        }


        public override bool EndBatch()
        {
            panLineitem.Visible = false;
            return base.EndBatch();
        }

        private void dcedGrid_KeyDownEvent(object sender, AxDCEDITLib._DDceditEvents_KeyDownEvent e)
        {
            int nKey = e.keyCode;
            AxDCEDITLib.AxDcedit pEdit = (AxDCEDITLib.AxDcedit)sender;
            if (nKey == 39 || nKey == 37)
            {
                int nLen=pEdit.CtlText.Length;
                object nStart=null;
                object nEnd=null;
                pEdit.GetSel(ref nStart, ref nEnd);

                if ((nKey == 39 && (int)nEnd < nLen) || nKey == 37 && (int)nStart > 0)
                    return;
                Control pNext = GetNextControl((Control)sender, (nKey == 39));
                while (pNext is AxDCIMAGELib.AxDcimage)
                    pNext = GetNextControl(pNext, (nKey == 39));
                if (pNext is AxDCEDITLib.AxDcedit)
                    pNext.Focus();
            }
            if (nKey == 38 || nKey == 40)
            {
                if (pEdit.Multiline)
                    return;
                int nLen = pEdit.CtlText.Length;
                Control pNext = GetNextControl((Control)sender, (nKey == 40));
                while (pNext!=null && (pNext is AxDCIMAGELib.AxDcimage || pNext.Left!=pEdit.Left))
                    pNext = GetNextControl(pNext, (nKey == 40));
                if (pNext!=null && pNext is AxDCEDITLib.AxDcedit)
                    pNext.Focus();
            }

        }
    }
}
