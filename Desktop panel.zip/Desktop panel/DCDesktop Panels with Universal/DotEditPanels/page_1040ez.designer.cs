
namespace DotEditPanels
{
    partial class Page_1040ez
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Page_1040ez));
            this.lblTaxpayerName = new System.Windows.Forms.Label();
            this.dcedTaxpayerName = new AxDCEDITLib.AxDcedit();
            this.dcedAddress = new AxDCEDITLib.AxDcedit();
            this.dcedCity = new AxDCEDITLib.AxDcedit();
            this.dcedState = new AxDCEDITLib.AxDcedit();
            this.dcedZip = new AxDCEDITLib.AxDcedit();
            this.dcedSpouseName = new AxDCEDITLib.AxDcedit();
            this.lblTaxpayerSSN = new System.Windows.Forms.Label();
            this.dcimTaxpayerSSN = new AxDCIMAGELib.AxDcimage();
            this.dcedTaxpayerSSN = new AxDCEDITLib.AxDcedit();
            this.lblSpouseSSN = new System.Windows.Forms.Label();
            this.dcimSpouseSSN = new AxDCIMAGELib.AxDcimage();
            this.dcedSpouseSSN = new AxDCEDITLib.AxDcedit();
            this.lbl1TotalWages = new System.Windows.Forms.Label();
            this.dcim1TotalWages = new AxDCIMAGELib.AxDcimage();
            this.dced1TotalWages = new AxDCEDITLib.AxDcedit();
            this.lbl2TaxableInterest = new System.Windows.Forms.Label();
            this.dcim2TaxableInterest = new AxDCIMAGELib.AxDcimage();
            this.dced2TaxableInterest = new AxDCEDITLib.AxDcedit();
            this.lbl3Unemployment = new System.Windows.Forms.Label();
            this.dcim3Unemployment = new AxDCIMAGELib.AxDcimage();
            this.dced3Unemployment = new AxDCEDITLib.AxDcedit();
            this.lbl4AdjustedGross = new System.Windows.Forms.Label();
            this.dcim4AdjustedGross = new AxDCIMAGELib.AxDcimage();
            this.dced4AdjustedGross = new AxDCEDITLib.AxDcedit();
            this.lbl5ParentClaimYES = new System.Windows.Forms.Label();
            this.dcim5ParentClaimYES = new AxDCIMAGELib.AxDcimage();
            this.cmb5ParentClaimYES = new System.Windows.Forms.ComboBox();
            this.dcim5ParentClaimNO = new AxDCIMAGELib.AxDcimage();
            this.cmb5ParentClaimNO = new System.Windows.Forms.ComboBox();
            this.lbl5Exemption = new System.Windows.Forms.Label();
            this.dcim5Exemption = new AxDCIMAGELib.AxDcimage();
            this.dced5Exemption = new AxDCEDITLib.AxDcedit();
            this.lbl6TaxableIncome = new System.Windows.Forms.Label();
            this.dcim6TaxableIncome = new AxDCIMAGELib.AxDcimage();
            this.dced6TaxableIncome = new AxDCEDITLib.AxDcedit();
            this.lbl7TaxWithheld = new System.Windows.Forms.Label();
            this.dcim7TaxWithheld = new AxDCIMAGELib.AxDcimage();
            this.dced7TaxWithheld = new AxDCEDITLib.AxDcedit();
            this.lbl8EIC_C = new System.Windows.Forms.Label();
            this.dced8EIC_C = new AxDCEDITLib.AxDcedit();
            this.lbl9TotalPayments = new System.Windows.Forms.Label();
            this.dcim9TotalPayments = new AxDCIMAGELib.AxDcimage();
            this.dced9TotalPayments = new AxDCEDITLib.AxDcedit();
            this.lbl10Tax = new System.Windows.Forms.Label();
            this.dcim10Tax = new AxDCIMAGELib.AxDcimage();
            this.dced10Tax = new AxDCEDITLib.AxDcedit();
            this.lbl11aRefund = new System.Windows.Forms.Label();
            this.dcim11aRefund = new AxDCIMAGELib.AxDcimage();
            this.dced11aRefund = new AxDCEDITLib.AxDcedit();
            this.lbl12TaxDue = new System.Windows.Forms.Label();
            this.dcim12TaxDue = new AxDCIMAGELib.AxDcimage();
            this.dced12TaxDue = new AxDCEDITLib.AxDcedit();
            this.lblTaxpayerSignature = new System.Windows.Forms.Label();
            this.dcimTaxpayerSignature = new AxDCIMAGELib.AxDcimage();
            this.cmbTaxpayerSignature = new System.Windows.Forms.ComboBox();
            this.lblSpouseSignature = new System.Windows.Forms.Label();
            this.dcimSpouseSignature = new AxDCIMAGELib.AxDcimage();
            this.cmbSpouseSignature = new System.Windows.Forms.ComboBox();
            this.dcimAddressSnip = new AxDCIMAGELib.AxDcimage();
            this.lblAddress = new System.Windows.Forms.Label();
            this.dcim8EIC_C = new AxDCIMAGELib.AxDcimage();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTaxpayerName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedZip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSpouseName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxpayerSSN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTaxpayerSSN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimSpouseSSN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSpouseSSN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1TotalWages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1TotalWages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim2TaxableInterest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2TaxableInterest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Unemployment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Unemployment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4AdjustedGross)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4AdjustedGross)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5ParentClaimYES)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5ParentClaimNO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5Exemption)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5Exemption)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6TaxableIncome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6TaxableIncome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7TaxWithheld)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7TaxWithheld)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8EIC_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9TotalPayments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9TotalPayments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10Tax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10Tax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aRefund)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aRefund)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12TaxDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12TaxDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxpayerSignature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimSpouseSignature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAddressSnip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8EIC_C)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTaxpayerName
            // 
            this.lblTaxpayerName.AutoSize = true;
            this.lblTaxpayerName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxpayerName.Location = new System.Drawing.Point(20, 178);
            this.lblTaxpayerName.Name = "lblTaxpayerName";
            this.lblTaxpayerName.Size = new System.Drawing.Size(101, 14);
            this.lblTaxpayerName.TabIndex = 6;
            this.lblTaxpayerName.Tag = "TaxpayerName";
            this.lblTaxpayerName.Text = "TaxpayerName";
            // 
            // dcedTaxpayerName
            // 
            this.dcedTaxpayerName.Location = new System.Drawing.Point(23, 352);
            this.dcedTaxpayerName.Name = "dcedTaxpayerName";
            this.dcedTaxpayerName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTaxpayerName.OcxState")));
            this.dcedTaxpayerName.Size = new System.Drawing.Size(437, 31);
            this.dcedTaxpayerName.TabIndex = 9;
            this.dcedTaxpayerName.Tag = "TaxpayerName";
            // 
            // dcedAddress
            // 
            this.dcedAddress.Location = new System.Drawing.Point(23, 418);
            this.dcedAddress.Name = "dcedAddress";
            this.dcedAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAddress.OcxState")));
            this.dcedAddress.Size = new System.Drawing.Size(437, 31);
            this.dcedAddress.TabIndex = 11;
            this.dcedAddress.Tag = "Address";
            // 
            // dcedCity
            // 
            this.dcedCity.Location = new System.Drawing.Point(23, 451);
            this.dcedCity.Name = "dcedCity";
            this.dcedCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCity.OcxState")));
            this.dcedCity.Size = new System.Drawing.Size(265, 31);
            this.dcedCity.TabIndex = 12;
            this.dcedCity.Tag = "City";
            // 
            // dcedState
            // 
            this.dcedState.Location = new System.Drawing.Point(289, 451);
            this.dcedState.Name = "dcedState";
            this.dcedState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedState.OcxState")));
            this.dcedState.Size = new System.Drawing.Size(47, 31);
            this.dcedState.TabIndex = 13;
            this.dcedState.Tag = "State";
            // 
            // dcedZip
            // 
            this.dcedZip.Location = new System.Drawing.Point(337, 451);
            this.dcedZip.Name = "dcedZip";
            this.dcedZip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedZip.OcxState")));
            this.dcedZip.Size = new System.Drawing.Size(123, 31);
            this.dcedZip.TabIndex = 14;
            this.dcedZip.Tag = "Zip";
            // 
            // dcedSpouseName
            // 
            this.dcedSpouseName.Location = new System.Drawing.Point(23, 385);
            this.dcedSpouseName.Name = "dcedSpouseName";
            this.dcedSpouseName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedSpouseName.OcxState")));
            this.dcedSpouseName.Size = new System.Drawing.Size(437, 31);
            this.dcedSpouseName.TabIndex = 10;
            this.dcedSpouseName.Tag = "SpouseName";
            // 
            // lblTaxpayerSSN
            // 
            this.lblTaxpayerSSN.AutoSize = true;
            this.lblTaxpayerSSN.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxpayerSSN.Location = new System.Drawing.Point(20, 84);
            this.lblTaxpayerSSN.Name = "lblTaxpayerSSN";
            this.lblTaxpayerSSN.Size = new System.Drawing.Size(90, 14);
            this.lblTaxpayerSSN.TabIndex = 0;
            this.lblTaxpayerSSN.Tag = "TaxpayerSSN";
            this.lblTaxpayerSSN.Text = "TaxpayerSSN";
            // 
            // dcimTaxpayerSSN
            // 
            this.dcimTaxpayerSSN.Location = new System.Drawing.Point(23, 101);
            this.dcimTaxpayerSSN.Name = "dcimTaxpayerSSN";
            this.dcimTaxpayerSSN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTaxpayerSSN.OcxState")));
            this.dcimTaxpayerSSN.Size = new System.Drawing.Size(208, 31);
            this.dcimTaxpayerSSN.TabIndex = 1;
            this.dcimTaxpayerSSN.TabStop = false;
            this.dcimTaxpayerSSN.Tag = "TaxpayerSSN";
            // 
            // dcedTaxpayerSSN
            // 
            this.dcedTaxpayerSSN.Location = new System.Drawing.Point(23, 140);
            this.dcedTaxpayerSSN.Name = "dcedTaxpayerSSN";
            this.dcedTaxpayerSSN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTaxpayerSSN.OcxState")));
            this.dcedTaxpayerSSN.Size = new System.Drawing.Size(208, 31);
            this.dcedTaxpayerSSN.TabIndex = 2;
            this.dcedTaxpayerSSN.Tag = "TaxpayerSSN";
            // 
            // lblSpouseSSN
            // 
            this.lblSpouseSSN.AutoSize = true;
            this.lblSpouseSSN.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpouseSSN.Location = new System.Drawing.Point(247, 84);
            this.lblSpouseSSN.Name = "lblSpouseSSN";
            this.lblSpouseSSN.Size = new System.Drawing.Size(79, 14);
            this.lblSpouseSSN.TabIndex = 3;
            this.lblSpouseSSN.Tag = "SpouseSSN";
            this.lblSpouseSSN.Text = "SpouseSSN";
            // 
            // dcimSpouseSSN
            // 
            this.dcimSpouseSSN.Location = new System.Drawing.Point(250, 101);
            this.dcimSpouseSSN.Name = "dcimSpouseSSN";
            this.dcimSpouseSSN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimSpouseSSN.OcxState")));
            this.dcimSpouseSSN.Size = new System.Drawing.Size(208, 31);
            this.dcimSpouseSSN.TabIndex = 4;
            this.dcimSpouseSSN.TabStop = false;
            this.dcimSpouseSSN.Tag = "SpouseSSN";
            // 
            // dcedSpouseSSN
            // 
            this.dcedSpouseSSN.Location = new System.Drawing.Point(250, 141);
            this.dcedSpouseSSN.Name = "dcedSpouseSSN";
            this.dcedSpouseSSN.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedSpouseSSN.OcxState")));
            this.dcedSpouseSSN.Size = new System.Drawing.Size(208, 31);
            this.dcedSpouseSSN.TabIndex = 5;
            this.dcedSpouseSSN.Tag = "SpouseSSN";
            // 
            // lbl1TotalWages
            // 
            this.lbl1TotalWages.AutoSize = true;
            this.lbl1TotalWages.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1TotalWages.Location = new System.Drawing.Point(860, 28);
            this.lbl1TotalWages.Name = "lbl1TotalWages";
            this.lbl1TotalWages.Size = new System.Drawing.Size(90, 14);
            this.lbl1TotalWages.TabIndex = 23;
            this.lbl1TotalWages.Tag = "1TotalWages";
            this.lbl1TotalWages.Text = "1TotalWages";
            // 
            // dcim1TotalWages
            // 
            this.dcim1TotalWages.Location = new System.Drawing.Point(484, 16);
            this.dcim1TotalWages.Name = "dcim1TotalWages";
            this.dcim1TotalWages.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim1TotalWages.OcxState")));
            this.dcim1TotalWages.Size = new System.Drawing.Size(182, 31);
            this.dcim1TotalWages.TabIndex = 21;
            this.dcim1TotalWages.TabStop = false;
            this.dcim1TotalWages.Tag = "1TotalWages";
            // 
            // dced1TotalWages
            // 
            this.dced1TotalWages.Location = new System.Drawing.Point(671, 16);
            this.dced1TotalWages.Name = "dced1TotalWages";
            this.dced1TotalWages.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced1TotalWages.OcxState")));
            this.dced1TotalWages.Size = new System.Drawing.Size(182, 31);
            this.dced1TotalWages.TabIndex = 22;
            this.dced1TotalWages.Tag = "1TotalWages";
            // 
            // lbl2TaxableInterest
            // 
            this.lbl2TaxableInterest.AutoSize = true;
            this.lbl2TaxableInterest.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2TaxableInterest.Location = new System.Drawing.Point(860, 67);
            this.lbl2TaxableInterest.Name = "lbl2TaxableInterest";
            this.lbl2TaxableInterest.Size = new System.Drawing.Size(115, 14);
            this.lbl2TaxableInterest.TabIndex = 26;
            this.lbl2TaxableInterest.Tag = "2TaxableInterest";
            this.lbl2TaxableInterest.Text = "2TaxableInterest";
            // 
            // dcim2TaxableInterest
            // 
            this.dcim2TaxableInterest.Location = new System.Drawing.Point(484, 55);
            this.dcim2TaxableInterest.Name = "dcim2TaxableInterest";
            this.dcim2TaxableInterest.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim2TaxableInterest.OcxState")));
            this.dcim2TaxableInterest.Size = new System.Drawing.Size(182, 31);
            this.dcim2TaxableInterest.TabIndex = 24;
            this.dcim2TaxableInterest.TabStop = false;
            this.dcim2TaxableInterest.Tag = "2TaxableInterest";
            // 
            // dced2TaxableInterest
            // 
            this.dced2TaxableInterest.Location = new System.Drawing.Point(671, 55);
            this.dced2TaxableInterest.Name = "dced2TaxableInterest";
            this.dced2TaxableInterest.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced2TaxableInterest.OcxState")));
            this.dced2TaxableInterest.Size = new System.Drawing.Size(182, 31);
            this.dced2TaxableInterest.TabIndex = 25;
            this.dced2TaxableInterest.Tag = "2TaxableInterest";
            // 
            // lbl3Unemployment
            // 
            this.lbl3Unemployment.AutoSize = true;
            this.lbl3Unemployment.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Unemployment.Location = new System.Drawing.Point(860, 101);
            this.lbl3Unemployment.Name = "lbl3Unemployment";
            this.lbl3Unemployment.Size = new System.Drawing.Size(109, 14);
            this.lbl3Unemployment.TabIndex = 29;
            this.lbl3Unemployment.Tag = "3Unemployment";
            this.lbl3Unemployment.Text = "3Unemployment";
            // 
            // dcim3Unemployment
            // 
            this.dcim3Unemployment.Location = new System.Drawing.Point(484, 94);
            this.dcim3Unemployment.Name = "dcim3Unemployment";
            this.dcim3Unemployment.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim3Unemployment.OcxState")));
            this.dcim3Unemployment.Size = new System.Drawing.Size(182, 31);
            this.dcim3Unemployment.TabIndex = 27;
            this.dcim3Unemployment.TabStop = false;
            this.dcim3Unemployment.Tag = "3Unemployment";
            // 
            // dced3Unemployment
            // 
            this.dced3Unemployment.Location = new System.Drawing.Point(671, 94);
            this.dced3Unemployment.Name = "dced3Unemployment";
            this.dced3Unemployment.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced3Unemployment.OcxState")));
            this.dced3Unemployment.Size = new System.Drawing.Size(182, 31);
            this.dced3Unemployment.TabIndex = 28;
            this.dced3Unemployment.Tag = "3Unemployment";
            // 
            // lbl4AdjustedGross
            // 
            this.lbl4AdjustedGross.AutoSize = true;
            this.lbl4AdjustedGross.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4AdjustedGross.Location = new System.Drawing.Point(860, 140);
            this.lbl4AdjustedGross.Name = "lbl4AdjustedGross";
            this.lbl4AdjustedGross.Size = new System.Drawing.Size(107, 14);
            this.lbl4AdjustedGross.TabIndex = 32;
            this.lbl4AdjustedGross.Tag = "4AdjustedGross";
            this.lbl4AdjustedGross.Text = "4AdjustedGross";
            // 
            // dcim4AdjustedGross
            // 
            this.dcim4AdjustedGross.Location = new System.Drawing.Point(484, 133);
            this.dcim4AdjustedGross.Name = "dcim4AdjustedGross";
            this.dcim4AdjustedGross.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim4AdjustedGross.OcxState")));
            this.dcim4AdjustedGross.Size = new System.Drawing.Size(182, 31);
            this.dcim4AdjustedGross.TabIndex = 30;
            this.dcim4AdjustedGross.TabStop = false;
            this.dcim4AdjustedGross.Tag = "4AdjustedGross";
            // 
            // dced4AdjustedGross
            // 
            this.dced4AdjustedGross.Location = new System.Drawing.Point(671, 133);
            this.dced4AdjustedGross.Name = "dced4AdjustedGross";
            this.dced4AdjustedGross.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced4AdjustedGross.OcxState")));
            this.dced4AdjustedGross.Size = new System.Drawing.Size(182, 31);
            this.dced4AdjustedGross.TabIndex = 31;
            this.dced4AdjustedGross.Tag = "4AdjustedGross";
            // 
            // lbl5ParentClaimYES
            // 
            this.lbl5ParentClaimYES.AutoSize = true;
            this.lbl5ParentClaimYES.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5ParentClaimYES.Location = new System.Drawing.Point(860, 178);
            this.lbl5ParentClaimYES.Name = "lbl5ParentClaimYES";
            this.lbl5ParentClaimYES.Size = new System.Drawing.Size(114, 14);
            this.lbl5ParentClaimYES.TabIndex = 37;
            this.lbl5ParentClaimYES.Tag = "5ParentClaimYES";
            this.lbl5ParentClaimYES.Text = "5ParentClaimYES";
            // 
            // dcim5ParentClaimYES
            // 
            this.dcim5ParentClaimYES.Location = new System.Drawing.Point(484, 172);
            this.dcim5ParentClaimYES.Name = "dcim5ParentClaimYES";
            this.dcim5ParentClaimYES.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5ParentClaimYES.OcxState")));
            this.dcim5ParentClaimYES.Size = new System.Drawing.Size(68, 31);
            this.dcim5ParentClaimYES.TabIndex = 33;
            this.dcim5ParentClaimYES.TabStop = false;
            this.dcim5ParentClaimYES.Tag = "5ParentClaimYES";
            // 
            // cmb5ParentClaimYES
            // 
            this.cmb5ParentClaimYES.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb5ParentClaimYES.FormattingEnabled = true;
            this.cmb5ParentClaimYES.Location = new System.Drawing.Point(558, 172);
            this.cmb5ParentClaimYES.Name = "cmb5ParentClaimYES";
            this.cmb5ParentClaimYES.Size = new System.Drawing.Size(107, 26);
            this.cmb5ParentClaimYES.TabIndex = 34;
            this.cmb5ParentClaimYES.Tag = "5ParentClaimYES";
            // 
            // dcim5ParentClaimNO
            // 
            this.dcim5ParentClaimNO.Location = new System.Drawing.Point(671, 172);
            this.dcim5ParentClaimNO.Name = "dcim5ParentClaimNO";
            this.dcim5ParentClaimNO.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5ParentClaimNO.OcxState")));
            this.dcim5ParentClaimNO.Size = new System.Drawing.Size(67, 31);
            this.dcim5ParentClaimNO.TabIndex = 35;
            this.dcim5ParentClaimNO.TabStop = false;
            this.dcim5ParentClaimNO.Tag = "5ParentClaimNO";
            // 
            // cmb5ParentClaimNO
            // 
            this.cmb5ParentClaimNO.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb5ParentClaimNO.FormattingEnabled = true;
            this.cmb5ParentClaimNO.Location = new System.Drawing.Point(744, 172);
            this.cmb5ParentClaimNO.Name = "cmb5ParentClaimNO";
            this.cmb5ParentClaimNO.Size = new System.Drawing.Size(109, 26);
            this.cmb5ParentClaimNO.TabIndex = 36;
            this.cmb5ParentClaimNO.Tag = "5ParentClaimNO";
            // 
            // lbl5Exemption
            // 
            this.lbl5Exemption.AutoSize = true;
            this.lbl5Exemption.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5Exemption.Location = new System.Drawing.Point(860, 223);
            this.lbl5Exemption.Name = "lbl5Exemption";
            this.lbl5Exemption.Size = new System.Drawing.Size(81, 14);
            this.lbl5Exemption.TabIndex = 40;
            this.lbl5Exemption.Tag = "5Exemption";
            this.lbl5Exemption.Text = "5Exemption";
            // 
            // dcim5Exemption
            // 
            this.dcim5Exemption.Location = new System.Drawing.Point(484, 211);
            this.dcim5Exemption.Name = "dcim5Exemption";
            this.dcim5Exemption.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim5Exemption.OcxState")));
            this.dcim5Exemption.Size = new System.Drawing.Size(182, 31);
            this.dcim5Exemption.TabIndex = 38;
            this.dcim5Exemption.TabStop = false;
            this.dcim5Exemption.Tag = "5Exemption";
            // 
            // dced5Exemption
            // 
            this.dced5Exemption.Location = new System.Drawing.Point(671, 211);
            this.dced5Exemption.Name = "dced5Exemption";
            this.dced5Exemption.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced5Exemption.OcxState")));
            this.dced5Exemption.Size = new System.Drawing.Size(182, 31);
            this.dced5Exemption.TabIndex = 39;
            this.dced5Exemption.Tag = "5Exemption";
            // 
            // lbl6TaxableIncome
            // 
            this.lbl6TaxableIncome.AutoSize = true;
            this.lbl6TaxableIncome.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6TaxableIncome.Location = new System.Drawing.Point(859, 262);
            this.lbl6TaxableIncome.Name = "lbl6TaxableIncome";
            this.lbl6TaxableIncome.Size = new System.Drawing.Size(110, 14);
            this.lbl6TaxableIncome.TabIndex = 43;
            this.lbl6TaxableIncome.Tag = "6TaxableIncome";
            this.lbl6TaxableIncome.Text = "6TaxableIncome";
            // 
            // dcim6TaxableIncome
            // 
            this.dcim6TaxableIncome.Location = new System.Drawing.Point(484, 250);
            this.dcim6TaxableIncome.Name = "dcim6TaxableIncome";
            this.dcim6TaxableIncome.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim6TaxableIncome.OcxState")));
            this.dcim6TaxableIncome.Size = new System.Drawing.Size(182, 31);
            this.dcim6TaxableIncome.TabIndex = 41;
            this.dcim6TaxableIncome.TabStop = false;
            this.dcim6TaxableIncome.Tag = "6TaxableIncome";
            // 
            // dced6TaxableIncome
            // 
            this.dced6TaxableIncome.Location = new System.Drawing.Point(671, 250);
            this.dced6TaxableIncome.Name = "dced6TaxableIncome";
            this.dced6TaxableIncome.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced6TaxableIncome.OcxState")));
            this.dced6TaxableIncome.Size = new System.Drawing.Size(182, 31);
            this.dced6TaxableIncome.TabIndex = 42;
            this.dced6TaxableIncome.Tag = "6TaxableIncome";
            // 
            // lbl7TaxWithheld
            // 
            this.lbl7TaxWithheld.AutoSize = true;
            this.lbl7TaxWithheld.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7TaxWithheld.Location = new System.Drawing.Point(859, 301);
            this.lbl7TaxWithheld.Name = "lbl7TaxWithheld";
            this.lbl7TaxWithheld.Size = new System.Drawing.Size(93, 14);
            this.lbl7TaxWithheld.TabIndex = 46;
            this.lbl7TaxWithheld.Tag = "7TaxWithheld";
            this.lbl7TaxWithheld.Text = "7TaxWithheld";
            // 
            // dcim7TaxWithheld
            // 
            this.dcim7TaxWithheld.Location = new System.Drawing.Point(484, 289);
            this.dcim7TaxWithheld.Name = "dcim7TaxWithheld";
            this.dcim7TaxWithheld.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim7TaxWithheld.OcxState")));
            this.dcim7TaxWithheld.Size = new System.Drawing.Size(182, 31);
            this.dcim7TaxWithheld.TabIndex = 44;
            this.dcim7TaxWithheld.TabStop = false;
            this.dcim7TaxWithheld.Tag = "7TaxWithheld";
            // 
            // dced7TaxWithheld
            // 
            this.dced7TaxWithheld.Location = new System.Drawing.Point(671, 289);
            this.dced7TaxWithheld.Name = "dced7TaxWithheld";
            this.dced7TaxWithheld.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced7TaxWithheld.OcxState")));
            this.dced7TaxWithheld.Size = new System.Drawing.Size(182, 31);
            this.dced7TaxWithheld.TabIndex = 45;
            this.dced7TaxWithheld.Tag = "7TaxWithheld";
            // 
            // lbl8EIC_C
            // 
            this.lbl8EIC_C.AutoSize = true;
            this.lbl8EIC_C.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8EIC_C.Location = new System.Drawing.Point(860, 340);
            this.lbl8EIC_C.Name = "lbl8EIC_C";
            this.lbl8EIC_C.Size = new System.Drawing.Size(54, 14);
            this.lbl8EIC_C.TabIndex = 49;
            this.lbl8EIC_C.Tag = "8EIC_C";
            this.lbl8EIC_C.Text = "8EIC_C";
            // 
            // dced8EIC_C
            // 
            this.dced8EIC_C.Location = new System.Drawing.Point(671, 328);
            this.dced8EIC_C.Name = "dced8EIC_C";
            this.dced8EIC_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced8EIC_C.OcxState")));
            this.dced8EIC_C.Size = new System.Drawing.Size(182, 31);
            this.dced8EIC_C.TabIndex = 48;
            this.dced8EIC_C.Tag = "8EIC_C";
            // 
            // lbl9TotalPayments
            // 
            this.lbl9TotalPayments.AutoSize = true;
            this.lbl9TotalPayments.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9TotalPayments.Location = new System.Drawing.Point(859, 376);
            this.lbl9TotalPayments.Name = "lbl9TotalPayments";
            this.lbl9TotalPayments.Size = new System.Drawing.Size(108, 14);
            this.lbl9TotalPayments.TabIndex = 52;
            this.lbl9TotalPayments.Tag = "9TotalPayments";
            this.lbl9TotalPayments.Text = "9TotalPayments";
            // 
            // dcim9TotalPayments
            // 
            this.dcim9TotalPayments.Location = new System.Drawing.Point(484, 367);
            this.dcim9TotalPayments.Name = "dcim9TotalPayments";
            this.dcim9TotalPayments.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim9TotalPayments.OcxState")));
            this.dcim9TotalPayments.Size = new System.Drawing.Size(182, 31);
            this.dcim9TotalPayments.TabIndex = 50;
            this.dcim9TotalPayments.TabStop = false;
            this.dcim9TotalPayments.Tag = "9TotalPayments";
            // 
            // dced9TotalPayments
            // 
            this.dced9TotalPayments.Location = new System.Drawing.Point(671, 367);
            this.dced9TotalPayments.Name = "dced9TotalPayments";
            this.dced9TotalPayments.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced9TotalPayments.OcxState")));
            this.dced9TotalPayments.Size = new System.Drawing.Size(182, 31);
            this.dced9TotalPayments.TabIndex = 51;
            this.dced9TotalPayments.Tag = "9TotalPayments";
            // 
            // lbl10Tax
            // 
            this.lbl10Tax.AutoSize = true;
            this.lbl10Tax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10Tax.Location = new System.Drawing.Point(860, 418);
            this.lbl10Tax.Name = "lbl10Tax";
            this.lbl10Tax.Size = new System.Drawing.Size(45, 14);
            this.lbl10Tax.TabIndex = 55;
            this.lbl10Tax.Tag = "10Tax";
            this.lbl10Tax.Text = "10Tax";
            // 
            // dcim10Tax
            // 
            this.dcim10Tax.Location = new System.Drawing.Point(484, 406);
            this.dcim10Tax.Name = "dcim10Tax";
            this.dcim10Tax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim10Tax.OcxState")));
            this.dcim10Tax.Size = new System.Drawing.Size(182, 31);
            this.dcim10Tax.TabIndex = 53;
            this.dcim10Tax.TabStop = false;
            this.dcim10Tax.Tag = "10Tax";
            // 
            // dced10Tax
            // 
            this.dced10Tax.Location = new System.Drawing.Point(671, 406);
            this.dced10Tax.Name = "dced10Tax";
            this.dced10Tax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced10Tax.OcxState")));
            this.dced10Tax.Size = new System.Drawing.Size(182, 31);
            this.dced10Tax.TabIndex = 54;
            this.dced10Tax.Tag = "10Tax";
            // 
            // lbl11aRefund
            // 
            this.lbl11aRefund.AutoSize = true;
            this.lbl11aRefund.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11aRefund.Location = new System.Drawing.Point(859, 457);
            this.lbl11aRefund.Name = "lbl11aRefund";
            this.lbl11aRefund.Size = new System.Drawing.Size(75, 14);
            this.lbl11aRefund.TabIndex = 58;
            this.lbl11aRefund.Tag = "11aRefund";
            this.lbl11aRefund.Text = "11aRefund";
            // 
            // dcim11aRefund
            // 
            this.dcim11aRefund.Location = new System.Drawing.Point(484, 445);
            this.dcim11aRefund.Name = "dcim11aRefund";
            this.dcim11aRefund.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim11aRefund.OcxState")));
            this.dcim11aRefund.Size = new System.Drawing.Size(182, 31);
            this.dcim11aRefund.TabIndex = 56;
            this.dcim11aRefund.TabStop = false;
            this.dcim11aRefund.Tag = "11aRefund";
            // 
            // dced11aRefund
            // 
            this.dced11aRefund.Location = new System.Drawing.Point(671, 445);
            this.dced11aRefund.Name = "dced11aRefund";
            this.dced11aRefund.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced11aRefund.OcxState")));
            this.dced11aRefund.Size = new System.Drawing.Size(182, 31);
            this.dced11aRefund.TabIndex = 57;
            this.dced11aRefund.Tag = "11aRefund";
            // 
            // lbl12TaxDue
            // 
            this.lbl12TaxDue.AutoSize = true;
            this.lbl12TaxDue.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12TaxDue.Location = new System.Drawing.Point(860, 496);
            this.lbl12TaxDue.Name = "lbl12TaxDue";
            this.lbl12TaxDue.Size = new System.Drawing.Size(70, 14);
            this.lbl12TaxDue.TabIndex = 61;
            this.lbl12TaxDue.Tag = "12TaxDue";
            this.lbl12TaxDue.Text = "12TaxDue";
            // 
            // dcim12TaxDue
            // 
            this.dcim12TaxDue.Location = new System.Drawing.Point(484, 484);
            this.dcim12TaxDue.Name = "dcim12TaxDue";
            this.dcim12TaxDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim12TaxDue.OcxState")));
            this.dcim12TaxDue.Size = new System.Drawing.Size(182, 31);
            this.dcim12TaxDue.TabIndex = 59;
            this.dcim12TaxDue.TabStop = false;
            this.dcim12TaxDue.Tag = "12TaxDue";
            // 
            // dced12TaxDue
            // 
            this.dced12TaxDue.Location = new System.Drawing.Point(671, 484);
            this.dced12TaxDue.Name = "dced12TaxDue";
            this.dced12TaxDue.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dced12TaxDue.OcxState")));
            this.dced12TaxDue.Size = new System.Drawing.Size(182, 31);
            this.dced12TaxDue.TabIndex = 60;
            this.dced12TaxDue.Tag = "12TaxDue";
            // 
            // lblTaxpayerSignature
            // 
            this.lblTaxpayerSignature.AutoSize = true;
            this.lblTaxpayerSignature.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxpayerSignature.Location = new System.Drawing.Point(72, 519);
            this.lblTaxpayerSignature.Name = "lblTaxpayerSignature";
            this.lblTaxpayerSignature.Size = new System.Drawing.Size(126, 14);
            this.lblTaxpayerSignature.TabIndex = 19;
            this.lblTaxpayerSignature.Tag = "TaxpayerSignature";
            this.lblTaxpayerSignature.Text = "TaxpayerSignature";
            // 
            // dcimTaxpayerSignature
            // 
            this.dcimTaxpayerSignature.Location = new System.Drawing.Point(23, 484);
            this.dcimTaxpayerSignature.Name = "dcimTaxpayerSignature";
            this.dcimTaxpayerSignature.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTaxpayerSignature.OcxState")));
            this.dcimTaxpayerSignature.Size = new System.Drawing.Size(101, 31);
            this.dcimTaxpayerSignature.TabIndex = 15;
            this.dcimTaxpayerSignature.TabStop = false;
            this.dcimTaxpayerSignature.Tag = "TaxpayerSignature";
            // 
            // cmbTaxpayerSignature
            // 
            this.cmbTaxpayerSignature.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTaxpayerSignature.FormattingEnabled = true;
            this.cmbTaxpayerSignature.Location = new System.Drawing.Point(130, 490);
            this.cmbTaxpayerSignature.Name = "cmbTaxpayerSignature";
            this.cmbTaxpayerSignature.Size = new System.Drawing.Size(101, 26);
            this.cmbTaxpayerSignature.TabIndex = 16;
            this.cmbTaxpayerSignature.Tag = "TaxpayerSignature";
            // 
            // lblSpouseSignature
            // 
            this.lblSpouseSignature.AutoSize = true;
            this.lblSpouseSignature.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpouseSignature.Location = new System.Drawing.Point(305, 519);
            this.lblSpouseSignature.Name = "lblSpouseSignature";
            this.lblSpouseSignature.Size = new System.Drawing.Size(115, 14);
            this.lblSpouseSignature.TabIndex = 20;
            this.lblSpouseSignature.Tag = "SpouseSignature";
            this.lblSpouseSignature.Text = "SpouseSignature";
            // 
            // dcimSpouseSignature
            // 
            this.dcimSpouseSignature.Location = new System.Drawing.Point(250, 484);
            this.dcimSpouseSignature.Name = "dcimSpouseSignature";
            this.dcimSpouseSignature.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimSpouseSignature.OcxState")));
            this.dcimSpouseSignature.Size = new System.Drawing.Size(101, 31);
            this.dcimSpouseSignature.TabIndex = 17;
            this.dcimSpouseSignature.TabStop = false;
            this.dcimSpouseSignature.Tag = "SpouseSignature";
            // 
            // cmbSpouseSignature
            // 
            this.cmbSpouseSignature.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSpouseSignature.FormattingEnabled = true;
            this.cmbSpouseSignature.Location = new System.Drawing.Point(357, 490);
            this.cmbSpouseSignature.Name = "cmbSpouseSignature";
            this.cmbSpouseSignature.Size = new System.Drawing.Size(103, 26);
            this.cmbSpouseSignature.TabIndex = 18;
            this.cmbSpouseSignature.Tag = "SpouseSignature";
            // 
            // dcimAddressSnip
            // 
            this.dcimAddressSnip.Location = new System.Drawing.Point(23, 195);
            this.dcimAddressSnip.Name = "dcimAddressSnip";
            this.dcimAddressSnip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimAddressSnip.OcxState")));
            this.dcimAddressSnip.Size = new System.Drawing.Size(437, 156);
            this.dcimAddressSnip.TabIndex = 8;
            this.dcimAddressSnip.TabStop = false;
            this.dcimAddressSnip.Tag = "AddressSnip";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(140, 178);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 14);
            this.lblAddress.TabIndex = 7;
            this.lblAddress.Tag = "Address";
            this.lblAddress.Text = "Address";
            // 
            // dcim8EIC_C
            // 
            this.dcim8EIC_C.Location = new System.Drawing.Point(484, 328);
            this.dcim8EIC_C.Name = "dcim8EIC_C";
            this.dcim8EIC_C.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcim8EIC_C.OcxState")));
            this.dcim8EIC_C.Size = new System.Drawing.Size(182, 31);
            this.dcim8EIC_C.TabIndex = 47;
            this.dcim8EIC_C.TabStop = false;
            this.dcim8EIC_C.Tag = "8EIC_C";
            // 
            // Page_1040ez
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.ClientSize = new System.Drawing.Size(1020, 533);
            this.Controls.Add(this.dcim8EIC_C);
            this.Controls.Add(this.lblTaxpayerName);
            this.Controls.Add(this.dcedTaxpayerName);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.dcedAddress);
            this.Controls.Add(this.dcedCity);
            this.Controls.Add(this.dcedState);
            this.Controls.Add(this.dcedZip);
            this.Controls.Add(this.dcedSpouseName);
            this.Controls.Add(this.lblTaxpayerSSN);
            this.Controls.Add(this.dcimTaxpayerSSN);
            this.Controls.Add(this.dcedTaxpayerSSN);
            this.Controls.Add(this.lblSpouseSSN);
            this.Controls.Add(this.dcimSpouseSSN);
            this.Controls.Add(this.dcedSpouseSSN);
            this.Controls.Add(this.lbl1TotalWages);
            this.Controls.Add(this.dcim1TotalWages);
            this.Controls.Add(this.dced1TotalWages);
            this.Controls.Add(this.lbl2TaxableInterest);
            this.Controls.Add(this.dcim2TaxableInterest);
            this.Controls.Add(this.dced2TaxableInterest);
            this.Controls.Add(this.lbl3Unemployment);
            this.Controls.Add(this.dcim3Unemployment);
            this.Controls.Add(this.dced3Unemployment);
            this.Controls.Add(this.lbl4AdjustedGross);
            this.Controls.Add(this.dcim4AdjustedGross);
            this.Controls.Add(this.dced4AdjustedGross);
            this.Controls.Add(this.lbl5ParentClaimYES);
            this.Controls.Add(this.dcim5ParentClaimYES);
            this.Controls.Add(this.cmb5ParentClaimYES);
            this.Controls.Add(this.dcim5ParentClaimNO);
            this.Controls.Add(this.cmb5ParentClaimNO);
            this.Controls.Add(this.lbl5Exemption);
            this.Controls.Add(this.dcim5Exemption);
            this.Controls.Add(this.dced5Exemption);
            this.Controls.Add(this.lbl6TaxableIncome);
            this.Controls.Add(this.dcim6TaxableIncome);
            this.Controls.Add(this.dced6TaxableIncome);
            this.Controls.Add(this.lbl7TaxWithheld);
            this.Controls.Add(this.dcim7TaxWithheld);
            this.Controls.Add(this.dced7TaxWithheld);
            this.Controls.Add(this.lbl8EIC_C);
            this.Controls.Add(this.dced8EIC_C);
            this.Controls.Add(this.lbl9TotalPayments);
            this.Controls.Add(this.dcim9TotalPayments);
            this.Controls.Add(this.dced9TotalPayments);
            this.Controls.Add(this.lbl10Tax);
            this.Controls.Add(this.dcim10Tax);
            this.Controls.Add(this.dced10Tax);
            this.Controls.Add(this.lbl11aRefund);
            this.Controls.Add(this.dcim11aRefund);
            this.Controls.Add(this.dced11aRefund);
            this.Controls.Add(this.lbl12TaxDue);
            this.Controls.Add(this.dcim12TaxDue);
            this.Controls.Add(this.dced12TaxDue);
            this.Controls.Add(this.lblTaxpayerSignature);
            this.Controls.Add(this.dcimTaxpayerSignature);
            this.Controls.Add(this.cmbTaxpayerSignature);
            this.Controls.Add(this.lblSpouseSignature);
            this.Controls.Add(this.dcimSpouseSignature);
            this.Controls.Add(this.cmbSpouseSignature);
            this.Controls.Add(this.dcimAddressSnip);
            this.Name = "Page_1040ez";
            ((System.ComponentModel.ISupportInitialize)(this.dcedTaxpayerName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedZip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSpouseName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxpayerSSN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTaxpayerSSN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimSpouseSSN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSpouseSSN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim1TotalWages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced1TotalWages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim2TaxableInterest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced2TaxableInterest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim3Unemployment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced3Unemployment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim4AdjustedGross)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced4AdjustedGross)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5ParentClaimYES)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5ParentClaimNO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim5Exemption)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced5Exemption)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim6TaxableIncome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced6TaxableIncome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim7TaxWithheld)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced7TaxWithheld)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced8EIC_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim9TotalPayments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced9TotalPayments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim10Tax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced10Tax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim11aRefund)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced11aRefund)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim12TaxDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dced12TaxDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxpayerSignature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimSpouseSignature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAddressSnip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcim8EIC_C)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTaxpayerName;
        private AxDCEDITLib.AxDcedit dcedTaxpayerName;
        private AxDCEDITLib.AxDcedit dcedAddress;
        private AxDCEDITLib.AxDcedit dcedCity;
        private AxDCEDITLib.AxDcedit dcedState;
        private AxDCEDITLib.AxDcedit dcedZip;
                                private AxDCEDITLib.AxDcedit dcedSpouseName;
                                private System.Windows.Forms.Label lblTaxpayerSSN;
                                private AxDCIMAGELib.AxDcimage dcimTaxpayerSSN;
                                private AxDCEDITLib.AxDcedit dcedTaxpayerSSN;
                                private System.Windows.Forms.Label lblSpouseSSN;
                                private AxDCIMAGELib.AxDcimage dcimSpouseSSN;
                                private AxDCEDITLib.AxDcedit dcedSpouseSSN;
                                private System.Windows.Forms.Label lbl1TotalWages;
                                private AxDCIMAGELib.AxDcimage dcim1TotalWages;
                                private AxDCEDITLib.AxDcedit dced1TotalWages;
                                private System.Windows.Forms.Label lbl2TaxableInterest;
                                private AxDCIMAGELib.AxDcimage dcim2TaxableInterest;
                                private AxDCEDITLib.AxDcedit dced2TaxableInterest;
                                private System.Windows.Forms.Label lbl3Unemployment;
                                private AxDCIMAGELib.AxDcimage dcim3Unemployment;
                                private AxDCEDITLib.AxDcedit dced3Unemployment;
                                private System.Windows.Forms.Label lbl4AdjustedGross;
                                private AxDCIMAGELib.AxDcimage dcim4AdjustedGross;
                                private AxDCEDITLib.AxDcedit dced4AdjustedGross;
                                private System.Windows.Forms.Label lbl5ParentClaimYES;
                                private AxDCIMAGELib.AxDcimage dcim5ParentClaimYES;
        private System.Windows.Forms.ComboBox cmb5ParentClaimYES;
                                private AxDCIMAGELib.AxDcimage dcim5ParentClaimNO;
                                private System.Windows.Forms.ComboBox cmb5ParentClaimNO;
                                private System.Windows.Forms.Label lbl5Exemption;
                                private AxDCIMAGELib.AxDcimage dcim5Exemption;
                                private AxDCEDITLib.AxDcedit dced5Exemption;
                                private System.Windows.Forms.Label lbl6TaxableIncome;
                                private AxDCIMAGELib.AxDcimage dcim6TaxableIncome;
                                private AxDCEDITLib.AxDcedit dced6TaxableIncome;
                                private System.Windows.Forms.Label lbl7TaxWithheld;
                                private AxDCIMAGELib.AxDcimage dcim7TaxWithheld;
                                private AxDCEDITLib.AxDcedit dced7TaxWithheld;
        private System.Windows.Forms.Label lbl8EIC_C;
                                private AxDCEDITLib.AxDcedit dced8EIC_C;
                                private System.Windows.Forms.Label lbl9TotalPayments;
                                private AxDCIMAGELib.AxDcimage dcim9TotalPayments;
                                private AxDCEDITLib.AxDcedit dced9TotalPayments;
                                private System.Windows.Forms.Label lbl10Tax;
                                private AxDCIMAGELib.AxDcimage dcim10Tax;
                                private AxDCEDITLib.AxDcedit dced10Tax;
                                private System.Windows.Forms.Label lbl11aRefund;
                                private AxDCIMAGELib.AxDcimage dcim11aRefund;
                                private AxDCEDITLib.AxDcedit dced11aRefund;
                                private System.Windows.Forms.Label lbl12TaxDue;
                                private AxDCIMAGELib.AxDcimage dcim12TaxDue;
                                private AxDCEDITLib.AxDcedit dced12TaxDue;
                                private System.Windows.Forms.Label lblTaxpayerSignature;
                                private AxDCIMAGELib.AxDcimage dcimTaxpayerSignature;
                                private System.Windows.Forms.ComboBox cmbTaxpayerSignature;
                                private System.Windows.Forms.Label lblSpouseSignature;
                                private AxDCIMAGELib.AxDcimage dcimSpouseSignature;
        private System.Windows.Forms.ComboBox cmbSpouseSignature;
        private AxDCIMAGELib.AxDcimage dcimAddressSnip;
        private System.Windows.Forms.Label lblAddress;
        private AxDCIMAGELib.AxDcimage dcim8EIC_C;
                        
    }
}
                